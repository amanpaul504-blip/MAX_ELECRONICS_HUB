<?php
date_default_timezone_set('UTC');
session_start();
require "header.php";
require 'includes/dB_pwd.php';  

$selector = $_GET["selector"] ?? '';
$validator = $_GET["validator"] ?? '';
?>

<!-- Move meta tags and external stylesheets to the real document head or leave them grouped securely -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
<link href='https://cdn.boxicons.com/3.0.6/fonts/brands/boxicons-brands.min.css' rel='stylesheet'>
<link href='https://cdn.boxicons.com/3.0.6/fonts/basic/boxicons.min.css' rel='stylesheet'>

<style>
/* Page Layout Framework */
.wrapper-main {
    margin: 0;
    padding: 0;
    background: #f4f6f9;
    font-family: Arial, Helvetica, sans-serif;
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 80vh;
}

/* Success Card Styling */
.success-wrapper {
    display: flex;
    justify-content: center;
    align-items: center;
    height: 60vh;
}
.success-card {
    background-color: #e0f2f1;
    color: #2e7d32;
    padding: 40px;
    border-radius: 15px;
    text-align: center;
    box-shadow: 0 10px 30px rgba(0,0,0,0.1);
    border: 1px solid #a5d6a7;
    max-width: 500px;
}
.success-card i {
    font-size: 4rem;
    display: block;
    margin-bottom: 15px;
}
.success-card h3 { margin: 0; font-size: 1.5rem; }
.success-card p { color: #555; margin-top: 10px; }

/* Reset Form Layout Styling */
.container {
    width: 100%;
    max-width: 700px;
    display: flex;
    background: rgba(0, 0, 0, 0.2);
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    backdrop-filter: blur(20px);
    border-radius: 12px;
    overflow: hidden;
    box-shadow: 0 10px 25px rgba(0, 0, 0, 0.15);
    position: relative; /* Fixed: Context for absolute close-btn */
}

/* Close button base styles */
.close-btn {
    position: absolute;
    top: 0px;
    right: 0px;
    background: rgba(0, 0, 0, 0.1);
    color: white;
    width: 25px;
    height: 25px;
    text-align: center;
    font-size: 20px;
    line-height: 25px;
    text-decoration: none;
    font-weight: bold;
    border-radius: 50%; /* Keeps it perfectly circular */
    transition: background 0.2s ease, color 0.2s ease; /* Smooth hover transition */
}

/* Hover state */
.close-btn:hover {
    background: skyblue;
    color: #ff4d4d;
}

/* Focus state */
.close-btn:focus {
    background: #fff;
    color: red;
    outline: 2px solid red; /* Adds visibility for accessibility */
}

/* Grid splits */
.left-side {
    width: 50%;
}
.left-side img {
    width: 100%;
    height: 100%;
    object-fit: cover;
}

.right-side {
    width: 50%;
    display: flex;
    flex-direction: column;
    justify-content: center;
    padding: 30px 20px;
}
.right-side h2 {
    text-align: center;
    font-size: 20px;
    color: #007bff;
    margin: 10px 0;
}
.right-side p.subtitle {
    text-align: center;
    font-size: 13px;
    color: #666;
    margin-bottom: 20px;
}

/* Fields & Custom Toggle Containers */
.input-box {
    position: relative;
    width: 100%;
    margin-bottom: 12px;
}
.right-side input {
    width: 100%;
    padding: 10px 35px 10px 10px; /* Added right padding for visibility eye icon */
    border: 1px solid #ccc;
    border-radius: 6px;
    font-size: 14px;
    box-sizing: border-box;
}
.right-side input:focus {
    border-color: #007bff;
    outline: none;
}
.toggle-password {
    position: absolute;
    right: 10px;
    top: 50%;
    transform: translateY(-50%);
    cursor: pointer;
    color: #888;
}

/* Button Control */
.right-side button {
    width: 100%;
    padding: 12px;
    background: #007bff;
    color: white;
    border: none;
    border-radius: 6px;
    font-size: 14px;
    font-weight: bold;
    cursor: pointer;
    transition: background 0.3s;
    margin-top: 5px;
}
.right-side button:hover {
    background: #0056b3;
}

.help {
    width: 100%;
    display: flex;
    align-items: center;
    margin-top: 20px;
    font-size: 12px;
    color: #888;
}
.help hr { flex: 1; border: 0; border-top: 1px solid #eee; }
.help span { margin: 0 10px; }

.footer-text {
    font-size: 12px;
    color: #666;
    text-align: center;
    margin-top: 15px;
}

@media (max-width: 600px) {
    .container { flex-direction: column; width: 90%; }
    .left-side { display: none; } /* Hide landscape image on small screens */
    .right-side { width: 100%; }
}
</style>

<main class="wrapper-main">
    <?php
    // Case A: Show Confirmation Alert if URL has no tokens
    if (empty($selector) && empty($validator)) {
        echo <<<HTML
        <div class="success-wrapper">
            <div class="success-card">
                <i class='bx bx-check-circle'></i>
                <h3>Success!</h3>
                <p>Your request has been submitted.<br> 
                <strong>Check your email for a reset link...</strong></p>
            </div>
        </div>
        <script>
            setTimeout(function() {
                window.location.href = 'http://localhost/MAX_ELECTRONICS_HUB/';
            }, 5000); // Redirects in 5 seconds
        </script>
        HTML;
            } 

         else { 
             // Case B: Evaluate and process incoming tokens from email click (Hexadecimal checking)

        if (!ctype_xdigit($selector) || !ctype_xdigit($validator)) {
            echo "<script>alert('Invalid token format. Redirecting to home...'); window.location.href='http://localhost/MAX_ELECTRONICS_HUB/';</script>";
            exit();
        }

        // 2. Lookup the selector in the database
        // Matches the "Y-m-d H:i:s" string format saved by your request page
        $currentDate = date("Y-m-d H:i:s");
        
        $sql = "SELECT * FROM pwdreset WHERE selector = ? AND pwdResetExpires >= ? LIMIT 1;";
        $stmt = mysqli_stmt_init($conn);

        if (!mysqli_stmt_prepare($stmt, $sql)) {
            echo "There was an error processing your request.";
            exit();
        }

        mysqli_stmt_bind_param($stmt, "ss", $selector, $currentDate);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);

        // 3. Check if a matching selector exists
        if (!$row = mysqli_fetch_assoc($result)) {
            echo "<script>alert('This link has expired or is invalid. Please request a new one.'); window.location.href='http://localhost/MAX_ELECTRONICS_HUB/res/foget.php';</script>";
            exit();
        }

        // 4. Verify the raw hexadecimal validator against the database hash
        $tokenEmail = $row['pwdResetEmail'];
        $tokenCheck = password_verify($validator, $row['validator']);

        if ($tokenCheck === false) {
            echo "<script>alert('Invalid token validation. Please request a new one.'); window.location.href='http://localhost/MAX_ELECTRONICS_HUB/res/foget.php';</script>";
            exit();
        }
        
        // Success: Tokens match! Proceed to display password input fields.
        ?>
        
        <div class="container">
            <a href="http://localhost/MAX_ELECTRONICS_HUB" class="close-btn">&times;</a>
            
            <!-- Left Side Layout Banner -->
            <div class="left-side">
                <img src="http://localhost/MAX_ELECTRONICS_HUB/Tea_Plantation.jpg" alt="Plantation">
            </div>

            <!-- Right Side Interactive Input Form -->
            <div class="right-side">
                <img src="http://localhost/MAX_ELECTRONICS_HUB/res/Logoo.jpg" style="align-self: center; border-radius: 50%; width: 70px; height: 70px; border: 1px solid #ddd; margin-bottom: 10px;" class="logo" alt="Logo">
                
                <h2>Create New Password</h2>
                <p class="subtitle">Enter and confirm your new password to reset your account password.</p>

                <form action="includes/reset_password.php" method="POST">
                    <input type="hidden" name="selector" value="<?php echo htmlspecialchars($selector); ?>">
                    <input type="hidden" name="validator" value="<?php echo htmlspecialchars($validator); ?>">
                    
                    <div class="input-box">
                        <input type="password" name="pwd" placeholder="Enter a new password" required>
                        <i class="fa-solid fa-eye toggle-password"></i>
                    </div>
                    
                    <div class="input-box">
                        <input type="password" name="pwd-repeat" placeholder="Repeat new password" required> 
                        <i class="fa-solid fa-eye toggle-password"></i>
                    </div>
                    
                    <button type="submit" name="reset-password-submit">
                        <i class="fa-solid fa-unlock-keyhole"></i> Reset Password
                    </button>
                </form>

                <div class="help">
                    <hr><span>Need help?</span><hr>
                </div>
                <p class="footer-text">
                    If you did not request a password reset, 
                    <a href="http://localhost/MAX_ELECTRONICS_HUB/nav/Contacts.php" style="color:#007bff; text-decoration:none;">contact support</a>.
                </p>
            </div>
        </div>
        <?php 
    } // End Else Token Checker block
    ?>
</main>

<script>
// Password Visibility Interaction handler
document.querySelectorAll(".toggle-password").forEach(function(icon) {
    icon.addEventListener("click", function() {
        let input = this.parentElement.querySelector("input");
        if (input.type === "password") {
            input.type = "text";
            this.classList.replace("fa-eye", "fa-eye-slash");
        } else {
            input.type = "password";
            this.classList.replace("fa-eye-slash", "fa-eye");
        }
    });
});
</script>

<?php 
// Include footer if available or delete if completely styled within header
?>


