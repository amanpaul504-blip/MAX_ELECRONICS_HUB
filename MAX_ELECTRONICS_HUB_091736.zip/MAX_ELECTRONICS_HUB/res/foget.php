<?php
require "header.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://cdn.boxicons.com/3.0.6/fonts/basic/boxicons.min.css' rel='stylesheet'>
    <link href='https://cdn.boxicons.com/3.0.6/fonts/brands/boxicons-brands.min.css' rel='stylesheet'>
</head>

<style>

body {
    margin: 0;
    padding: 0;
    background: #fff;
    font-family: Arial, Helvetica, sans-serif;
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 100vh;
}

.form-container {
    width: 600px;
    display: flex;
    margin: auto;
    max-width: 700px;
    background: rgba(0, 0, 0, 0.2);
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    backdrop-filter: blur(20px);
    border-radius: 12px;
    overflow: hidden;
    box-shadow: 0 10px 25px rgba(0, 0, 0, 0.15);
}

/* Style the link to look and act like a button */
/* Center layout container */
.container {
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
    position: relative;
}

/* Close button base styles */
.close-btn {
    position: absolute;
    top: 0px;
    right: 0px;
    background: rgba(0, 0, 0, 0.1);
    color: white;
    width: 25px;
    height: 25px;
    text-align: center;
    font-size: 20px;
    line-height: 25px;
    text-decoration: none;
    font-weight: bold;
    border-radius: 50%; /* Keeps it perfectly circular */
    transition: background 0.2s ease, color 0.2s ease; /* Smooth hover transition */
}

/* Hover state */
.close-btn:hover {
    background: #ffff;
    color: #ff4d4d;
}

/* Focus state */
.close-btn:focus {
    background: #fff;
    color: red;
    outline: 2px solid red; /* Adds visibility for accessibility */
}

/* Left Side */
.left-side {
    width:50%;
    align-self: left-side;
}

.left-side img{
    width: 100%;
    height:100%;
    object-fit: cover;
}

/* Right Side */
.right-side{
    width:50%;
    display:flex;
    flex-direction:column;
    text-align:center;
    padding: 12px;
    align-self: right-side;
}
/* Labels */
.right-side h2 {
    text-align: center;
    font-size: 16px;
    color: blue;
    padding-bottom: 1px;
}

.right-side p {
    text-align: center;
    font-size: 12px;
    padding-bottom: 2px;
}

/* Input fields */
.right-side input {
    width: 70%;
    padding-bottom: 12px;
    margin-bottom: 5px;
    border: 0.3px solid #ffff;
    border-radius: 6px;
    font-size: 12px;
    text-align: center;
    box-sizing: border-box;
}

.right-side input:focus {
    border-color: #ffff;
    outline: none;
}

/* Button */
.right-side button {
    width: 70%;
    padding-bottom: 9px;
    background: #007bff;
    color: white;
    border: none;
    border-radius: 6px;
    font-size: 12px;
    text-align: center;
    cursor: pointer;
    transition: 0.3s;
}

.right-side button:hover {
    background: #0056b3;
}

.input-container input {
  width: 100%;
  padding: 10px 10px 10px 35px; /* Extra left padding for the icon */
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
}


.footer-text p {
    width: 100%;
    max-width: 420px;
    text-align: center;
    margin-top: 10px;
}

/* Responsive */
@media (max-width: 480px) {
    .container {
        width: 90%;
        padding: 0px;
    }
}
</style>
<body>
    <main>
    <div class="form-container">
         <a href="http://localhost/MAX_ELECTRONICS_HUB" class="close-btn">&times;</a>

        <!--Left Side-->
         <div class= "left-side"><img src= "http://localhost/MAX_ELECTRONICS_HUB/Tea_Plantation.jpg" style="width: 280px;height: 300px; border-radius: 10px;"  alt="Plantation">
        </div>

        <!--Right Side-->
        <div class="right-side">
        <img src="http://localhost/MAX_ELECTRONICS_HUB/res/Logoo.jpg" style= "align-self: center; border-radius: 50%; width: 70px; height: 70px; border: .5px solid;color: red; margin-bottom: 2px; margin-top: 15px; position: relative;"class="logo" alt="Logoo">
    <section>
        <h2>Forgot your password?</h2>
        <p>Enter your email address below, then instructions to reset your password will be sent through it.</p>
       <!-- Your form element -->
    <form action="includes/reset_request.php" method="POST">
        <input type="email" id="userEmail" name="email" placeholder="eg. jessie@gmail.com" required>
        <button type="submit" name="reset_request_submit">Reset Password</button>
    </form>
    </div>
    
        <?php
        if (isset($_GET["reset"])) {
            if ($_GET["reset"] == "success") {
            echo '<p class="signupsuccess">Check your e-mail!</p>';
           }
          }
        ?>
    </section>
</div>
</main>
</body>
</html>

<?php
require "footer.php";
?>
