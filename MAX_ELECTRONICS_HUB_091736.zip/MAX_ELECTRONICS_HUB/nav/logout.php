
<?php include'C:\xampp\htdocs\MAX_ELECTRONICS_HUB\logout.php'; 
exit()
  ?>