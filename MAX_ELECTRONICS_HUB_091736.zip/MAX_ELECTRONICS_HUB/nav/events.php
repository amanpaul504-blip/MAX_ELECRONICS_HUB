<?php

session_start();
$fname = $_SESSION['fname'] ??''; 

?>

<!DOCTYPE html>
<html lang="en">
<head>
<script type="text/javascript">
  window.history.foward(); 
</script>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Community Health org</title>
  <link rel="stylesheet" href="sty.css">
  <link href='https://cdn.boxicons.com/fonts/basic/boxicons.min.css' rel='stylesheet'>
</head><br><br><br><br><br><br>

<head><h3> Events</h3>
</head><br>
<style>
    ul {
      list-style-type: square; /* Changes bullets to squares */
}
            
table, th, td {
  border:1px solid black;
  border-collapse: collapse;
  text-align: left; 
  line-spacing:10px;
  font-size: 16px; 
  padding-top:10px;
}

body {
  margin: 100px 30px 10px 30px;
  align-content: justify;
  font-size: 22px;
}

</style>
<body style="background-color: lightblue;">
<P align="Justify">Currently no events has been posted </P>

 <!-- login-btn-modal is linked to user_auth.php -->
  <?php include'user_auth.php'; ?>