<?php

session_start();
$fname = $_SESSION['fname'] ??''; 

?>

<!DOCTYPE html>
<html lang="en">
<head>
<script type="text/javascript">
  window.history.foward(); 
</script>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Community Health org</title>
  <link rel="stylesheet" href="sty.css">
  <link href='https://cdn.boxicons.com/fonts/basic/boxicons.min.css' rel='stylesheet'>
</head><br><br><br><br><br><br>

<head><h3>Volunteering</h3>
</head><br>
<style>
    ul {
      list-style-type: square; /* Changes bullets to squares */
}
            
table, th, td {
  border:1px solid black;
  border-collapse: collapse;
  text-align: left; 
  line-spacing:10px;
  font-size: 16px; 
  padding-top:10px;
}

body {
  margin: 100px 30px 10px 30px;
  align-content: justify;
  font-size: 22px;
}

</style>
<body style="background-color: lightblue;">
<P align="Justify">For individuals or organizations who wish to volunteer on specialized health care services such as surgery, physiotherapy and other services in Tanzania, we advise them to log in the account and fill the volunteer request form or email us on xxxx@gmail.com. After review their request form, we will communicate with him/her about the cost of accommodation, then we will write a letter of acceptance that will be used for visa request. <br><br>
We welcome foreigner from different countries who wish to practice with us, learn our culture and visit different tourism sites in Tanzania.</P>

 <!-- login-btn-modal is linked to user_auth.php -->
  <?php include'user_auth.php'; ?>