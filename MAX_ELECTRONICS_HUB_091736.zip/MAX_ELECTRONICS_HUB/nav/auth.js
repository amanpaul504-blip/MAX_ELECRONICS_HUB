document.addEventListener("DOMContentLoaded", function () {
    const profileBox = document.querySelector(".profile-box");
    const dropdown = document.querySelector(".dropdown");

    if (profileBox && dropdown) {
        profileBox.addEventListener("click", function (e) {
            e.stopPropagation();
            dropdown.classList.toggle("show");
        });

        document.addEventListener("click", function () {
            dropdown.classList.remove("show");
        });
    }
});
