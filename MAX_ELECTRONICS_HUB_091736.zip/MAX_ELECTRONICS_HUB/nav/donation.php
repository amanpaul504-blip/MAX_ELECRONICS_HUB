<?php

session_start();
$fname = $_SESSION['fname'] ??''; 

?>

<!DOCTYPE html>
<html lang="en">
<head>
<script type="text/javascript">
  window.history.foward(); 
</script>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Community Health org</title>
  <link rel="stylesheet" href="sty.css">
  <link href='https://cdn.boxicons.com/fonts/basic/boxicons.min.css' rel='stylesheet'>
</head><br><br><br><br><br><br>

<head><h3> Pledge a Donation</h3>
</head><br>
<style>
    ul {
      list-style-type: square; /* Changes bullets to squares */
}
            
table, th, td {
  border:1px solid black;
  border-collapse: collapse;
  text-align: left; 
  line-spacing:10px;
  font-size: 16px; 
  padding-top:10px;
}

body {
  margin: 100px 30px 10px 30px;
  align-content: justify;
  font-size: 22px;
}

</style>
<body style="background-color: lightblue;">
<P align="Justify">CIHL as a non-Profit Organization, we invite stakeholders and individuals to donate any amount of money or material they wish, this will support implementation of different health activities as per planned activities in Tanzania.<br><br>
We do believe some organization or individuals have a desire to support poor communities achieve their health needs, but they haven’t found proper agents that can fulfill their needs. CIHL is the right organization that can deliver appropriate service to the community as per donors’ desire, where you can specify the area of intervention, for example maternal care, child malnutrition or any other.<br><br> We are currently solicitizing for fund for treatment of hospitalized malnourished children and rehabilitation of children who are with disabilities.
If you wish to donate log in the account to fill the pledge donation form or click the link  <a href="http://localhost/MAX_ELECTRONICS_HUB/nav/appl/don.php"> Donation Pledge form</a> to pledge your donation, then you will receive the directives on your email.  And if you have any concern about donations, contact us on xxxxxx.</P>

 <!-- login-btn-modal is linked to user_auth.php -->
  <?php include'user_auth.php'; ?>