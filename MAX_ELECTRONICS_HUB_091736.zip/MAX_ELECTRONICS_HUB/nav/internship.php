<?php

session_start();
$fname = $_SESSION['fname'] ??''; 

?>

<!DOCTYPE html>
<html lang="en">
<head>
<script type="text/javascript">
  window.history.foward(); 
</script>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Home</title>
  <link rel="stylesheet" href="sty.css">
  <link href='https://cdn.boxicons.com/fonts/basic/boxicons.min.css' rel='stylesheet'>
</head><br><br><br><br><br><br>

<head><h3>Safari Intership Program</h3>
</head>
<style>
    ul {
      list-style-type: square; /* Changes bullets to squares */
}
            
table, th, td {
  border:1px solid black;
  border-collapse: collapse;
  text-align: left; 
  line-spacing:10px;
  font-size: 16px; 
  padding-top:10px;
}

body {
  margin: 100px 30px 10px 30px;
  align-content: justify;
  font-size: 22px;
}

</style>
<body style="background-color: lightblue;">

<P align="Justify">Safari internship program is a medical internships program for students, graduate, and young professional around the world organised by Community Initiatives for Healthy Life (CIHL) in a Tanzania. We coordinate sourcing and customizing internship placement as well as provision of accommodation, and meals. We are currently operating in Mufindi District in Iringa Region-Tanzania, our placements are customized to meet your study requirements and career needs. <br><br>
Welcome to Southern Highlands of Tanzania to fulfill your career needs on medical field and for tourism, where you will be able to visit the world’s spectacular tourism centers of Isimila Stone Age, Ruaha National Park, Katavi National Park and many more.
</P><br>

<head><h3>How to apply </h3></head>
<p align="Justify">To apply for the'Safari Internship Program(SIP)', you fill our online application form after registering a user account. Filling the form and submitting the application form takes few minutes and it costs $20 only. The application form asks questions that help us to understand your career objectives, educational background, and other characters so we can match with our capabilities to fulfill your career needs.<br><br>
Before you apply for the post, you should be able to answer these questions.
<ul align=left 20px:><li>Which internship program are you interested in medical field and for how long will you practice?</li> 
<li>Does the medical course you studied or studying relate to the field you want to apply?</li>
<li>What are the relevant areas of your studies relate to your chosen internship field?</li>
<li>What motivate you to apply for Medical internship in Tanzania?</li></ul>
</p><br>

<head><h3 id ="Eligibility">Eligibility Criteria</h3></head>
<p align="Justify"> To be succesful with your application for intership with CHIO, you need to have;<br> <ul><li>You must have medical background and/or practical experiences that is relevant to your chosen internship field.</li> 
<li>You must be at least 18 years old.</li> 
<li>English is our prevalence communication language.</li></ul><br>
Once your application form is submitted online, our staffs review your background, experience, and interests if it fits your chosen internship program. The application process is interactive and consultative, where we discuss and advise applicants on different matters that arise to come up with the right choice for your career. We are currently organizing intern medical practices on Medical Laboratory Sciences, Medicine, General Nursing, Nursing Midwifery, Dental Surgery, Oral hygiene, Physiotherapy, and Radiography. We encourage you to please check these before you apply.</p><br>

<head><h3>Internship commencement period</h3></head>
<p align="Justify">Our programs run throughout the year. However, we do make slight changes to the dates to ensure they align with your program’s requirement and accessibility. We usually communicate with applicants to make sure everything run smoothly to fulfill their career and social needs, and to inform them if their applications has been accepted. If you prefer to communicate with us before filling an online application, please dont hesitate just get in touch with our team.</p><br>

</body>
<head><h3>Program fees</h3></head>
<p>Program fee ranges from 1,100 US$ to 3,800 US$ for the period of 2 to 22 weeks of stay and practice, which is equivalent to the average 32 US$ per day. The amount paid covers the cost of coordinating internship placements and arranging the accommodation near Hospitals and Health centers in Tanzania. The item covered are:-
<ul><li>Orientation,</li>
<li>Accommodation,</li>
<li>Meals (Dinner and Breakfast)</li>
<li>Local staff support during internship practices.</li>
<li>One day per month tour visit at the chosen sites</li></ul>
</p><br>

<p>Here is the table showing the amount of fees to be paid per weeks of practice</p><br>

<table style="width:100%">
  <tr>
       <th align="center">Number of Weeks</th>
    <th>2</th><th>3</th> <th>4</th><th>5</th><th>6</th> <th>7</th> <th>8</th><th>9</th> <th>10</th><th>11</th><th>12</th><th>13</th><th>14</th><th>15</th><th>16</th><th>17</th><th>18</th><th>19</th><th>20</th><th>21</th><th>22</th></tr>
  <tr>
    <td align="Left"><b>Fees in US$</b></td><td>1,100</td><td>1,150</td><td>1,200</td><td>1,500</td><td>1,560</td><td>1,620</td><td>1,680</td><td>1,740</td><td>2,000</td><td>2,080</td><td>2,160</td><td>2,240</td><td>2,320</td><td>3,000</td><td>3,100</td><td>3,300</td><td>3,400</td><td>3,500</td><td>3,600</td><td>3,700</td><td>3,800</td></td>
  </tr>
  <tr>
    <td><b>Average US$ per day</b></td><td>79</td><td>55</td><td>43</td><td>43</td><td>37</td><td>33</td><td>30</td><td>28</td><td>29</td><td>27</td><td>26</td><td>25</td><td>24</td><td>29</td><td>28</td><td>28</td><td>27</td><td>26</td><td>26</td><td>25</td><td>25</td></td>
  </tr></table><br>

<b> Note:</b><br>
<p align="Justify"><ul><li>Registration fee of $20 is not part of the Program Fee.
<li align="Justify">Internship placements require interns to pay Ministry of Health contributions. The contributions are not included in the internship program fee; it must be made directly, in-country, under the directives and guidance of the Program Coordinator in the country. 
Interns will not be permitted to commence their placement until this has been covered. The amount of the Ministry of Health contribution varies, as it is not the same for every medical field. However, to cover the contribution sufficiently, we advice interns to budget up to US$75 per week.</li>
<li align="justify">Balance of your Program Fee is due 14 days before your internship start date, where it can also be paid in installments.</li>
<li align="Justify">All additional charges which are not listed will be paid by an individual.</li></ul>
</p>
 <!-- login-btn-modal is linked to user_auth.php -->
  <?php include'user_auth.php'; ?>
<script src="MAX_ELECTRONICS_HUB/script.js"></script><br><br><br>

</body>
</html>