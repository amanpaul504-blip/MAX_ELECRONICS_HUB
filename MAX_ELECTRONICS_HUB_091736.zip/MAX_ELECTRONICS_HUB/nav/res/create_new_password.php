<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
?>
   <!-- login-btn-modal is linked to user_auth.php -->
  <?php include($_SERVER['DOCUMENT_ROOT'] . '/MAX_ELECTRONICS_HUB/res/create_new_password.php');
 ?>
  
 