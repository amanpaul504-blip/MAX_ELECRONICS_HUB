<?php
if (session_status() == PHP_SESSION_NONE) {
  
}
  include'C:\xampp\htdocs\MAX_ELECTRONICS_HUB\appl\int_pdf.php'; 
  ?>