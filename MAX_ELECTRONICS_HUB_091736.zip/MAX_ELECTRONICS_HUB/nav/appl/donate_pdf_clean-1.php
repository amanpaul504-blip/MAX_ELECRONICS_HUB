// 1. First, load and validate the environment variables
if (is_file(__DIR__ . '/.env')) {
    require_once __DIR__ . '/vendor/autoload.php';

    $dotenv = Dotenv\Dotenv::createImmutable(__DIR__);
    $dotenv->safeLoad();
    
    // Halts execution automatically if variables are missing or empty
    $dotenv->required(['CIHL_MAIL_USER', 'CIHL_MAIL_PASSWORD'])->notEmpty();
}

// 2. Now it is safe to read them into variables
$mailUser = $_ENV['CIHL_MAIL_USER'] ?? $_SERVER['CIHL_MAIL_USER'] ?? '';
$mailPassword = $_ENV['CIHL_MAIL_PASSWORD'] ?? $_SERVER['CIHL_MAIL_PASSWORD'] ?? '';
