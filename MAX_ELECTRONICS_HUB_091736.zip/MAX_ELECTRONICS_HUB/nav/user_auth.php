<?php 
if (session_status() == PHP_SESSION_NONE) { 
    session_start(); 

    // Set the success alert array
$_SESSION['alerts'][] = [
    'type' => 'success',
    'message' => 'Password reset successful! You can now login.'
];

// Set the login form to open automatically
$_SESSION['active_form'] = 'login';
$_SESSION['login_return']=
$_SESSION['REQUEST_URI'];

// Redirect back to your main page
header("Location: ". $redirect);
exit();
} 

// Receive variables from session or give default values to prevent errors
$fname = $_SESSION['fname'] ?? null; 
$lname = $_SESSION['lname'] ?? null; 
$alerts = $_SESSION['alerts'] ?? [];
//Remove alerts from the session immediately 
//To be displayed only once
unset($_SESSION['alerts']);
?>

<?php 
foreach ($alerts as $alert): ?>
    <div class='alert <?= htmlspecialchars($alert['type'] ?? 'info') ?>'>
        <?= htmlspecialchars($alert['message'] ?? '') ?>
    </div>
<?php endforeach; ?>

<?php 
$active_form = $_SESSION['active_form'] ?? ''; 
$isloggedin = isset($_SESSION['fname']); 

// Block unauthorized access to pages
function check_login() { 
    # FIX 3: Read $_SESSION directly (it is a global supervariable)
    if (!isset($_SESSION['fname'])) { 
        header("Location: login.php"); 
        exit(); 
    }
} 

// Register login data into the session
function login_user($fname, $lname, $alerts, $active_form) { 
    $_SESSION['fname'] = $fname; 
    $_SESSION['lname'] = $lname; 
    $_SESSION['alerts'] = $alerts; 
    $_SESSION['active_form'] = $active_form; 
    $redirect=$_SESSION['login_return'] ??
    'index.php';
    unset($_SESSION['login_return']);
    header("Location: ".$redirect); exit;
} 

if ($fname !== null && $lname !== null) { 
    $_SESSION['fullname'] = $fname . ' ' . $lname; 
} 
?> 


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Community Health org</title>
  <link rel="stylesheet" href="http://localhost/MAX_ELECTRONICS_HUB/style.css">
  <link href='https://cdn.boxicons.com/3.0.6/fonts/basic/boxicons.min.css' rel='stylesheet'>
  <link href='https://cdn.boxicons.com/3.0.6/fonts/brands/boxicons-brands.min.css' rel='stylesheet'>
  <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
  
  <script type="text/javascript">
    // Fixed: Removed invalid history.forward() method
    window.onload = function() {
      // Pass PHP authentication state to JavaScript safely
      const isLoggedIn = <?php echo $isLoggedIn ? 'true' : 'false'; ?>;
      if (isLoggedIn) {
          console.log("User is securely logged in.");
      } else {
          // Optional: redirect to login if page requires auth
          // window.location.href = "/login"; 
      }
    };

    function myFunction() {
      alert("Function executed without refresh!");
    }

const isAuthenticated = <?php echo isset($_SESSION['user_id']) ? 'true' : 'false'; ?>;

if (isAuthenticated) {
    authModal.classList.remove('show', 'slide');

    if (loginLink) {
        loginLink.addEventListener('click', e => e.preventDefault());
    }

    if (registerLink) {
        registerLink.addEventListener('click', e => e.preventDefault());
    }
}
  // Check if the user has already seen the alert during this session
  if (!sessionStorage.getItem('hasLoggedInAlerted')) {
      
      // Trigger your alert or notification modal
      alert();
      
      // Set the flag so it won't fire again until the next login/session
      sessionStorage.setItem('hasLoggedInAlerted', 'true');
  }

  </script>
</head>

<body>
  <header>
    <a href="http://localhost/MAX_ELECTRONICS_HUB/admin/adm.php"><img src="http://localhost/MAX_ELECTRONICS_HUB/CIHL.jpg" alt="CIHL Logo"></a>

    <nav>
      <ul>
        <li><a href="http://localhost/MAX_ELECTRONICS_HUB/index.php">HOME</a></li>
        <li><a href="#">ABOUT</a>
          <ul>
            <li><a href="http://localhost/MAX_ELECTRONICS_HUB/nav/About.php#:~:text=Mission">Mission</a></li>
            <li><a href="http://localhost/MAX_ELECTRONICS_HUB/nav/About.php#:~:text=Vision">Vision</a></li>
            <li><a href="http://localhost/MAX_ELECTRONICS_HUB/nav/About.php#:~:text=Vision">Objectives</a></li>
            <li><a href="http://localhost/MAX_ELECTRONICS_HUB/nav/About.php#:~:text=Establishment">Establishment</a></li>
            <li><a href="http://localhost/MAX_ELECTRONICS_HUB/nav/About.php#:~:text=Programs">Programs</a></li>
          </ul>
        </li>
        <li><a href="#">COLLECTION</a>
          <ul>
            <li><a href="http://localhost/MAX_ELECTRONICS_HUB/nav/news.php">News</a></li>
            <li><a href="http://localhost/MAX_ELECTRONICS_HUB/nav/events.php">Events</a></li>
            <li><a href="https://www.weathercrave.com/weather-forecast-tanzania/city-592872/weather-forecast-mufindi-today">Weather</a></li>
            <li><a href="http://localhost/MAX_ELECTRONICS_HUB/nav/internship.php">Internship</a></li>
            <li><a href="http://localhost/MAX_ELECTRONICS_HUB/nav/donation.php">Donations</a></li>
            <li><a href="http://localhost/MAX_ELECTRONICS_HUB/nav/volunteer.php">Volunteering</a></li>
          </ul>
        </li>
        <li><a href="http://localhost/MAX_ELECTRONICS_HUB/nav/Contacts.php">CONTACTS</a>
          <ul>
            <li><a href="http://localhost/MAX_ELECTRONICS_HUB/nav/Contacts.php">Phone</a></li>
            <li><a href="http://localhost/MAX_ELECTRONICS_HUB/nav/Contacts.php">Email</a></li>
            <li><a href="http://localhost/MAX_ELECTRONICS_HUB/nav/Contacts.php">Facebook</a></li>
            <li><a href="http://localhost/MAX_ELECTRONICS_HUB/nav/Contacts.php">Whatsapp</a></li>
          </ul>
        </li>
      </ul>
    </nav>

    <div class="user-auth">
      <?php if (!empty($fname)): ?>
        <div class="profile-box">
          <div class="avatar-circle"><?=strtoupper($fname[0]);?></div>
          <div class="dropdown">
            <a href="Application.php">Applications</a>
            <a href="#">My downloads</a>
            <a href="logout.php">Logout</a>
        </div> <!-- Fixed: Added missing closing div for dropdown -->
        </div>
      <?php else: ?>
        <button type="button" class="login-btn-modal">Login</button>
      <?php endif; ?>
    </div>
  </header>
   
  <?php if (!empty($alerts)): ?>
    <div class="alert-box">
      <?php foreach ($alerts as $alert): ?>
        <div class="alert <?=$alert['type'];?>">
          <i class='bx <?= $alert['type']==='success'?'bx-check-circle':'bx-x-circle';?>'></i>
          <span><?= $alert['message']; ?></span>
        </div>
      <?php endforeach;?>
    </div>
  <?php endif; ?>

  <div class="auth-modal <?= $active_form ==='register'?'show slide':($active_form ==='login'?'show':''); ?>">
    <button type="button" class="close-btn-modal">x</button>
    
    <div class="form-box login">
      <h2>Login</h2>
      <form action="auth_process.php" method="POST">
        <div class="input-box">
          <input type="email" name="email" placeholder="Email" required>
          <i class='fa-solid fa-envelope input-icon'></i>  
        </div>
        <div class="input-box">
          <input type="password" name="password" placeholder="Password" required>
           <i class='fa-solid fa-eye input-icon' id='togglePassword'></i>  
        </div>
        <button type="submit" name="login_btn" class="btn">Login</button>
        <p align="center"> Don't have an account? <a href="#" class="register-link">Register</a><br>You forgot a password? <a href="res/foget.php">Reset</a></p>
      </form>
      <?php
      if (isset($_GET['newpwd']) && $_GET['newpwd'] == "passwordupdated") {
          echo '<div class="password-success-alert"><i class="bx bx-check-circle"></i><span>Password reset successful! </span></div>'; 
      }
      ?>
    </div>

    <div class="form-box register">
      <h2>Register</h2>
      <form action="auth_process.php" method="POST">
        <div class="input-box">
          <input type="text" name="fname" placeholder="First Name" required>
           <i class='fa-solid fa-user input-icon'></i>   
        </div>
        <div class="input-box">
          <input type="text" name="lname" placeholder="Last Name" required>
           <i class='fa-solid fa-user input-icon'></i>   
        </div>
        <div class="input-box">
          <input type="email" name="email" placeholder="email" required>
           <i class='fa-solid fa-envelope input-icon'></i>  
        </div>
        <div class="input-box">
          <input type="password" name="password" placeholder="password" required>
           <i class='fa-solid fa-eye input-icon'></i>   
        </div>
        <button type="submit" name="register_btn" class="btn">Register</button>
        <p align="center"> Already have an account? <a href="#" class="login-link">Login</a></p>
      </form>
    </div> 
  </div> 
        
  <script src="script.js"></script>
</body>
</html>
