<?php
// 1. Initialize session and verify data injection
session_start();

// 2. Include the core FPDF library 
require('fpdf.php');

class DonationPDF extends FPDF {
    // Page header configuration
    function Header() {
        $this->SetFont('Arial', 'B', '16');
        $this->Cell(0, 10, 'DONATION REQUEST FORM', 0, 1, 'C');
        $this->SetFont('Arial', 'I', '10');
        $this->MultiCell(0, 5, 'Fill the form with correct details as per instructions on each field, attach all the necessary documents, then verify the details before you submit.', 0, 'C');
        $this->Ln(10); // Spacing
    }

    // Page footer configuration
    function Footer() {
        $this->SetY(-15);
        $this->SetFont('Arial', 'I', 8);
        $this->Cell(0, 10, 'Page ' . $this->PageNo() . '/{nb}', 0, 0, 'C');
    }

    // Custom helper to build clean form rows
    function FormRow($label, $value) {
        $this->SetFont('Arial', 'B', 11);
        $this->Cell(55, 8, ucwords($label) . ':', 1, 0, 'L');
        $this->SetFont('Arial', '', 11);
        $this->Cell(0, 8, ' ' . $value, 1, 1, 'L');
    }
}

// 3. Check if form data was actually posted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    // Sanitize inbound inputs to prevent XSS/vulnerabilities
    $firstname    = htmlspecialchars($_POST['firstname'] ?? '');
    $middlename   = htmlspecialchars($_POST['middlename'] ?? '');
    $lastname     = htmlspecialchars($_POST['lastname'] ?? '');
    $email        = htmlspecialchars($_POST['email'] ?? '');
    $pnumber_a    = htmlspecialchars($_POST['pnumber_a'] ?? '');
    $organisation = htmlspecialchars($_POST['organisation'] ?? '');
    $nation       = htmlspecialchars($_POST['nation'] ?? '');

    // 4. Construct the PDF Document Structure
    $pdf = new DonationPDF();
    $pdf->AliasNbPages();
    $pdf->AddPage();
    
    // Document Subheading Section
    $pdf->SetFont('Arial', 'B', 13);
    $pdf->Cell(0, 10, 'Personal Information', 0, 1, 'L');
    $pdf->Ln(2);

    // Populate Key-Value Form Blocks
    $pdf->FormRow('first name', $firstname);
    $pdf->FormRow('middle name', $middlename);
    $pdf->FormRow('last name', $lastname);
    $pdf->FormRow('email address', $email);
    $pdf->FormRow('phone number', $pnumber_a);
    $pdf->FormRow('organisation', $organisation);
    $pdf->FormRow('country', $nation);

    // 5. Output PDF straight to user's web browser for download
    $pdf->Output('D', 'donation_request_' . time() . '.pdf');
    exit;
} else {
    // Redirect user back to the form if page is accessed directly
    header("Location: don_form.php");
    exit;
}
?>
<?php
session_start();
require('fpdf.php'); // Include the PDF library

if ($_SERVER["REQUEST_METHOD"] == "POST") {
   // Sanitize inputs
    $fname = trim($_POST['firstname']);
    $mname = trim($_POST['middlename']);
    $lname = trim($_POST['lastname']);
    $email = filter_var(trim($_POST['email']), FILTER_SANITIZE_EMAIL);
    $phone = trim($_POST['pnumber_a']);
    $org   = trim($_POST['organisation']);
    $country = trim($_POST['nation']);
    $category = trim($_POST['categories']);
    $amount = trim($_POST['amount']);
    $payment = trim($_POST['payment']);
    $comment = trim($_POST['comment']);

    // 5. Basic Validation
    if (empty($fname) || empty($email) || empty($country) || empty($category)) {
        $_SESSION['status'] = "Please fill in all required fields.";
        header("Location: don_form.php");
        exit();
    }

    // 6. Use Prepared Statement for Security
    $sql = "INSERT INTO donation_requests (firstname, middlename, lastname, email, phone, organisation, country, category, amount, payment, comment) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    $stmt = $conn->prepare($sql);

    // Corrected: Added quotes around types string "sssssssssss"
    // NOTE: Ensure amount/payment are strings or change 's' to 'i'/'d' for integers/doubles
    $stmt->bind_param("sssssssssss", $fname, $mname, $lname, $email, $phone, $org, $country, $categories, $amount, $payment, $comment);

    if ($stmt->execute()) {http://localhost/MAX_ELECTRONICS_HUB/Application.php"; // Update with your actual URL
    $timeout_milliseconds = 3000;  // 3 seconds

    echo <<<HTML
    <link href='https://cdn.boxicons.com/3.0.6/fonts/brands/boxicons-brands.min.css' rel='stylesheet'>
        <link href='https://cdn.boxicons.com/3.0.6/fonts/basic/boxicons.min.css' rel='stylesheet'>
    <link href='unpkg.com' rel='stylesheet'>
    
    <style>
        .success-wrapper {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 80vh;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .success-card {
            background-color: #e0f2f1;
            color: #2e7d32;
            padding: 40px;
            border-radius: 15px;
            text-align: center;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            border: 1px solid #a5d6a7;
            max-width: 500px;
        }
        .success-card i {
            font-size: 4rem;
            display: block;
            margin-bottom: 15px;
        }
        .success-card h3 { margin: 0; font-size: 1.5rem; }
        .success-card p { color: #555; margin-top: 10px; }
    </style>

    <div class="success-wrapper">
        <div class="success-card">
            <i class='bx bx-check-circle'></i>
            <h3>Thanks a lot!</h3>
            <p>Your application has been uploaded successfully.<br> 
            <strong>You will receive a response message in your email shortly.....</strong></p>
        </div>
    </div>

    <script>
    // Configuration: Set redirect back to form or home
    const redirectUrl = "http://localhost/MAX_ELECTRONICS_HUB"; 
    const timeout = 5000; // Longer delay for errors so they can read the message

    setTimeout(function() {
        window.location.href = redirectUrl;
    }, timeout);
    </script>
    
    HTML;

    } else {
    echo <<<HTML
    <link href='https://cdn.boxicons.com/3.0.6/fonts/brands/boxicons-brands.min.css' rel='stylesheet'>
        <link href='https://cdn.boxicons.com/3.0.6/fonts/basic/boxicons.min.css' rel='stylesheet'>
    <link href='unpkg.com' rel='stylesheet'>
    <style>
        .error-wrapper {
        display: flex;
        justify-content: center;
        align-items: center;
        height: 80vh;
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        .error-card {
        background-color: #ffebee; /* Light red background */
        color: #c62828;            /* Dark red text */
        padding: 40px;
        border-radius: 15px;
        text-align: center;
        box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        border: 1px solid #ffcdd2;
        max-width: 500px;

        }
        /* Icon styling */
        .error-card i {
        font-size: 4rem;
        display: block;
        margin-bottom: 15px;
        }
        .error-card h3 { margin: 0; font-size: 1.5rem; }
        .http://localhost/MAX_ELECTRONICS_HUB/Application.phpn-top: 10px; }
    
        /* Retry Button (Optional but helpful for errors) */
        .retry-btn {
        margin-top: 20px;
        display: inline-block;
        padding: 10px 20px;
        background-color: #c62828;
        color: white;
        text-decoration: none;
        border-radius: 5px;
        font-weight: bold;
        }
    </style>

    <div class="error-wrapper">
    <div class="error-card">
        <!-- Error icon (X circle) -->
        <i class='bx bx-x-circle'></i>
        <h3>Submission Failed</h3>
        <p>We encountered an error while processing your application.<br> 
        <strong>Redirecting you back to try again...</strong></p>
    </div>
    </div>

    <script>
    // Configuration: Set redirect back to form or home
    const redirectUrl = "http://localhost/MAX_ELECTRONICS_HUB/Application.php"; 
    const timeout = 5000; // Longer delay for errors so they can read the message

    setTimeout(function() {
        window.location.href = redirectUrl;
    }, timeout);
    </script>
    HTML;

    }
    $stmt->close();
    $conn->close();
}

    // 3. Clear output buffers to prevent PDF file corruption
    if (ob_get_length()) ob_clean();

    // 4. Generate and force download the PDF document
    $pdf = new FPDF();
    $pdf->AddPage();
    $pdf->SetFont('Arial', 'B', 16);
    $pdf->Cell(40, 10, 'Donation Request: ' . $firstname);
    
    // Outputs file directly to browser for download
    $pdf->Output('D', 'donation_request.pdf'); 
    exit;
}
?>
