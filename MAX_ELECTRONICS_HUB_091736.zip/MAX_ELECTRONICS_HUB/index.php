<?php
session_start();
$cartCount = array_sum($_SESSION['cart'] ?? []);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>MAX ELECTRONICS HUB | Electronics Accessories</title>
<link rel="stylesheet" href="style.css">
<link rel="stylesheet" href="https://cdn.boxicons.com/3.0.6/fonts/basic/boxicons.min.css">
</head>
<body>
<?php include 'header.php'; ?>

<section class="hero">
  <div class="hero-content">
    <span class="badge">ONLINE ELECTRONICS STORE</span>
    <h1>MAX ELECTRONICS HUB</h1>
    <p>Quality electronics accessories at affordable prices. Shop chargers, cables, earphones, power banks, phone accessories and more.</p>
    <div class="hero-actions">
      <a class="btn primary" href="products.php">Shop Now</a>
      <a class="btn secondary" href="contacts.php">Contact Us</a>
    </div>
  </div>
</section>

<section class="categories container">
  <h2>Shop by Category</h2>
  <div class="category-grid">
    <a href="products.php?category=Chargers">🔌 <span>Chargers</span></a>
    <a href="products.php?category=Cables">🔗 <span>Cables</span></a>
    <a href="products.php?category=Audio">🎧 <span>Audio</span></a>
    <a href="products.php?category=Power">🔋 <span>Power Banks</span></a>
    <a href="products.php?category=Phone Accessories">📱 <span>Phone Accessories</span></a>
  </div>
</section>

<section class="features container">
  <div><strong>✓ Quality Products</strong><span>Carefully selected accessories</span></div>
  <div><strong>✓ Easy Ordering</strong><span>Order online in a few steps</span></div>
  <div><strong>✓ Customer Support</strong><span>We are ready to help</span></div>
</section>

<section class="container promo">
  <div>
    <span class="badge">MAX ELECTRONICS HUB</span>
    <h2>Power your everyday technology.</h2>
    <p>Find practical accessories for phones, laptops, tablets and other devices.</p>
  </div>
  <a class="btn primary" href="products.php">View Products</a>
</section>

<?php include 'footer.php'; ?>
</body>
</html>