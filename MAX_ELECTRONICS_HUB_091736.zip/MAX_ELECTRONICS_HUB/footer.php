<footer class="footer">
  <div class="container footer-grid">
    <div><h3>MAX ELECTRONICS HUB</h3><p>Your online store for reliable electronics accessories.</p></div>
    <div><h4>Shop</h4><a href="products.php">All Products</a><a href="cart.php">Shopping Cart</a></div>
    <div><h4>Support</h4><a href="about.php">About Us</a><a href="contacts.php">Contact Us</a></div>
  </div>
  <div class="copyright">© <?= date('Y') ?> MAX ELECTRONICS HUB. All rights reserved.</div>
</footer>