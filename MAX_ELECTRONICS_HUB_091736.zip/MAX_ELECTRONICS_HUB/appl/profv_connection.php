
<?php
// Define configuration variables for redirection

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // 1. Capture text inputs from $_POST
    $firstname = $_POST['firstname'] ?? "";
    $middlename = $_POST['middlename'] ?? "";
    $lastname = $_POST['lastname'] ?? "";
    $email = $_POST['email'] ??"" ;
    $pnumber_a = $_POST['pnumber_a'] ??"";
    $proffesional = $_POST['proffesional'] ??"";
    $speciality = $_POST['speciality'] ??"";
    $regnum = $_POST['regnum'] ??"";
    $nation = $_POST['nation'] ??"";
    $passnum = $_POST['passnum'] ??"";
    $comment = $_POST['comment'] ??"";
    

    // Database connection details
    $servername = 'localhost';
    $username = 'root';
    $password = ''; 
    $dbname = 'appl_db';

    // Create connection
    $conn = new mysqli($servername,$username,$password,$dbname);

    // 2. Process Files
    $target_dir = "upload/";
    $file_inputs = ["fileUpload","fileUpload1","fileUpload2"];
    $paths = [];

    foreach ($file_inputs as $input_name) {
        if (!empty($_FILES[$input_name]["name"])) {
            $file_name = time() . "_" . basename($_FILES[$input_name]["name"]);
            $target_file = $target_dir . $file_name;
            
            if (move_uploaded_file($_FILES[$input_name]["tmp_name"], $target_file)) {
                $paths[] = $target_file;
            } else {
                $paths[] = null;
            }
        } else {
            $paths[] = null;
        }
    }

    // 3. One single INSERT for all data
    $sql = "INSERT INTO profv_form (firstname,middlename,lastname,email,pnumber_a,proffesional,speciality,regnum,nation,passnum,file_path,file_path1,file_path2,comment) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
   
     // FIX: Pass the $sql variable into prepare()
    $stmt = $conn->prepare($sql);

    if ($stmt === false) {
        die("Prepare failed: " . htmlspecialchars($conn->error));
    }

    // Bind the 14 strings(11 data strings and 3 file attachments)
    $stmt->bind_param("ssssssssssssss",$firstname,$middlename,$lastname,$email,$pnumber_a,$proffesional,$speciality,$regnum,$nation,$passnum,$paths[0],$paths[1],$paths[2],$comment);

    if ($stmt->execute( )) {

    // Configuration
    $redirect_url = "http://localhost/MAX_ELECTRONICS_HUB/appl/appl.php"; // Update with your actual URL
    $timeout_milliseconds = 3000;  // 3 seconds

    echo <<<HTML
    <link href='https://cdn.boxicons.com/3.0.6/fonts/brands/boxicons-brands.min.css' rel='stylesheet'>
        <link href='https://cdn.boxicons.com/3.0.6/fonts/basic/boxicons.min.css' rel='stylesheet'>
    <link href='unpkg.com' rel='stylesheet'>
    
    <style>
        .success-wrapper {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 80vh;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .success-card {
            background-color: #e0f2f1;
            color: #2e7d32;
            padding: 40px;
            border-radius: 15px;
            text-align: center;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            border: 1px solid #a5d6a7;
            max-width: 500px;
        }
        .success-card i {
            font-size: 4rem;
            display: block;
            margin-bottom: 15px;
        }
        .success-card h3 { margin: 0; font-size: 1.5rem; }
        .success-card p { color: #555; margin-top: 10px; }
    </style>

    <div class="success-wrapper">
        <div class="success-card">
            <i class='bx bx-check-circle'></i>
            <h3>Success!</h3>
            <p>Your application has been uploaded successfully.<br> 
            <strong>Please wait, redirecting to payment...</strong></p>
        </div>
    </div>

    <script>
    // Configuration: Set redirect back to form or home
    const redirectUrl = "http://localhost/MAX_ELECTRONICS_HUB/appl/$$&.php"; 
    const timeout = 5000; // Longer delay for errors so they can read the message

    setTimeout(function() {
        window.location.href = redirectUrl;
    }, timeout);
    </script>
    
    HTML;

    } else {

    echo <<<HTML
    <link href='https://cdn.boxicons.com/3.0.6/fonts/brands/boxicons-brands.min.css' rel='stylesheet'>
        <link href='https://cdn.boxicons.com/3.0.6/fonts/basic/boxicons.min.css' rel='stylesheet'>
    <link href='unpkg.com' rel='stylesheet'>
    <style>
        .error-wrapper {
        display: flex;
        justify-content: center;
        align-items: center;
        height: 80vh;
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        .error-card {
        background-color: #ffebee; /* Light red background */
        color: #c62828;            /* Dark red text */
        padding: 40px;
        border-radius: 15px;
        text-align: center;
        box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        border: 1px solid #ffcdd2;
        max-width: 500px;

        }
        /* Icon styling */
        .error-card i {
        font-size: 4rem;
        display: block;
        margin-bottom: 15px;
        }
        .error-card h3 { margin: 0; font-size: 1.5rem; }
        .error-card p { color: #555; margin-top: 10px; }
    
        /* Retry Button (Optional but helpful for errors) */
        .retry-btn {
        margin-top: 20px;
        display: inline-block;
        padding: 10px 20px;
        background-color: #c62828;
        color: white;
        text-decoration: none;
        border-radius: 5px;
        font-weight: bold;
        }
    </style>

    <div class="error-wrapper">
    <div class="error-card">
        <!-- Error icon (X circle) -->
        <i class='bx bx-x-circle'></i>
        <h3>Submission Failed</h3>
        <p>We encountered an error while processing your application.<br> 
        <strong>Redirecting you back to try again...</strong></p>
    </div>
    </div>

    <script>
    // Configuration: Set redirect back to form or home
    const redirectUrl = "http://localhost/MAX_ELECTRONICS_HUB/appl/appl.php"; 
    const timeout = 5000; // Longer delay for errors so they can read the message

    setTimeout(function() {
        window.location.href = redirectUrl;
    }, timeout);
    </script>
    HTML;

    }

    $stmt->close();
    // Close connection outside the IF or inside depending on if you have more logic
    $conn->close();
}
    ?>
