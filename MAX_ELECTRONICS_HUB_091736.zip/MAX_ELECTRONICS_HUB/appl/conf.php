

<?php
// conf.php

// 1. Load Composer autoloader
$autoloader = __DIR__ . '/vendor/autoload.php';

if (!file_exists($autoloader)) {
    die("Configuration Error: Composer autoloader not found. Run 'composer install' in the project directory.");
}

require_once $autoloader;

try {
    // 2. Load the .env file from the current directory
    $dotenv = Dotenv\Dotenv::createImmutable(__DIR__);
    $dotenv->load();
    
    // 3. Optional Safety Check: Ensure critical variables are not missing
    $dotenv->required([
        'CIHL_MAIL_USER', 
        'CIHL_MAIL_PASSWORD', 
        'CIHL_PAYPAL_URL', 
        'CIHL_CREDIT_CARD_URL'
    ])->notEmpty();

} catch (Dotenv\Exception\ValidationException $e) {
    // Fails instantly if variables exist in .env but are completely empty strings
    die("Configuration Error: Missing required environment variable values. " . $e->getMessage());
} catch (Exception $e) {
    // Fails if the physical .env file itself is completely missing
    die("Configuration Error: Could not load the configuration file. Ensure .env exists. " . $e->getMessage());
}
