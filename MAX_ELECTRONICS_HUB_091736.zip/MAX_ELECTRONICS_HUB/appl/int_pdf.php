<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';
// 1. Initialize session and verify data injection
session_start();

// 2. Include the core FPDF library 
require('fpdf.php');

class InternshipPDF extends FPDF {
    // Page header configuration
    function Header() {
         // Display the header only onpage 1
        if ($this->PageNo() !=1) {
            return;
        }
         // Add heading
        $this->Ln(26);
        //Organisation name
        $this->SetFont("Arial", "B", 16);
        $this->Cell(0, 8, 'COMMUNITY INITIATIVES FOR HEALTHY LIFE(CIHL)',0, 1, 'C');

        // Form Title
        $this->SetFont("Helvetica", "B", 14);
        $this->Cell(0, 8, "INTERNSHIP APPLICATION FORM", 0, 1, "C");
        
        // Subtitle instructions
        $this->Ln(10);
        $this->SetFont("Helvetica", "I", 12);
        $this->SetLeftMargin(30);
        $instructions = "This is an official digital copy of your submitted application form for medical internship in Tanzania.";
        $this->SetX(20);
        $this->MultiCell(140, 4, $instructions, 0, "C");
        $this->SetLeftMargin(10);
        $this->Ln(8);
        //Full width header line
        $this->SetDrawColor(0, 102, 204);
        $this->SetLinewidth(0,8);
        $this->Line(10, 30, 200, 30);
        $this->Ln(12);
    }
    function SectionHeader($title){
        $this->SetFont('Arial','B',12);
        $this->SetFillColor(230,230,230);
        $this->Cell(0, 8, $title, 0, 1, "L", true);
        $this->Ln(2);
    }

    function DrawField($label, $value, $width = 60, $margin = 10) {
    // Save current positions to force vertical alignment
    $startX = $this->GetX();
    $startY = $this->GetY();
    
    // 1. Draw the Label row
    $this->SetFont('Arial', 'B', 10);
    $this->Cell($width, 6, $label, 0, 0, 'L'); 
    
    // Move cursor exactly below the label
    $this->SetXY($startX, $startY + 6);
    
    // 2. Draw the Value row directly beneath
    $this->SetFont('Arial', '', 10);
    $this->Cell($width, 8, $value, 0, 0, 'L');
    
    // Reset cursor to the top-right of this field block for the next column
    $this->SetXY($startX + $width + 4, $startY);
}


    // Two-column row layout method
    function DrawTwoFields($label1, $value1, $label2, $value2, $margin = 10, $fieldWidth = 90, $spacing = 10)
    {
        // Labels
        $this->SetFont('Arial', 'B', 10);
        $this->SetX($margin);
        $this->Cell($fieldWidth, 6, $label1, 0, 0);
        $this->Cell($spacing, 6, '', 0, 0);
        $this->Cell($fieldWidth, 6, $label2, 0, 1);

        // Values
        $this->SetFont('Arial', '', 10);
        $this->SetX($margin);
        $this->Cell($fieldWidth, 8, $value1, 0, 0);
        $this->Cell($spacing, 8, '', 0, 0);
        $this->Cell($fieldWidth, 8, $value2, 0, 1);

        $this->Ln(4);
    }

    // Three-column row layout method
    function DrawThreeFields($label1, $value1, $label2, $value2, $label3, $value3, $margin = 10, $fieldWidth = 56, $spacing = 10)
    {
        // Labels
        $this->SetFont('Arial', 'B', 11);
        $this->SetX($margin);
        $this->Cell($fieldWidth, 6, $label1, 0, 0);
        $this->Cell($spacing, 6, '', 0, 0);
        $this->Cell($fieldWidth, 6, $label2, 0, 0);
        $this->Cell($spacing, 6, '', 0, 0);
        $this->Cell($fieldWidth, 6, $label3, 0, 1);

        // Values
        $this->SetFont('Arial', '', 10);
        $this->SetX($margin);
        $this->Cell($fieldWidth, 8, $value1, 0, 0);
        $this->Cell($spacing, 8, '', 0, 0);
        $this->Cell($fieldWidth, 8, $value2, 0, 0);
        $this->Cell($spacing, 8, '', 0, 0);
        $this->Cell($fieldWidth, 8, $value3, 0, 1);

        $this->Ln(4);
    }

     function CheckPageSpace($height = 20)
    {
        if ($this->GetY() + $height >($this->GetPageHeight() - 35)) {
            $this->AddPage();
        }
    }

     //Footer
    function Footer()
    {
        $this->SetY(-30);
        //Fool-width footer line
        $this->SetDrawColor(0, 102, 204);
        $this->SetLinewidth(0,8);
        $this->Line(10,
        $this->GetY(), 200,
        $this->GetY());

        $this->Ln(2);
        $this->SetFont('Arial','I',8);
        $this->Cell(0, 5, 'Community Initiatives for Healthy Life(CIHL)', 0, 1, 'C');
        $this->Cell(0, 5, 'Page '.
        $this->PageNo(). '/{nb}', 0, 0, 'C');

    }
}

// Database connection details
$servername = 'localhost';
$username   = 'root';
$password   = ''; 
$dbname     = 'appl_db';

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if form data was actually posted
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // 2. Process Files
    $target_dir = "uploads/";
    
    // make sure you have a forder
    if (!file_exists($target_dir)) {
        mkdir($target_dir, 0777, true);
    }

    $file_inputs = ["fileUpload", "fileUpload1", "fileUpload2", "fileUpload3"];

    $paths = array_map(function($input) use ($target_dir) {
        if (empty($_FILES[$input]["name"])) return null;
        
        $file_name = time() . "_" . basename($_FILES[$input]["name"]);
        $target_file = $target_dir . $file_name;
        return move_uploaded_file($_FILES[$input]["tmp_name"], $target_file) ? $target_file : null;
    }, $file_inputs);


    // 1. Capture text inputs from $_POST
    $firstname = htmlspecialchars(trim($_POST['firstname'] ?? ''));
    $middlename = htmlspecialchars(trim($_POST['middlename'] ?? ''));
    $lastname= htmlspecialchars(trim($_POST['lastname'] ?? ''));
    $DoB= htmlspecialchars(trim($_POST['DoB'] ?? ''));
    $sex= htmlspecialchars(trim($_POST['sex'] ?? ''));
    $height= htmlspecialchars(trim($_POST['height'] ?? ''));
    $nationality= htmlspecialchars(trim($_POST['nationality'] ?? ''));
    $pnumber= htmlspecialchars(trim($_POST['pnumber'] ?? ''));
    $lang= htmlspecialchars(trim($_POST['lang'] ?? ''));
    $email = htmlspecialchars(trim($_POST['email'] ?? ''), FILTER_SANITIZE_EMAIL);
    $pnumber_a = htmlspecialchars(trim($_POST['pnumber_a'] ?? ''));
    $hnumber = htmlspecialchars(trim($_POST['hnumber'] ?? ''));
    $street = htmlspecialchars(trim($_POST['street'] ?? ''));
    $t_city = htmlspecialchars(trim($_POST['t_city'] ?? ''));
    $country = htmlspecialchars(trim($_POST['country'] ?? ''));
    $cu_study = htmlspecialchars(trim($_POST['cu_study'] ?? ''));
    $country_a = htmlspecialchars(trim($_POST['country_a'] ?? ''));
    $c_studied = htmlspecialchars(trim($_POST['c_studied'] ?? ''));
    $yenrolled = htmlspecialchars(trim($_POST['yenrolled'] ?? ''));
    $sID_num = htmlspecialchars(trim($_POST['sID_num'] ?? ''));
    $d_graduated = htmlspecialchars(trim($_POST['d_graduated'] ?? ''));
    $n_referee = htmlspecialchars(trim($_POST['n_referee'] ?? ''));
    $n_univ = htmlspecialchars(trim($_POST['n_univ'] ?? ''));
    $country_b = htmlspecialchars(trim($_POST['country_b'] ?? ''));
    $pnumber_b = htmlspecialchars(trim($_POST['pnumber_b'] ?? ''));
    $email_b = htmlspecialchars(trim($_POST['email_b'] ?? ''));
    $fapplied = htmlspecialchars(trim($_POST['fapplied'] ?? ''));
    $duration = htmlspecialchars(trim($_POST['duration'] ?? ''));
    $d_start = htmlspecialchars(trim($_POST['d_start'] ?? ''));

// 4. Basic Validation
    if (empty($firstname) || empty($email) || empty($country) || empty($yenrolled)) {
        $_SESSION['status'] = "Please fill in all required fields.";
        header("Location: int.php");
        exit();
    }

// 5. Use Prepared Statement for Database Insertion
    $sql = "INSERT INTO appl_form (firstname,middlename,lastname,DoB,sex,height,nationality,pnumber,lang,email,pnumber_a,hnumber,street,t_city,country,cu_study,country_a,c_studied,yenrolled,sID_num,d_graduated,n_referee,n_univ,country_b,pnumber_b,email_b,fapplied,duration,d_start,file_path,file_path1,file_path2,file_path3) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

    // Bind the 33 strings(29 data strings and 4 file attachments)
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssssssssssssssssssssssssssssssss",$firstname,$middlename,$lastname,$DoB,$sex,$height,$nationality,$pnumber,$lang,$email,$pnumber_a,$hnumber,$street,$t_city,$country,$cu_study,$country_a,$c_studied,$yenrolled,$sID_num,$d_graduated,$n_referee,$n_univ,$country_b,$pnumber_b,$email_b,$fapplied,$duration,$d_start,$paths[0],$paths[1],$paths[2],$paths[3]);
   

    if ($stmt->execute()) {
        $stmt->close();
        $conn->close();

// 6. GENERATE PDF IN BACKGROUND AS BASE64 STRING
    $pdf = new InternshipPDF();
    $pdf->AliasNbPages();
    $pdf->SetMargins(10, 8, 10); //Left,Top, Right margins
    $pdf->SetAutoPageBreak(true,35); //Leave 35 mm for footer
    $pdf->AddPage();

if  ($pdf->GetY() + 1 >
    ($pdf->GetPageHeight() - 8)) {
    $pdf->AddPage();
   }

    // Add logo
    $pdf->Image('C:\xampp\htdocs\MAX_ELECTRONICS_HUB\CIHL.jpg', 10, 31, 24);
    $pdf->SetY(75);

    //Applicant photo
    if(!empty($paths[0]) && file_exists($paths[0])) {
        $pdf->Image($paths[0], 170,45, 30, 33); // X, Y, Width,Height
    }
    //Full name below the photo
    $fName = trim($firstname);
    $mInit = !empty($middlename) ? strtoupper(substr(trim($middlename), 0, 1)) . '.' : '';
    $lName = trim($lastname);

    // 2. Unganisha kwa kutumia nafasi safi (Inaweka nafasi tu kama jina lipo)
    $fullName = implode(' ', array_filter([$fName, $mInit, $lName]));

    $pdf->SetFont('Arial', 'B', 6);
    // Photo sits between X=173 and X=200 (173 + 27). 
    // Center the text box by setting X=171.5 with a width of 30.
    // Set Y to 94 so it starts exactly 1mm below the photo container.
    $pdf->SetXY(170.0, 78);

    //Position below the photo
    $pdf->Multicell(30, 4, $fullName, 0, 'C');
    //Start form below the photo
    $pdf->SetY(82);
        
    // Section 1: Applicant Personal Info
    $pdf->SectionHeader("PERSONAL DETAILS");
    $pdf->DrawThreeFields("First Name", $firstname, "Middle Name", $middlename, "Last Name", $lastname);
    $pdf->DrawThreeFields("Date of Birth", $DoB, "Sex", $sex, "Height", $height);
    $pdf->DrawThreeFields("Nationality", $nationality, "Passport Number", $pnumber, "Do you speak English?", $lang);
    

    // Section 2: Contact Information
    $pdf->SectionHeader("CONTACT INFORMATION");
    $pdf->DrawThreeFields("Email", $email, "Phone Number", $pnumber_a, "House Number", $hnumber);
    $pdf->DrawThreeFields("Street", $street, "Town/City", $t_city, "Country", $country);
    
    // Section 3: University/College information
    $pdf->SectionHeader("UNIVERSITY/COLLEGE INFORMATION");
    $pdf->DrawThreeFields("College/University Studied", $cu_study, "Country", $country, "Course Studied", $c_studied);
    $pdf->DrawThreeFields("Year enrolled on studies", $yenrolled, "Student ID Number", $sID_num, "Graduation Date/expected Date", $d_graduated);

    // Section 4: Referees information
    $pdf->SectionHeader("REFEREE'S INFORMATION");
    $pdf->DrawThreeFields("Name of referee", $n_referee, "Name of University/College", $n_univ, "Country", $country_b);
    $pdf->DrawTwoFields("Phone Number", $pnumber_b, "email", $email_b);

    // Section 5: Details of the application
    $pdf->SectionHeader("DETAILS OF THE APPLICATION");
    $pdf->DrawThreeFields("Field applied for internship", $fapplied, "Duration for internship", $duration, "Date expected to start internship", $d_start);

    // Certification Section
    $pdf->SetFont('Arial', '', 10);

    // Tunahifadhi nafasi ya sasa ya X na Y ili kudhibiti muonekano wetu vizuri
    $currentX = $pdf->GetX();
    $currentY = $pdf->GetY();

    // 2. TENGENEZA KISANDUKU CHA KUTEUA (CHECKBOX)
    // Tunajaza rangi ya bluu ndani ya kisanduku (kama kwenye picha yako)
    $pdf->SetFillColor(225, 225, 225); // Rangi ya Bluu (RGB)
    $pdf->Rect($currentX, $currentY + 1, 4, 4, 'DF'); // Kuchora kisanduku cha 4mm x 4mm

    // 3. WEKA ALAMA YA KUTEUA (TICK) NDANI YA KISANDUKU
    $pdf->SetFont('ZapfDingbats', '', 8);
    $pdf->SetTextColor(0,  0,  0); // A tick with black color
    // Alama "4" kwenye fonti ya ZapfDingbats inazalisha alama ya kuteua (✔)
    // Tunasogeza X kwa 0.5mm na Y kwa 1mm ili ikae katikati ya kisanduku
    $pdf->SetXY($currentX + 0.5, $currentY + 1);
    $pdf->Cell(4, 4, '4', 0, 0, 'C');

    // 4. Certification statement 
    // black fonts color
    $pdf->SetTextColor(0, 0, 0);
    $pdf->SetFont('Arial', '', 10);

    // Sogeza nafasi ya kuanzia mbele ya kisanduku (umbali wa 6mm kutoka X ya awali)
    $pdf->SetXY($currentX + 6, $currentY);

    // Maandishi kutoka kwenye picha yako
    $text = "I hereby certify that, to the best of my knowledge, the provided information is true and accurate";

    // Tunatumia MultiCell kwa sababu maandishi ni marefu na yanahitaji kujigawa katika mistari miwili (upana wa 150mm)
    $pdf->MultiCell(150, 5, $text, 0, 'L');

    // Turn PDF into Base64 string for Javascript to execute download
    $pdfData = $pdf->Output('S');
    $base64Pdf = base64_encode($pdfData);
    $filename = 'Internship_Request_' . $firstname . '.pdf';

     $mail = new PHPMailer(true);

try {
    $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com';
    $mail->SMTPAuth = true;

    // Your Gmail account
    $mail->Username = 'initiativescommunity6@gmail.com';

    // Your 16-character Gmail App Password
    $mail->Password = 'muhl ylmf nlkq gfkn';

    $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
    $mail->Port = 465;

    // Sender
    $mail->setFrom('initiativescommunity6@gmail.com', 'CIHL');

    // Applicant's email from the form
    $mail->addAddress($email, $firstname . ' ' . $lastname);

    // Attach generated PDF (optional)
    if (!empty($pdfData)) {
        $mail->addStringAttachment($pdfData, $filename, 'base64', 'application/pdf');
    }

    // Email content
    $mail->isHTML(true);
    $mail->Subject = 'Donation peadge Received';

    $mail->Body = "
    Dear <b>$firstname</b>,<br><br>

    Thank you for applying for medical internship in Tanzamia with the  Community Initiatives for Healthy Life.<br><br>

    We have successfully received your application and it is now under review.<br><br>

    Regards,<br>
    Community Health Initiative
    ";

    $mail->AltBody = "Dear $firstname, Your application has been received successfully.";

    $mail->send();

} catch (Exception $e) {
    error_log("Mailer Error: " . $mail->ErrorInfo);
}


// 7. DISPLAY SUCCESS ALERT CARD HTML
        echo <<<HTML
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Submission Successful</title>
            <link href='https://unpkg.com' rel='stylesheet'>
            <style>
                .success-wrapper {
                    display: flex;
                    justify-content: center;
                    align-items: center;
                    height: 90vh;
                    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                    background-color: #f4f7f6;
                }
                .success-card {
                    background-color: #e0f2f1;
                    color: #2e7d32;
                    padding: 40px;
                    border-radius: 15px;
                    text-align: center;
                    box-shadow: 0 10px 30px rgba(0,0,0,0.1);
                    border: 1px solid #a5d6a7;
                    max-width: 500px;
                    width: 100%;
                }
                .success-card i {
                    font-size: 4.5rem;
                    display: block;
                    margin-bottom: 15px;
                }
                .success-card h3 { margin: 0; font-size: 1.7rem; }
                .success-card p { color: #444; margin-top: 10px; line-height: 1.6; font-size: 1.05rem;}
                
                /* Download button styling */
                .download-btn {
                    display: inline-flex;
                    align-items: center;
                    gap: 8px;
                    background-color: #2e7d32;
                    color: white;
                    padding: 12px 24px;
                    border-radius: 8px;
                    text-decoration: none;
                    font-weight: bold;
                    margin-top: 20px;
                    box-shadow: 0 4px 10px rgba(46, 125, 50, 0.2);
                    transition: background 0.3s ease;
                    cursor: pointer;
                    border: none;
                }
                .download-btn:hover {
                    background-color: #1b5e20;
                }
                .redirect-msg {
                    font-size: 0.85rem;
                    color: #666;
                    margin-top: 15px;
                }
            </style>
        </head>
        <body>

        <div class="success-wrapper">
            <div class="success-card">
                <i class='bx bx-check-circle'></i>
                <h3>Thanks a lot!</h3>
                <p><strong>Your application has been submitted successfully ...</strong></p>
                
                <!-- Manual Download trigger if auto fails -->
                <button class="download-btn" onclick="triggerDownload()">
                    <i class='bx bx-download'></i> Download PDF Form</button>
                
                <div class="redirect-msg">Redirecting you to the payment page...</div>
            </div>
        </div>

        <script>
        const base64Data = "{$base64Pdf}";
        const filename = "{$filename}";

        // Execution logic to download base64 string asset
        function triggerDownload() {
            const linkSource = `data:application/pdf;base64,\${base64Data}`;
            const downloadLink = document.createElement("a");
            downloadLink.href = linkSource;
            downloadLink.download = filename;
            document.body.appendChild(downloadLink);
            downloadLink.click();
            document.body.removeChild(downloadLink);
        }

// 1. Run automatic download on window mount
    window.onload = function() {
    triggerDownload();
            
// 2. Redirect back after 6 seconds to give time for operations
         setTimeout(function() {
            window.location.href = "$$&.php";
            }, 6000);
        };
        </script>
        
        </body>
        </html>
HTML;
        exit();

    } else {
        // Error Display Screen if DB execution fails
        echo <<<HTML
        <!DOCTYPE html>
        <html>
        <head>
            <link href='https://unpkg.com' rel='stylesheet'>
            <style>
                .error-wrapper { display: flex; justify-content: center; align-items: center; height: 80vh; font-family: sans-serif; }
                .error-card { background-color: #ffebee; color: #c62828; padding: 40px; border-radius: 15px; text-align: center; border: 1px solid #ffcdd2; max-width: 500px; }
                .error-card i { font-size: 4rem; display: block; margin-bottom: 15px; }
            </style>
        </head>
    }
HTML;
exit();
 }
}
?>