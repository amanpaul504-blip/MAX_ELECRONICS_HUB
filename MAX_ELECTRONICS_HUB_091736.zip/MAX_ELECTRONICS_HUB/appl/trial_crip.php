<?php
// 1. Include the FPDF library
// Download fpdf.php from fpdf.org and place it in your project directory
require_once('fpdf.php');

// Extend FPDF to create your custom application layout
class InternshipFormPDF extends FPDF {
    function Header() {
        // Form Title
        $this->SetFont("Helvetica", "B", 14);
        $this->Cell(0, 8, "INTERNSHIP APPLICATION RECORD", 0, 1, "C");
        
        // Subtitle instructions
        $this->SetFont("Helvetica", "I", 7);
        $instructions = "This is an official digital copy of your submitted internship application form.";
        $this->MultiCell(0, 4, $instructions, 0, "C");
        $this->Ln(4);
    }

    function SectionHeader($title) {
        // Section banner styling
        $this->SetFillColor(230, 230, 235);
        $this->SetFont("Helvetica", "B", 9);
        $this->Cell(0, 6, $title, 0, 1, "C", true);
        $this->Ln(3);
    }

    function DrawField($label, $value, $width) {
        // Label text
        $this->SetFont("Helvetica", "B", 8);
        $this->Cell($width, 4, $label, 0, 1);
        
        // Capture current positioning
        $current_x = $this->GetX();
        $current_y = $this->GetY();
        
        // Draw Field box container
        $this->SetFillColor(255, 255, 255);
        $this->SetDrawColor(200, 200, 200);
        $this->Rect($current_x, $current_y, $width, 7, 'DF');
        
        // Populate field with user input values
        $this->SetTextColor(50, 50, 50);
        $this->SetFont("Helvetica", "", 8);
        $this->SetXY($current_x + 2, $current_y + 1);
        
        // Handle empty values safely
        $display_text = (!empty($value)) ? $value : "N/A";
        $this->Cell($width - 4, 5, $display_text);
        
        // Reset styles and push cursor position below the generated box
        $this->SetTextColor(0, 0, 0);
        $this->SetXY($current_x, $current_y + 9);
    }
}

if (isset($_POST["submit"])) {
    // 2. Capture text inputs from $_POST
    $firstname   = $_POST['firstname'] ?? "";
    $middlename  = $_POST['middlename'] ?? "";
    $lastname    = $_POST['lastname'] ?? "";
    $DoB         = $_POST['DoB'] ?? "";
    $sex         = $_POST['sex'] ?? "";
    $height      = $_POST['height'] ?? "";
    $nationality = $_POST['nationality'] ?? "";
    $pnumber     = $_POST['pnumber'] ?? "";
    $lang        = $_POST['lang'] ?? "";
    $email       = $_POST['email'] ?? "";
    $pnumber_a   = $_POST['pnumber_a'] ?? "";
    $hnumber     = $_POST['hnumber'] ?? "";
    $street      = $_POST['street'] ?? "";
    $t_city      = $_POST['t_city'] ?? "";
    $country     = $_POST['country'] ?? "";
    $cu_study    = $_POST['cu_study'] ?? "";
    $country_a   = $_POST['country_a'] ?? "";
    $c_studied   = $_POST['c_studied'] ?? "";
    $yenrolled   = $_POST['yenrolled'] ?? "";
    $sID_num     = $_POST['sID_num'] ?? "";
    $d_graduated = $_POST['d_graduated'] ?? "";
    $n_referee   = $_POST['n_referee'] ?? "";
    $n_univ      = $_POST['n_univ'] ?? "";
    $country_b   = $_POST['country_b'] ?? "";
    $pnumber_b   = $_POST['pnumber_b'] ?? "";
    $email_b     = $_POST['email_b'] ?? "";
    $fapplied    = $_POST['fapplied'] ?? "";
    $duration    = $_POST['duration'] ?? "";
    $d_start     = $_POST['d_start'] ?? "";

    // Database connection details
    $servername = 'localhost';
    $username   = 'root';
    $password   = ''; 
    $dbname     = 'appl_db';

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);
    }

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // 3. Process Uploaded Files
    $target_dir = "uploads/";
    
    // Ensure the directories exist
    if (!file_exists($target_dir)) {
        mkdir($target_dir, 0777, true);
    }
    if (!file_exists('receipts/')) {
        mkdir('receipts/', 0777, true);
    }

    $file_inputs = ["fileUpload", "fileUpload1", "fileUpload2", "fileUpload3"];
    $paths = [];

    foreach ($file_inputs as $input_name) {
        if (!empty($_FILES[$input_name]["name"])) {
            $file_name = time() . "_" . basename($_FILES[$input_name]["name"]);
            $target_file = $target_dir . $file_name;
            
            if (move_uploaded_file($_FILES[$input_name]["tmp_name"], $target_file)) {
                $paths[] = $target_file;
            } else {
                $paths[] = null;
            }
        } else {
            $paths[] = null;
        }
    }

    // 4. One single INSERT for all data
    $sql = "INSERT INTO appl_form (firstname,middlename,lastname,DoB,sex,height,nationality,pnumber,lang,email,pnumber_a,hnumber,street,t_city,country,cu_study,country_a,c_studied,yenrolled,sID_num,d_graduated,n_referee,n_univ,country_b,pnumber_b,email_b,fapplied,duration,d_start,file_path,file_path1,file_path2,file_path3) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
   
    $stmt = $conn->prepare($sql);

    if ($stmt === false) {
        die("Prepare failed: " . htmlspecialchars($conn->error));
    }

    // Bind the 33 parameters
    $stmt->bind_param("sssssssssssssssssssssssssssssssss",
        $firstname, $middlename, $lastname, $DoB, $sex, $height, $nationality, $pnumber, $lang, 
        $email, $pnumber_a, $hnumber, $street, $t_city, $country, $cu_study, $country_a, $c_studied, 
        $yenrolled, $sID_num, $d_graduated, $n_referee, $n_univ, $country_b, $pnumber_b, $email_b, 
        $fapplied, $duration, $d_start, $paths[0], $paths[1], $paths[2], $paths[3]
    );

    if ($stmt->execute()) {
        
        // 5. Generate the FPDF Application Document
        $pdf = new InternshipFormPDF("L", "mm", "A4");
        $pdf->SetMargins(10, 10, 10);
        $pdf->AddPage();

        // --- Section 1: Personal Information ---
        $pdf->SectionHeader("Personal Information");
        $start_y = $pdf->GetY();
        $pdf->DrawField("First name", $firstname, 88);
        $pdf->DrawField("Date of Birth", $DoB, 88);
        $pdf->DrawField("Nationality", $nationality, 88);

        $pdf->SetXY(102, $start_y);
        $pdf->DrawField("Middle name", $middlename, 88);
        $pdf->DrawField("Sex", $sex, 88);
        $pdf->DrawField("Passport Number", $pnumber, 88);

        $pdf->SetXY(194, $start_y);
        $pdf->DrawField("Last name", $lastname, 88);
        $pdf->DrawField("Height", $height, 88);
        $pdf->DrawField("Do you speak English?", $lang, 88);
        
        // Explicitly set position below Section 1 to prevent layout overlaps
        $pdf->SetXY(10, $start_y + 30);

        // --- Section 2: Contact Information ---
        $pdf->SectionHeader("Contact Information");
        $start_y = $pdf->GetY();
        $pdf->DrawField("Email", $email, 88);
        $pdf->DrawField("Street", $street, 88);

        $pdf->SetXY(102, $start_y);
        $pdf->DrawField("Phone Number", $pnumber_a, 88);
        $pdf->DrawField("Town/City", $t_city, 88);

        $pdf->SetXY(194, $start_y);
        $pdf->DrawField("House Number", $hnumber, 88);
        $pdf->DrawField("Country", $country, 88);
        
        $pdf->SetXY(10, $start_y + 22);

        // --- Section 3: University/College Information ---
        $pdf->SectionHeader("University/College Information");
        $start_y = $pdf->GetY();
        $pdf->DrawField("College/University studied", $cu_study, 88);
        $pdf->DrawField("Year enrolled for studies", $yenrolled, 88);

        $pdf->SetXY(102, $start_y);
        $pdf->DrawField("Country", $country_a, 88);
        $pdf->DrawField("Student ID Number", $sID_num, 88);

        $pdf->SetXY(194, $start_y);
        $pdf->DrawField("Course studied", $c_studied, 88);
        $pdf->DrawField("Date Graduated or expected", $d_graduated, 88);
        
        $pdf->SetXY(10, $start_y + 22);

        // --- Section 4: Referees Information ---
        $pdf->SectionHeader("Referees Information");
        $start_y = $pdf->GetY();
        $pdf->DrawField("Name of referee from University/College", $n_referee, 88);
        $pdf->DrawField("Phone Number", $pnumber_b, 88);

        $pdf->SetXY(102, $start_y);
        $pdf->DrawField("Name of University/College", $n_univ, 88);
        $pdf->DrawField("Email", $email_b, 88);

        $pdf->SetXY(194, $start_y);
        $pdf->DrawField("Country", $country_b, 88);
        
        $pdf->SetXY(10, $start_y + 22);

        // --- Section 5: Details of the application ---
        $pdf->SectionHeader("Details of the Application");
        $start_y = $pdf->GetY();
        $pdf->DrawField("Field applied for internship", $fapplied, 88);
        
        $pdf->SetXY(102, $start_y);
        $pdf->DrawField("Duration for internship (Weeks)", $duration, 88);
        
        $pdf->SetXY(194, $start_y);
        $pdf->DrawField("Date expected to start internship", $d_start, 88);

        // Save PDF to local system server folder
        $pdf_filename = "receipts/application_" . time() . "_" . $firstname . ".pdf";
        $pdf->Output("F", $pdf_filename);
        }
        // 6. Display Success State Screen Output using Nowdoc to avoid parsing breaks
        echo <<<'HTML'
        <link href='https://boxicons.com' rel='stylesheet'>
        <link href='https://boxicons.com' rel='stylesheet'>
        
        <style>
            .success-wrapper {
                display: flex;
                justify-content: center;
                align-items: center;
                height: 80vh;
                font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            }
            .success-card {
                background-color: #e0f2f1;
                color: #2e7d32;
                padding: 40px;
                border-radius: 15px;
                text-align: center;
                box-shadow: 0 10px 30px rgba(0,0,0,0.1);
                border: 1px solid #a5d6a7;
                max-width: 500px;
            }
        </style>
    </HTML>
    ?>
