<?php
// 1. Initialize session and verify data injection
session_start();

// 2. Include the core FPDF library 
require('fpdf.php');

class DonationPDF extends FPDF {
    // Page header configuration
    function Header() {

         // Add heading
        $this->Ln(26);
        //Organisation name
        $this->SetFont("Arial", "B", 16);
        $this->Cell(0, 8, 'COMMUNITY INITIATIVES FOR HEALTHY LIFE(CIHL)',0, 1, 'C');

        // Form Title
        $this->SetFont("Helvetica", "B", 14);
        $this->Cell(0, 8, "MEDICAL PROFFESIONAL VOLUNTEER REQUEST FORM", 0, 1, "C");
        
        // Subtitle instructions
        $this->Ln(16);
        $this->SetFont("Helvetica", "I", 12);
        $instructions = "This is an official digital copy of your submitted request to volunteer to volunteers to practice in Tanzania Hospitals.";
        $this->MultiCell(0, 4, $instructions, 0, "C");
        $this->Ln(8);
        //Full width header line
        $this->SetDrawColor(0, 102, 204);
        $this->SetLinewidth(0,8);
        $this->Line(10, 30, 200, 30);
        $this->Ln(16);
    }
    function SectionHeader($title){
        $this->SetFont('Arial','B',12);
        $this->SetFillColor(230,230,230);
        $this->Cell(0, 8, $title, 0, 1, "L", true);
        $this->Ln(2);
    }

    // Single-field helper method
    function DrawField($label, $value, $width = 0, $margin = 10) {
        $this->SetX($margin);
        $this->SetFont('Arial', 'B', 10);
        $this->Cell($width, 6, $label, 0, 1); // Label row
        
        $this->SetX($margin);
        $this->SetFont('Arial', '', 10);
        $this->Cell($width, 8, $value, 0, 1); // Value box row
        $this->Ln(4);
    }

    // Three-column row layout method
    function DrawThreeFields($label1, $value1, $label2, $value2, $label3, $value3, $margin = 10, $fieldWidth = 55, $spacing = 10)
    {
        // Labels
        $this->SetFont('Arial', 'B', 10);
        $this->SetX($margin);
        $this->Cell($fieldWidth, 6, $label1, 0, 0);
        $this->Cell($spacing, 6, '', 0, 0);
        $this->Cell($fieldWidth, 6, $label2, 0, 0);
        $this->Cell($spacing, 6, '', 0, 0);
        $this->Cell($fieldWidth, 6, $label3, 0, 1);

        // Values
        $this->SetFont('Arial', '', 10);
        $this->SetX($margin);
        $this->Cell($fieldWidth, 8, $value1, 0, 0);
        $this->Cell($spacing, 8, '', 0, 0);
        $this->Cell($fieldWidth, 8, $value2, 0, 0);
        $this->Cell($spacing, 8, '', 0, 0);
        $this->Cell($fieldWidth, 8, $value3, 0, 1);

        $this->Ln(4);
    }
     //Footer
    function Footer()
    {
        $this->SetY(-34);
        //Fool-width footer line
        $this->SetDrawColor(0, 102, 204);
        $this->SetLinewidth(0.8);
        $this->Line(10,
        $this->GetY(), 200,
        $this->GetY());

        $this->Ln(2);
        $this->SetFont('Arial','I',8);
        $this->Cell(0, 5, 'Community Intiatives for Healthy Life(CIHL)', 0, 1, 'C');
        $this->Cell(0, 5, 'Page '.
        $this->PageNo(). '/{nb}', 0, 0, 'C');

    }
}

// Database connection details
$servername = 'localhost';
$username   = 'root';
$password   = ''; 
$dbname     = 'appl_db';

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// 3. Check if form data was actually posted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $firstname = htmlspecialchars(trim($_POST['firstname'] ?? ''));
    $middlename = htmlspecialchars(trim($_POST['middlename'] ?? ''));
    $lastname = htmlspecialchars(trim($_POST['lastname'] ?? ''));
    $email = htmlspecialchars(trim($_POST['email'] ?? ''), FILTER_SANITIZE_EMAIL);
    $pnumber_a = htmlspecialchars(trim($_POST['pnumber_a'] ?? ''));
    $proffesional = htmlspecialchars(trim($_POST['proffesional'] ?? ''));
    $speciality = htmlspecialchars(trim($_POST['speciality'] ?? ''));
    $regnum = htmlspecialchars(trim($_POST['regnum'] ?? ''));
    $nation = htmlspecialchars(trim($_POST['nation'] ?? ''));
    $passnum = htmlspecialchars(trim($_POST['passnum'] ?? ''));
    $comment = htmlspecialchars(trim($_POST['comment'] ?? ''));

// 4. Basic Validation
    if (empty($fname) || empty($email) || empty($country) || empty($proffesional)) {
        $_SESSION['status'] = "Please fill in all required fields.";
        header("Location: don_form.php");
        exit();
    }

// 5. Use Prepared Statement for Database Insertion
    $sql = "INSERT INTO profv_form (firstname,middlename,lastname,email,pnumber_a,proffesional,speciality,regnum,nation,passnum,file_path,file_path1,file_path2,comment) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
   

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssssssssssssss",$firstname,$middlename,$lastname,$email,$pnumber_a,$proffesional,$speciality,$regnum,$nation,$passnum,$paths[0],$paths[1],$paths[2],$comment);

    if ($stmt->execute()) {
        $stmt->close();
        $conn->close();

// 6. GENERATE PDF IN BACKGROUND AS BASE64 STRING
    $pdf = new VolunteerPDF();
    $pdf->AddPage();

    // Add logo
    $pdf->Image('C:\xampp\htdocs\MAX_ELECTRONICS_HUB\CIHL.jpg', 10, 31, 24);
    $pdf->SetY(75);
        
    // Section 1: Donor Personal Info
    $pdf->SectionHeader("PERSONAL DETAILS");
    $pdf->DrawThreeFields("First Name", $fname, "Middle Name", $mname, "Last Name", $lname);
    $pdf->DrawThreeFields("Email Address", $email, "Phone Number", $phone, "Country", $country);
    $pdf->DrawField("Organisation", $org, 185);

    // Section 2: Contribution Info
    $pdf->SectionHeader("DONATION SPECIFICATIONS");
    $pdf->DrawThreeFields("Intervention you wish to donate for", $category, "Amount of Money in US$", $amount, "Payment Method you preffer to use", $payment);
    $pdf->DrawField("Comments / Message about the donation", $comment, 185);

    // Turn PDF into Base64 string for Javascript to execute download
    $pdfData = $pdf->Output('S');
    $base64Pdf = base64_encode($pdfData);
    $filename = 'Donation_Request_' . $fname . '.pdf';

// 7. DISPLAY SUCCESS ALERT CARD HTML
        echo <<<HTML
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Submission Successful</title>
            <link href='https://unpkg.com' rel='stylesheet'>
            <style>
                .success-wrapper {
                    display: flex;
                    justify-content: center;
                    align-items: center;
                    height: 90vh;
                    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                    background-color: #f4f7f6;
                }
                .success-card {
                    background-color: #e0f2f1;
                    color: #2e7d32;
                    padding: 40px;
                    border-radius: 15px;
                    text-align: center;
                    box-shadow: 0 10px 30px rgba(0,0,0,0.1);
                    border: 1px solid #a5d6a7;
                    max-width: 500px;
                    width: 100%;
                }
                .success-card i {
                    font-size: 4.5rem;
                    display: block;
                    margin-bottom: 15px;
                }
                .success-card h3 { margin: 0; font-size: 1.7rem; }
                .success-card p { color: #444; margin-top: 10px; line-height: 1.6; font-size: 1.05rem;}
                
                /* Download button styling */
                .download-btn {
                    display: inline-flex;
                    align-items: center;
                    gap: 8px;
                    background-color: #2e7d32;
                    color: white;
                    padding: 12px 24px;
                    border-radius: 8px;
                    text-decoration: none;
                    font-weight: bold;
                    margin-top: 20px;
                    box-shadow: 0 4px 10px rgba(46, 125, 50, 0.2);
                    transition: background 0.3s ease;
                    cursor: pointer;
                    border: none;
                }
                .download-btn:hover {
                    background-color: #1b5e20;
                }
                .redirect-msg {
                    font-size: 0.85rem;
                    color: #666;
                    margin-top: 15px;
                }
            </style>
        </head>
        <body>

        <div class="success-wrapper">
            <div class="success-card">
                <i class='bx bx-check-circle'></i>
                <h3>Thanks a lot!</h3>
                <p>Your application has been uploaded successfully.<br> 
                <strong>Your will receive instructions on your email shortly...</strong></p>
                
                <!-- Manual Download trigger if auto fails -->
                <button class="download-btn" onclick="triggerDownload()">
                    <i class='bx bx-download'></i> Download PDF Receipt
                </button>
                
                <div class="redirect-msg">Redirecting you back to home page shortly...</div>
            </div>
        </div>

        <script>
        const base64Data = "{$base64Pdf}";
        const filename = "{$filename}";

        // Execution logic to download base64 string asset
        function triggerDownload() {
            const linkSource = `data:application/pdf;base64,\${base64Data}`;
            const downloadLink = document.createElement("a");
            downloadLink.href = linkSource;
            downloadLink.download = filename;
            document.body.appendChild(downloadLink);
            downloadLink.click();
            document.body.removeChild(downloadLink);
        }

// 1. Run automatic download on window mount
    window.onload = function() {
    triggerDownload();
            
// 2. Redirect back after 6 seconds to give time for operations
         setTimeout(function() {
            window.location.href = "http://localhost/MAX_ELECTRONICS_HUB";
            }, 6000);
        };
        </script>
        
        </body>
        </html>
HTML;
        exit();

    } else {
        // Error Display Screen if DB execution fails
        echo <<<HTML
        <!DOCTYPE html>
        <html>
        <head>
            <link href='https://unpkg.com' rel='stylesheet'>
            <style>
                .error-wrapper { display: flex; justify-content: center; align-items: center; height: 80vh; font-family: sans-serif; }
                .error-card { background-color: #ffebee; color: #c62828; padding: 40px; border-radius: 15px; text-align: center; border: 1px solid #ffcdd2; max-width: 500px; }
                .error-card i { font-size: 4rem; display: block; margin-bottom: 15px; }
            </style>
        </head>
    }
HTML;
exit();
 }
}
?>