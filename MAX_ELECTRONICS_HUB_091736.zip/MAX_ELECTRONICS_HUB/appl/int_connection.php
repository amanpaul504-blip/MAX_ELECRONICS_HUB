
<?php
// Define configuration variables for redirection

if (isset($_POST["submit"])) {
    // 1. Capture text inputs from $_POST
    $firstname = $_POST['firstname'] ?? "";
    $middlename = $_POST['middlename'] ?? "";
    $lastname = $_POST['lastname'] ?? "";
    $DoB = $_POST['DoB'] ??"";
    $sex = $_POST['sex'] ??"";
    $height = $_POST['height'] ??"" ;
    $nationality = $_POST['nationality'] ??"";
    $pnumber = $_POST['pnumber'] ??"";
    $lang = $_POST['lang'] ??"";
    $email = $_POST['email'] ??"" ;
    $pnumber_a = $_POST['pnumber_a'] ??"";
    $hnumber = $_POST['hnumber'] ??"";
    $street = $_POST['street'] ??"";
    $t_city = $_POST['t_city'] ??"";
    $country = $_POST['country'] ??"";
    $cu_study = $_POST['cu_study'] ??"";
    $country_a = $_POST['country_a'] ??"";
    $c_studied = $_POST['c_studied'] ??"";
    $yenrolled = $_POST['yenrolled'] ??"";
    $sID_num = $_POST['sID_num'] ??"";
    $d_graduated = $_POST['d_graduated'] ??"";
    $n_referee = $_POST['n_referee'] ??"";
    $n_univ = $_POST['n_univ'] ??"";
    $country_b = $_POST['country_b'] ??"";
    $pnumber_b = $_POST['pnumber_b'] ??"";
    $email_b = $_POST['email_b'] ??"";
    $fapplied = $_POST['fapplied'] ??"";
    $duration = $_POST['duration'] ??"";
    $d_start = $_POST['d_start'] ??"";


    // Database connection details
    $servername = 'localhost';
    $username = 'root';
    $password = ''; 
    $dbname = 'appl_db';

    // Create connection
    $conn = new mysqli($servername,$username,$password,$dbname);

    // 2. Process Files
    $target_dir = "uploads/";
    $file_inputs = ["fileUpload","fileUpload1","fileUpload2","fileUpload3"];
    $paths = [];

    foreach ($file_inputs as $input_name) {
        if (!empty($_FILES[$input_name]["name"])) {
            $file_name = time() . "_" . basename($_FILES[$input_name]["name"]);
            $target_file = $target_dir . $file_name;
            
            if (move_uploaded_file($_FILES[$input_name]["tmp_name"], $target_file)) {
                $paths[] = $target_file;
            } else {
                $paths[] = null;
            }
        } else {
            $paths[] = null;
        }
    }

    // 3. One single INSERT for all data
    $sql = "INSERT INTO appl_form (firstname,middlename,lastname,DoB,sex,height,nationality,pnumber,lang,email,pnumber_a,hnumber,street,t_city,country,cu_study,country_a,c_studied,yenrolled,sID_num,d_graduated,n_referee,n_univ,country_b,pnumber_b,email_b,fapplied,duration,d_start,file_path,file_path1,file_path2,file_path3) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
   
     // FIX: Pass the $sql variable into prepare()
    $stmt = $conn->prepare($sql);

    if ($stmt === false) {
        die("Prepare failed: " . htmlspecialchars($conn->error));
    }

    // Bind the 33 strings(29 data strings and 4 file attachments)
    $stmt->bind_param("sssssssssssssssssssssssssssssssss",$firstname,$middlename,$lastname,$DoB,$sex,$height,$nationality,$pnumber,$lang,$email,$pnumber_a,$hnumber,$street,$t_city,$country,$cu_study,$country_a,$c_studied,$yenrolled,$sID_num,$d_graduated,$n_referee,$n_univ,$country_b,$pnumber_b,$email_b,$fapplied,$duration,$d_start,$paths[0],$paths[1],$paths[2],$paths[3]);

    if ($stmt->execute( )) {

    // Configuration
    $redirect_url = "$$&.php"; // Update with your actual URL
    $timeout_milliseconds = 3000;  // 3 seconds

    echo <<<HTML
    <link href='https://cdn.boxicons.com/3.0.6/fonts/brands/boxicons-brands.min.css' rel='stylesheet'>
        <link href='https://cdn.boxicons.com/3.0.6/fonts/basic/boxicons.min.css' rel='stylesheet'>
    <link href='unpkg.com' rel='stylesheet'>
    
    <style>
        .success-wrapper {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 80vh;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .success-card {
            background-color: #e0f2f1;
            color: #2e7d32;
            padding: 40px;
            border-radius: 15px;
            text-align: center;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            border: 1px solid #a5d6a7;
            max-width: 500px;
        }
        .success-card i {
            font-size: 4rem;
            display: block;
            margin-bottom: 15px;
        }
        .success-card h3 { margin: 0; font-size: 1.5rem; }
        .success-card p { color: #555; margin-top: 10px; }
    </style>

    <div class="success-wrapper">
        <div class="success-card">
            <i class='bx bx-check-circle'></i>
            <h3>Success!</h3>
            <p>Your application has been uploaded successfully.<br> 
            <strong>Please wait, redirecting to payment...</strong></p>
        </div>
    </div>

    <script>
    // Configuration: Set redirect back to form or home
    const redirectUrl = "http://localhost/MAX_ELECTRONICS_HUB/appl/$$&.php"; 
    const timeout = 5000; // Longer delay for errors so they can read the message

    setTimeout(function() {
        window.location.href = redirectUrl;
    }, timeout);
    </script>
    
    HTML;

    } else {

    echo <<<HTML
    <link href='https://cdn.boxicons.com/3.0.6/fonts/brands/boxicons-brands.min.css' rel='stylesheet'>
        <link href='https://cdn.boxicons.com/3.0.6/fonts/basic/boxicons.min.css' rel='stylesheet'>
    <link href='unpkg.com' rel='stylesheet'>
    <style>
        .error-wrapper {
        display: flex;
        justify-content: center;
        align-items: center;
        height: 80vh;
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        .error-card {
        background-color: #ffebee; /* Light red background */
        color: #c62828;            /* Dark red text */
        padding: 40px;
        border-radius: 15px;
        text-align: center;
        box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        border: 1px solid #ffcdd2;
        max-width: 500px;

        }
        /* Icon styling */
        .error-card i {
        font-size: 4rem;
        display: block;
        margin-bottom: 15px;
        }
        .error-card h3 { margin: 0; font-size: 1.5rem; }
        .error-card p { color: #555; margin-top: 10px; }
    
        /* Retry Button (Optional but helpful for errors) */
        .retry-btn {
        margin-top: 20px;
        display: inline-block;
        padding: 10px 20px;
        background-color: #c62828;
        color: white;
        text-decoration: none;
        border-radius: 5px;
        font-weight: bold;
        }
    </style>

    <div class="error-wrapper">
    <div class="error-card">
        <!-- Error icon (X circle) -->
        <i class='bx bx-x-circle'></i>
        <h3>Submission Failed</h3>
        <p>We encountered an error while processing your application.<br> 
        <strong>Redirecting you back to try again...</strong></p>
    </div>
    </div>

    <script>
    // Configuration: Set redirect back to form or home
    const redirectUrl = "http://localhost/MAX_ELECTRONICS_HUB/appl/appl.php"; 
    const timeout = 5000; // Longer delay for errors so they can read the message

    setTimeout(function() {
        window.location.href = redirectUrl;
    }, timeout);
    </script>
    HTML;

    }

    $stmt->close();
    }

    // Close connection outside the IF or inside depending on if you have more logic
    $conn->close();
    ?>
