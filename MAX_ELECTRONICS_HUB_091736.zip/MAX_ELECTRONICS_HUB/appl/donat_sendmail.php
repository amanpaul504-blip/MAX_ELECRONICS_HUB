<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'path/to/PHPMailer/src/Exception.php';
require 'path/to/PHPMailer/src/PHPMailer.php';
require 'path/to/PHPMailer/src/SMTP.php';

//Create an instance; passing `true` enables exceptions
$mail = new PHPMailer(true);

try {
    //Server settings
    $mail->SMTPDebug = PHPMailer\PHPMailer\SMTP::DEBUG_SERVER;                     //Enable verbose debug output
    $mail->isSMTP();                                                               //Send using SMTP
    $mail->Host       = 'smtp.gmail.com';                                          //Set the SMTP server to send through
    $mail->SMTPAuth   = true;                                                      //Enable SMTP authentication
    $mail->Username   = 'cybermisc4@gmail.com';                                      //SMTP username
    $mail->Password   = 'lhwx ywvh capu dioe';                                     //SMTP password
    $mail->SMTPSecure = PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_SMTPS;           //Enable implicit TLS encryption
    $mail->Port       = 465;                                    //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`

    
    //Attachments
    $mail->addAttachment('/var/tmp/file.tar.gz');         //Add attachments
    $mail->addAttachment('/tmp/image.jpg', 'new.jpg');    //Optional name

    //Content
    $mail->isHTML(true);                                  //Set email format to HTML
    $mail->Subject = 'Here is the subject';
    $mail->Body    = 'This is the HTML message body <b>in bold!</b>';
    $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

    $mail->send();
    echo 'Message has been sent';
} catch (Exception $e) {
    echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
}

//Server settings
$mail->SMTPDebug = PHPMailer\PHPMailer\SMTP::DEBUG_SERVER;   // Fix: Use the correct constant instead of raw text
$mail->isSMTP();                                            // Send using SMTP
$mail->Host       = 'smtp.gmail.com';                       // Fix: Set the correct Gmail SMTP server
$mail->SMTPAuth   = true;                                   // Enable SMTP authentication
$mail->Username   = 'your_real_email@gmail.com';            // Fix: Use your actual Gmail address
$mail->Password   = 'abcd efgh ijkl mnop';                  // Fix: Must be a 16-character Google App Password
$mail->SMTPSecure = PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_SMTPS; // Enable implicit TLS encryption
$mail->Port       = 465;                                    // Port for SMTPS
