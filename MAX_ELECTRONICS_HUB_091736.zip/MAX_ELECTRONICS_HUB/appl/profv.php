<?php
session_start();
?>

<!DOCTYPE html>
<head>
  <meta charset="UTF-8">
  <meta id="viewport" content="width=device-width, initial-scale=1.0">
  <title> profv_form </title>
  <link rel="stylesheet" href="don.css">
  <link href='https://cdn.boxicons.com/fonts/basic/boxicons.min.css' rel='stylesheet'>

</head>

<body>
  <h2 align="center">MEDICAL PROFFESIONAL REQUEST <BR>FOR VISIT TO PRACTICE IN TANZANIA HOSPITALS</h2>
    <p align="center">Fill the form with correct details as per instructions on each field,
      attach all the necessary documents, then verify the details before you submit</p>
</body>

<body>

<form class="application-form"action="profv_pdf.php"method="POST"enctype="multipart/form-data">
<h3 align="center"><b>Personal Information</b></h3>
  <div class="form-group">
    <label for="firstname">First name</label>
    <input type="text"id="firstname" name="firstname" placeholder="eg. John" required />
  </div>

<div class="form-group">
    <label for="middlename">Middle name</label>
    <input type="text" id="middlename" name="middlename" placeholder="eg. Andreas" required/>
  </div>

  <div class="form-group">
    <label for="lastname">Last name</label>
    <input type="text" id="lastname" name="lastname" placeholder="eg. Vandapult" required/>
  </div>

   <div class="form-group">
    <label for="email">Email</label>
    <input type="email" id="email" name="email" placeholder="eg. vandapult@gmail.com" required/>
    </div>

    <div class="form-group">
    <label for="pnumber_a">Phone Number</label>
    <input type="text" id="pnumber_a"name="pnumber_a" placeholder="eg. +49 123 566 001" required/>
    </div>

    <div class="form-group">
    <label for="proffesional">Proffesional</label>
    <input type="text" id="proffesional"name="proffesional" placeholder="eg. Medical Doctor" required/>
    </div>

    <div class="form-group">
    <label for="speciality">Speciality(Optional)</label>
    <input type="text" id="speciality" name="speciality"placeholder="eg. Gaenacology"/></div>

    <div class="form-group">
    <label for="regnum">Registration Number</label>
    <input type="text" id="regnum" name="regnum"placeholder="eg. From Medical/proffesional board"required/></div>

  <div class="form-group">
    <label for="nation">Nationality</label>
  <select id ="nation" name="nation">
    <option Value="SC">Select country</option>
    <option value="Afghanistan">Afghanistan</option>
    <option value="Aland">Åland Islands</option>
    <option value="Albania">Albania</option>
    <option value="Algeria">Algeria</option>
    <option value="American">American Samoa</option>
    <option value="Andorra">Andorra</option>
    <option value="Angola">Angola</option>
    <option value="Anguilla">Anguilla</option>
    <option value="Antarctica">Antarctica</option>
    <option value="Antigua">Antigua and Barbuda</option>
    <option value="Argentina">Argentina</option>
    <option value="Armenia">Armenia</option>
    <option value="Aruba">Aruba</option>
    <option value="Australia">Australia</option>
    <option value="Austria">Austria</option>
    <option value="Azerbaijan">Azerbaijan</option>
    <option value="Bahamas">Bahamas</option>
    <option value="Bahrain">Bahrain</option>
    <option value="Bangladesh">Bangladesh</option>
    <option value="Barbados">Barbados</option>
    <option value="Belarus">Belarus</option>
    <option value="Belgium">Belgium</option>
    <option value="Belize">Belize</option>
    <option value="Benin">Benin</option>
    <option value="Bermuda">Bermuda</option>
    <option value="Bhutan">Bhutan</option>
    <option value="BO">Bolivia (Plurinational State of)</option>
    <option value="Bosnia & Herzegovina">Bosnia and Herzegovina</option>
    <option value="Botswana">Botswana</option>
    <option value="Bouvet Isl.">Bouvet Island</option>
    <option value="Brazil">Brazil</option>
    <option value="British Indian Ocean Terr">British Indian Ocean Territory</option>
    <option value="Brunei Darussalam">Brunei Darussalam</option>
    <option value="Bulgaria">Bulgaria</option>
    <option value="Burkina Faso">Burkina Faso</option>
    <option value="Burundi">Burundi</option>
    <option value="Cabo Verde">Cabo Verde</option>
    <option value="Cambodia">Cambodia</option>
    <option value="Cameroon">Cameroon</option>
    <option value="Canada">Canada</option>
    <option value="Caribbean Netherlands">Caribbean Netherlands</option>
    <option value="Cayman Isl.">Cayman Islands</option>
    <option value="Central African Republic">Central African Republic</option>
    <option value="Chad">Chad</option>
    <option value="Chile">Chile</option>
    <option value="China">China</option>
    <option value="Christmas Isl.">Christmas Island</option>
    <option value="Cocos Isl.">Cocos (Keeling) Islands</option>
    <option value="Colombia">Colombia</option>
    <option value="Comoro">Comoros</option>
    <option value="Congo">Congo</option>
    <option value="Congo DR">Congo, Democratic Republic of the</option>
    <option value="Cook Islands">Cook Islands</option>
    <option value="Costa Rica">Costa Rica</option>
    <option value="Croatia">Croatia</option>
    <option value="Cuba">Cuba</option>
    <option value="Curacao">Curaçao</option>
    <option value="Cyprus">Cyprus</option>
    <option value="Czech Republic">Czech Republic</option>
    <option value="Cote d'Ivoire">Côte d'Ivoire</option>
    <option value="Denmark">Denmark</option>
    <option value="Djibouti">Djibouti</option>
    <option value="Dominica">Dominica</option>
    <option value="Dominican Republic">Dominican Republic</option>
    <option value="Ecuador">Ecuador</option>
    <option value="Egypt">Egypt</option>
    <option value="El Salvador">El Salvador</option>
    <option value="Equatorial Guinea">Equatorial Guinea</option>
    <option value="Eritrea">Eritrea</option>
    <option value="Estonia">Estonia</option>
    <option value="Eswatini">Eswatini (Swaziland)</option>
    <option value="Ethiopia">Ethiopia</option>
    <option value="Falkland Islands">Falkland Islands (Malvinas)</option>
    <option value="Faroe Islands">Faroe Islands</option>
    <option value="Fiji">Fiji</option>
    <option value="Finland">Finland</option>
    <option value="France">France</option>
    <option value="French Guiana">French Guiana</option>
    <option value="French Polynesia">French Polynesia</option>
    <option value="French Southern Ter.">French Southern Territories</option>
    <option value="Gabon">Gabon</option>
    <option value="Gambia">Gambia</option>
    <option value="Georgia">Georgia</option>
    <option value="Germany">Germany</option>
    <option value="Ghana">Ghana</option>
    <option value="Gibraltar">Gibraltar</option>
    <option value="Greece">Greece</option>
    <option value="Greenland">Greenland</option>
    <option value="Grenada">Grenada</option>
    <option value="Guadeloupe">Guadeloupe</option>
    <option value="Guam">Guam</option>
    <option value="Guatemala">Guatemala</option>
    <option value="Guernsey">Guernsey</option>
    <option value="Guinea">Guinea</option>
    <option value="Guinea-Bissau">Guinea-Bissau</option>
    <option value="Guyana">Guyana</option>
    <option value="Haiti">Haiti</option>
    <option value="Heard Island & Mcdonald Isl.">Heard Island and Mcdonald Islands</option>
    <option value="Honduras">Honduras</option>
    <option value="Hong Kong">Hong Kong</option>
    <option value="Hungary">Hungary</option>
    <option value="Iceland">Iceland</option>
    <option value="India">India</option>
    <option value="Indonesia">Indonesia</option>
    <option value="Iran">Iran</option>
    <option value="Iraq">Iraq</option>
    <option value="Ireland">Ireland</option>
    <option value="Isle of Man">Isle of Man</option>
    <option value="Israel">Israel</option>
    <option value="Italy">Italy</option>
    <option value="Jamaica">Jamaica</option>
    <option value="Japan">Japan</option>
    <option value="Jersey">Jersey</option>
    <option value="Jordan">Jordan</option>
    <option value="Kazakhstan">Kazakhstan</option>
    <option value="Kenya">Kenya</option>
    <option value="Kiribati">Kiribati</option>
    <option value="Korea">Korea, North</option>
    <option value="Korea">Korea, South</option>
    <option value="Kosovo">Kosovo</option>
    <option value="Kuwait">Kuwait</option>
    <option value="Kyrgyzstan">Kyrgyzstan</option>
    <option value="Lao People">Lao People's Democratic Republic</option>
    <option value="Latvia">Latvia</option>
    <option value="Lebanon">Lebanon</option>
    <option value="Lesotho">Lesotho</option>
    <option value="Liberia">Liberia</option>
    <option value="Libya">Libya</option>
    <option value="Liechtenstein">Liechtenstein</option>
    <option value="Lithuania">Lithuania</option>
    <option value="Luxembourg">Luxembourg</option>
    <option value="Macao">Macao</option>
    <option value="Macedonia">Macedonia North</option>
    <option value="Madagascar">Madagascar</option>
    <option value="Malawi">Malawi</option>
    <option value="Malaysia">Malaysia</option>
    <option value="Maldives">Maldives</option>
    <option value="Mali">Mali</option>
    <option value="Malta">Malta</option>
    <option value="Marshall">Marshall Islands</option>
    <option value="Martinique">Martinique</option>
    <option value="Mauritania">Mauritania</option>
    <option value="Mauritius">Mauritius</option>
    <option value="Mayotte">Mayotte</option>
    <option value="Mexico">Mexico</option>
    <option value="Micronesia">Micronesia</option>
    <option value="Moldova">Moldova</option>
    <option value="Monaco">Monaco</option>
    <option value="Mongolia">Mongolia</option>
    <option value="Montenegro">Montenegro</option>
    <option value="Montserrat">Montserrat</option>
    <option value="Morocco">Morocco</option>
    <option value="Mozambique">Mozambique</option>
    <option value="Myanmar">Myanmar (Burma)</option>
    <option value="Namibia">Namibia</option>
    <option value="Nauru">Nauru</option>
    <option value="Nepal">Nepal</option>
    <option value="Netherlands">Netherlands</option>
    <option value="Netherlands Antilles">Netherlands Antilles</option>
    <option value="New Caledonia">New Caledonia</option>
    <option value="New Zealand">New Zealand</option>
    <option value="Nicaragua">Nicaragua</option>
    <option value="Niger">Niger</option>
    <option value="Nigeria">Nigeria</option>
    <option value="Niue">Niue</option>
    <option value="Norfolk Island">Norfolk Island</option>
    <option value="Northern Mariana Islands">Northern Mariana Islands</option>
    <option value="Norway">Norway</option>
    <option value="Oman">Oman</option>
    <option value="Pakistan">Pakistan</option>
    <option value="Palau">Palau</option>
    <option value="Palestine">Palestine</option>
    <option value="Panama">Panama</option>
    <option value="Papua New Guinea">Papua New Guinea</option>
    <option value="Paraguay">Paraguay</option>
    <option value="Peru">Peru</option>
    <option value="Philippines">Philippines</option>
    <option value="Pitcairn Islands">Pitcairn Islands</option>
    <option value="Poland">Poland</option>
    <option value="Portugal">Portugal</option>
    <option value="Puerto Rico">Puerto Rico</option>
    <option value="Qatar">Qatar</option>
    <option value="Reunion">Reunion</option>
    <option value="Romania">Romania</option>
    <option value="Russian Federation">Russian Federation</option>
    <option value="Rwanda">Rwanda</option>
    <option value="Saint Barthelemy">Saint Barthelemy</option>
    <option value="Saint Helena">Saint Helena</option>
    <option value="Saint Kitts and Nevis">Saint Kitts and Nevis</option>
    <option value="Saint Lucia">Saint Lucia</option>
    <option value="Saint Martin">Saint Martin</option>
    <option value="Saint Pierre and Miquelon">Saint Pierre and Miquelon</option>
    <option value="Saint Vincent and the Grenadines">Saint Vincent and the Grenadines</option>
    <option value="Samoa">Samoa</option>
    <option value="San Marino">San Marino</option>
    <option value="Sao Tome & Principe">Sao Tome and Principe</option>
    <option value="Saudi Arabia">Saudi Arabia</option>
    <option value="Senegal">Senegal</option>
    <option value="Serbia">Serbia</option>
    <option value="Serbia & Montenegro">Serbia and Montenegro</option>
    <option value="Seychelles">Seychelles</option>
    <option value="Sierra Leone">Sierra Leone</option>
    <option value="Singapore">Singapore</option>
    <option value="Sint Maarten">Sint Maarten</option>
    <option value="Slovakia">Slovakia</option>
    <option value="Slovenia">Slovenia</option>
    <option value="Solomon Islands">Solomon Islands</option>
    <option value="Somalia">Somalia</option>
    <option value="South Africa">South Africa</option>
    <option value="South Gergia & South Sandwich">South Georgia and the South Sandwich Islands</option>
    <option value="South Sudan">South Sudan</option>
    <option value="Spain">Spain</option>
    <option value="sri Lanka">Sri Lanka</option>
    <option value="Sudan">Sudan</option>
    <option value="Suriid">Suriid</option>
    <option value="Svalbard & Jan Mayen">Svalbard and Jan Mayen</option>
    <option value="Sweden">Sweden</option>
    <option value="Switzerland">Switzerland</option>
    <option value="Syria">Syria</option>
    <option value="Taiwan">Taiwan</option>
    <option value="Tajikistan">Tajikistan</option>
    <option value="Tanzania">Tanzania</option>
    <option value="Thailand">Thailand</option>
    <option value="Timor-Leste">Timor-Leste</option>
    <option value="Togo">Togo</option>
    <option value="Tokelau">Tokelau</option>
    <option value="Tonga">Tonga</option>
    <option value="Trinidad">Trinidad and Tobago</option>
    <option value="Tunisia">Tunisia</option>
    <option value="Turkey">Turkey (Türkiye)</option>
    <option value="Turkmenistan">Turkmenistan</option>
    <option value="Turks and Caicos Isl.">Turks and Caicos Islands</option>
    <option value="Tuvalu">Tuvalu</option>
    <option value="U.S. Outlying Isl.">U.S. Outlying Islands</option>
    <option value="Uganda">Uganda</option>
    <option value="Ukraine">Ukraine</option>
    <option value="UAE">United Arab Emirates</option>
    <option value="UK">United Kingdom</option>
    <option value="United States">United States</option>
    <option value="Uruguay">Uruguay</option>
    <option value="Uzbekistan">Uzbekistan</option>
    <option value="Vanuatu">Vanuatu</option>
    <option value="Vatican">Vatican City Holy See</option>
    <option value="Venezuela">Venezuela</option>
    <option value="Vietnum">Vietnam</option>
    <option value="Virgin Islands, British">Virgin Islands, British</option>
    <option value="Virgin Islands, US">Virgin Islands, U.S</option>
    <option value="Walis and Futuna">Wallis and Futuna</option>
    <option value="W.Sahara">Western Sahara</option>
    <option value="Yemen">Yemen</option>
    <option value="Zambia">Zambia</option>
    <option value="Zimbabwe">Zimbabwe</option>
</select>
</div>

<div class="form-group">
    <label for="passnum">Passport Number</label>
    <input type="text" id="passnum" name="passnum"placeholder="Passport Number"/>
  </div>
  
<h3 align="center"><b>Supporting Documents/Information</b></h3>


<div class="form-group">
    <label for="uploadedFile">Attach a current coloured passport size photo</label>
    <input type="file" name="fileUpload" id="uploadedFile" accept=".png, .jpg, .jpeg, image/png, image/jpeg"/>
    </div>

    <div class="form-group">
    <label for="uploadedFile1">Attach a proffesional registration certificate</label>
     <input type="file" name="fileUpload1" id="uploadedFile1" accept=".pdf"/>
    </div>

    <div class="form-group">
    <label for="uploadedFile2">Attach a licence of practice</label>
     <input type="file" name="fileUpload2" id="uploadedFile2" accept=".pdf"/>
    </div>

<label1 for="user-comment">Write your explanation for the visit <br>(eg. expectations, how long do you wish to stay, what you want to deliver or benefit from the visit)</label1>
    <textarea id="user-comment" name="comment" rows="6" cols="157" placeholder="Wtite your comments here....." required/></textarea>

<div class="form-group">
  <label for="blank">.</label></div>

  <p><input type="Submit" name="Submit" id="Submit"></p>
  </div></form>

  <script>
  function myFunction() {
    // Your JavaScript function runs without the page refreshing
    alert("Function executed without refresh!");
  }
  </script>
   
    <!--end of page-->
    <?php
    require_once("profv.php");
    ?>
  <script src="appl.js"></script>
    <!--end of page-->
    <!--end of page-->