<?php

session_start();
session_unset();
?>
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
body {
  font-family: Arial;
  font-size: 17px;
  padding: 8px;
}

* {
  box-sizing: border-box;
}

.row {
  display: -ms-flexbox; /* IE10 */
  display: flex;
  -ms-flex-wrap: wrap; /* IE10 */
  flex-wrap: wrap;
  margin: 0 -16px;
}

.col-25 {
  -ms-flex: 25%; /* IE10 */
  flex: 25%;
}

.col-50 {
  -ms-flex: 50%; /* IE10 */
  flex: 50%;
}

.col-75 {
  -ms-flex: 75%; /* IE10 */
  flex: 75%;
}

.col-25,
.col-50,
.col-75 {
  padding: 0 16px;
}

.container {
  background-color: whitesmoke;
  padding: 50px 60px 20px 60px;
  border: 1px solid lightgrey;
  border-radius: 15px;
}

.button onclick [type=button] {
  background-color: #4CAF50; /* Green background */
  width: 100%;
  color: white; /* White text */
  padding: 14px 20px; /* Padding inside the button */
  margin-left: 5px;
  border: none; /* No border */
  border-radius: 15px; /* Slightly rounded corners */
  cursor: pointer; /* Change cursor on hover */
  font-size: 16px; /* Font size */
  transition: background-color 0.3s ease; /* Smooth transition for hover effect */
}

button {
  width: 54%;
  border-radius: 10px;
  border: 0.5px solid;color: yellow;
  margin-bottom: 10px;
  margin-top: 0px;
  background-color: orange;
}

button:hover {
  background-color: yellow;
  border: 0.5px solid;color:orange;
}

input[type=text] {
  width: 100%;
  margin-bottom: 20px;
  padding: 12px;
  border: 1px solid #ccc;
  border-radius: 15px;
}

label {
  margin-bottom: 1px;
  display: block;
}

.icon-container {
  margin-bottom: 40px;
  padding: 7px 0;
  font-size: 24px;
}

.btn {
  background-color: skyblue;
  color: black;
  padding: 10px;
  margin: 4px 40px;
  border: none;
  width: 60%;
  border-radius: 15px;
  cursor: pointer;
  font-size: 17px;
}

.btn:hover {
  background-color: whitesmoke;
}

a {
  color: #2196F3;
}

hr {
  border: 1px solid lightgrey;
}

span.price {
  float: right;
  color: grey;
}

/* Responsive layout - when the screen is less than 800px wide, make the two columns stack on top of each other instead of next to each other (also change the direction - make the "cart" column go on top) */
@media (max-width: 800px) {
  .row {
    flex-direction: column-reverse;
  }
  .col-25 {
    margin-bottom: 30px;
  }
}
</style>
</head>
<body>
  <style>
.flex-container1 {
  display: flex;
  align-items: stretch;
  background-color: skyblue;
  border-radius: 15px;
}

.flex-container1 > div {
  background-color: skyblue;
  color: black;
  margin: 10px; 
  text-align: center;
  line-height: 10px;
  font-size: 20px;
}

</style>
<div class="container">
<div class="flex-container1">
  <div style="flex-grow: 1"><b>Payment of registration fees</b></div>
  
</div>

<p align="center">To finalize submission of the application form, you have to pay $20 registration fees and submit your application for further proceses</p>
<div class="row">
  <div class="col-75">
    <div class="container">
      <form action="/action_page.php">
      
        <div class="row">
          <div class="col-50">
            <h3>Applicant Address</h3>
            <label for="fname"><i class="fa fa-user"></i> Full Name</label>
            <input type="text" id="fname" name="fullname" placeholder="Juan L. Christian" required/>
            <label for="email"><i class="fa fa-envelope"></i> Email</label>
            <input type="text" id="email" name="email" placeholder="juan@gmail.com" required/>
            <label for="adr"><i class="fa fa-address-card-o"></i> Address</label>
            <input type="text" id="adr" name="address" placeholder="542 P. 12th Street" required/>
            <label for="city"><i class="fa fa-institution"></i> City</label>
            <input type="text" id="city" name="city" placeholder="New York" required/>

            <div class="row">
              <div class="col-50">
                <label for="state">State</label>
                <input type="text" id="state" name="state" placeholder="NY" required/>
              </div>
              <div class="col-50">
                <label for="zip">Zip</label>
                <input type="text" id="zip" name="zip" placeholder="10001" required/>
              </div>
            </div>
          </div>

          <div class="col-50">
            <h3>Payment</h3>
            <label for="fname">Accepted Cards & Payment Methods</label>
            <div class="icon-container">
              <i class="fa fa-cc-visa" style="color:navy;font-size: 40px; padding-right: 40px;"></i>
              <i class="fa fa-cc-mastercard" style="color:red;font-size: 40px; padding-right: 40px;"></i>
              <i class="fa fa-cc-paypal" style="color:orange;font-size: 40px;"></i>
            </div>
            <button onclick="location.href='https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=V7KGDPZUWC86S'" type="button" >
    <span style="color:#fff; font-style:italic; font-weight:bold;font-size: 15px;"> PayPal payment Click here</span>
</button><label for="cname">Name on Card</label>
            <input type="text" id="cname" name="cardname" placeholder="Juan Luiz Christian" required/>
            <label for="ccnum">Credit card number</label>
            <input type="text" id="ccnum" name="cardnumber" placeholder="1091-0982-1324-0021" required/>
            <label for="expmonth">Exp Month</label>
            <input type="text" id="expmonth" name="expmonth" placeholder="September" required/>
            <div class="row">
              <div class="col-50">
                <label for="expyear">Exp Year</label>
                <input type="text" id="expyear" name="expyear" placeholder="2018" required/>
              </div>
              <div class="col-50">
                <label for="cvv">CVV</label>
                <input type="text" id="cvv" name="cvv" placeholder="352" required/>
              </div>
            </div>
          </div>
          
        </div>
       </style>

<div class="flex-container1">
  <div style="flex-grow: 1"><b><input type="submit" value=" Pay $20 Fees" class="btn">
      </form></b></div><br>
    </div>
  </div>
</div>

</body>
</html>
