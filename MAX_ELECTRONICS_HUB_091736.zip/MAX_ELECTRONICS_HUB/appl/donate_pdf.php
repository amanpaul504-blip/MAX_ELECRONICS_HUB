<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';
require 'fpdf.php';

session_start();
 
// 1. Load configuration pathway map
require_once __DIR__ . '/conf.php';

if (!file_exists($autoloader)) {
    die("Configuration Error: Composer autoloader not found. Run 'composer install' in the project directory.");
}
require_once $autoloader;

// 2. ISOLATED DOTENV ENVIRONMENT INITIALIZATION
try {
    $dotenv = Dotenv\Dotenv::createImmutable(__DIR__);
    $dotenv->load();
    
    $dotenv->required([
        'CIHL_MAIL_USER', 
        'CIHL_MAIL_PASSWORD', 
        'CIHL_PAYPAL_URL', 
        'CIHL_CREDIT_CARD_URL',
    ])->notEmpty();
} catch (\Exception $e) {
    die("Critical Configuration Error: Missing or invalid environment keys. Detail: " . $e->getMessage());
}

                                                                
// 2. Include the core FPDF library 

class DonationPDF extends FPDF {
    // Page header configuration
    function Header() {

         // Add heading
        $this->Ln(26);
        //Organisation name
        $this->SetFont("Arial", "B", 16);
        $this->Cell(0, 8, 'COMMUNITY INITIATIVES FOR HEALTHY LIFE(CIHL)',0, 1, 'C');

        // Form Title
        $this->SetFont("Helvetica", "B", 14);
        $this->Cell(0, 8, "DONATION PLEDGE FORM", 0, 1, "C");
        
        // Subtitle instructions
        $this->Ln(16);
        $this->SetFont("Helvetica", "I", 12);
        $instructions = "This is an official digital copy of your submitted pledge to donate money.";
        $this->MultiCell(0, 4, $instructions, 0, "C");
        $this->Ln(8);
        //Full width header line
        $this->SetDrawColor(0, 102, 204);
        $this->SetLinewidth(0.3);
        $this->Line(10, 30, 200, 30);
        $this->Ln(16);
    }
    function SectionHeader($title){
        $this->SetFont('Arial','B',12);
        $this->SetFillColor(230,230,230);
        $this->Cell(0, 8, $title, 0, 1, "L", true);
        $this->Ln(2);
    }

    // Single-field helper method
    function DrawField($label, $value, $width = 0, $margin = 10) {
        $this->SetX($margin);
        $this->SetFont('Arial', 'B', 10);
        $this->Cell($width, 6, $label, 0, 1); // Label row
        
        $this->SetX($margin);
        $this->SetFont('Arial', '', 10);
        $this->Cell($width, 8, $value, 0, 1); // Value box row
        $this->Ln(4);
    }

    // Three-column row layout method
    function DrawThreeFields($label1, $value1, $label2, $value2, $label3, $value3, $margin = 10, $fieldWidth = 55, $spacing = 10)
    {
        // Labels
        $this->SetFont('Arial', 'B', 10);
        $this->SetX($margin);
        $this->Cell($fieldWidth, 6, $label1, 0, 0);
        $this->Cell($spacing, 6, '', 0, 0);
        $this->Cell($fieldWidth, 6, $label2, 0, 0);
        $this->Cell($spacing, 6, '', 0, 0);
        $this->Cell($fieldWidth, 6, $label3, 0, 1);

        // Values
        $this->SetFont('Arial', '', 10);
        $this->SetX($margin);
        $this->Cell($fieldWidth, 8, $value1, 0, 0);
        $this->Cell($spacing, 8, '', 0, 0);
        $this->Cell($fieldWidth, 8, $value2, 0, 0);
        $this->Cell($spacing, 8, '', 0, 0);
        $this->Cell($fieldWidth, 8, $value3, 0, 1);

        $this->Ln(4);
    }
     //Footer
    function Footer()
    {
        $this->SetY(-34);
        //Fool-width footer line
        $this->SetDrawColor(0, 102, 204);
        $this->SetLinewidth(0.3);
        $this->Line(10,
        $this->GetY(), 200,
        $this->GetY());

        $this->Ln(2);
        $this->SetFont('Arial','I',8);
        $this->Cell(0, 5, 'Community Intiatives for Healthy Life(CIHL)', 0, 1, 'C');
        $this->Cell(0, 5, 'Page '.
        $this->PageNo(). '/{nb}', 0, 0, 'C');
    }
}

// Database connection details
$servername = 'localhost';
$username   = 'root';
$password   = ''; 
$dbname     = 'appl_db';

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// 3. Check if form data was actually posted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    // Clean inputs for DB entry
    $fname       = htmlspecialchars(trim($_POST['firstname'] ?? ''));
    $mname       = htmlspecialchars(trim($_POST['middlename'] ?? ''));
    $lname       = htmlspecialchars(trim($_POST['lastname'] ?? ''));
    $email       = filter_var(trim($_POST['email'] ?? ''), FILTER_SANITIZE_EMAIL);
    $phone       = htmlspecialchars(trim($_POST['pnumber_a'] ?? ''));
    $org         = htmlspecialchars(trim($_POST['organisation'] ?? '')); 
    $country     = htmlspecialchars(trim($_POST['nation'] ?? ''));
    $selectedCategories = $_POST['categories'] ?? [];
    if (is_array($selectedCategories)) {
        $selectedCategories = array_map(function ($value) {
            return htmlspecialchars(trim((string)$value));
        }, $selectedCategories);
        $selectedCategories = array_values(array_filter($selectedCategories, function ($value) {
            return $value !== '';
        }));
        $category = implode(', ', $selectedCategories);
    } else {
        $category = htmlspecialchars(trim((string)$selectedCategories));
    }
    $payment     = htmlspecialchars(trim($_POST['payment'] ?? ''));
    $comment     = htmlspecialchars(trim($_POST['comment'] ?? ''));
  
    // Parse numeric amount safely into a primitive float variable first
    $rawAmount   = isset($_POST['amount']) ? (float)$_POST['amount'] : 0.0;

    // 4. Basic Core Validations (Before Formatting Actions Alter Types)
    if (empty($fname) || empty($email) || empty($country) || empty($category) || empty($payment) || $rawAmount <= 0.0) {
        $_SESSION['status'] = "Please fill in all required fields with a valid donation amount.";
        header("Location: don_form.php");
        exit();
    }
  
    // 3. ONLY format it as a display string AFTER the validation passes successfully
    $paymentLink = $_SESSION['payment_link'] ?? '';

    $paypalUrl = getenv('CIHL_PAYPAL_URL');
    // Donation amount
    $rawAmount = isset($_POST['amount']) ? (float) $_POST['amount'] : 0.0;

    if ($rawAmount <= 0) {
        $_SESSION['status'] = "Please enter a valid donation amount.";
        header("Location: don_form.php");
        exit();
    }

    // Format amount for display
    $amount = number_format($rawAmount, 2, '.', ',');

    // Load payment URLs from .env via $_ENV array for XAMPP reliability
    $paypalUrl = $_ENV['CIHL_PAYPAL_URL'] ?? '';
    $creditcardURL = $_ENV['CIHL_CREDIT_CARD_URL'] ?? '';

    // PayPal link calculation using the unformatted $rawAmount variable
    $paypalLink = '';
    if (!empty($paypalUrl)) {
        $paypalLink = $paypalUrl
            . "?business=" . urlencode("cybermisc4@gmail.com")
            . "&item_name=" . urlencode("Donation")
            . "&amount=" . urlencode(number_format($rawAmount, 2, '.', '')) // Notice: No commas passed to URL
            . "&currency_code=USD";
    }

    // Credit-card link calculation using the unformatted $rawAmount variable
    $creditCardLink = '';
    if (!empty($creditcardURL)) {
        $creditCardLink = $creditcardURL
            . "?amount=" . urlencode(number_format($rawAmount, 2, '.', '')); // Notice: Clean float passed to URL
    }

    // 4. Basic Validation
    if (empty($fname) || empty($email) || empty($country) || empty($category) || empty($amount) || empty($payment)) {
        $_SESSION['status'] = "Please fill in all required fields.";
        header("Location: don_form.php");
        exit();
    }

    // 5. Use Prepared Statement for Database Insertion
    $sql = "INSERT INTO donation_requests (firstname, middlename, lastname, email, phone, organisation, country, category, amount, payment, comment) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssssssssss", $fname, $mname, $lname, $email, $phone, $org, $country, $category, $amount, $payment, $comment);

    if ($stmt->execute()) {
        $stmt->close();
        $conn->close();

    // 6. GENERATE PDF IN BACKGROUND AS BASE64 STRING
    $pdf = new DonationPDF();
    $pdf->AddPage();

    // Add logo
    $pdf->Image('C:\xampp\htdocs\MAX_ELECTRONICS_HUB\CIHL.jpg', 10, 31, 24);
    $pdf->SetY(75);
        
    // Section 1: Donor Personal Info
    $pdf->SectionHeader("PERSONAL DETAILS");
    $pdf->DrawThreeFields("First Name", $fname, "Middle Name", $mname, "Last Name", $lname);
    $pdf->DrawThreeFields("Email Address", $email, "Phone Number", $phone, "Country", $country);
    $pdf->DrawField("Organisation", $org, 185);

    // Section 2: Contribution Info
    $pdf->SectionHeader("DONATION SPECIFICATIONS");
    $pdf->DrawThreeFields("Intervention you wish to donate for", $category, "Amount of Money in US$", $amount, "Payment Method you preffer to use", $payment);
    $pdf->DrawField("Comments / Message about the donation", $comment, 185);

    // Turn PDF into Base64 string for Javascript to execute download
    $pdfData = $pdf->Output('S');
    $base64Pdf = base64_encode($pdfData);
    $filename = 'Donation_Pledge_' . $fname . '.pdf';

    $mail = new PHPMailer(true);

try {
    $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com';
    $mail->SMTPAuth = true;

    // Your Gmail account

    $mail->Username = $_ENV['CIHL_MAIL_USER']; 

    // Your 16-character Gmail App Password
    $mail->Password = $_ENV['CIHL_MAIL_PASSWORD'];

    $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
    $mail->Port = 465;

    // Sender
    $mail->setFrom('initiativescommunity6@gmail.com','CIHL');

    // Applicant's email from the form
    $mail->addAddress($email, $fname . ' ' . $lname);

    // Attach generated PDF (optional)
    if (!empty($pdfData)) {
        $mail->addStringAttachment($pdfData, $filename, 'base64', 'application/pdf');
    }

    // Email content
    $mail->isHTML(true);
    $mail->Subject = "Donation Pledge Received";
         
    // Clean HTML content block
    // Build payment section first
$paymentSection = '';

if ($payment === 'Credit card') {

    $paymentSection = '
        <p>
            <a href="' . htmlspecialchars($creditCardLink, ENT_QUOTES, 'UTF-8') . '">
                Click here to donate
            </a>
        </p>';

} elseif ($payment === 'PayPal') {

    $paymentSection = '
        <p>
            <a href="' . htmlspecialchars($paypalLink, ENT_QUOTES, 'UTF-8') . '">
                Click here to donate
            </a>
        </p>';

} elseif ($payment === 'Wire transfer' or 'Bank deposit') {

    $paymentSection = '
    <p style="line-height: 2; font-family: sans-serif;">
    <strong style="display: inline-block; width: 180px; vertical-align: top;">BANK NAME:</strong> CRDB BANK PLC TANZANIA<br>
    <strong style="display: inline-block; width: 180px; vertical-align: top;">ACCOUNT NAME:</strong> COMMUNITY INITIATIVES FOR HEALTHY LIFE (CIHL)<br>
    <strong style="display: inline-block; width: 180px; vertical-align: top;">ACCOUNT NUMBER:</strong> 011106212899<br>
    <strong style="display: inline-block; width: 180px; vertical-align: top;">SWIFT / BIC Code:</strong> CORUTZTZ101<br>
    <strong style="display: inline-block; width: 180px; vertical-align: top;">BRANCH:</strong> MAFINGA<br>
    <shadow style="display: inline-block; width: 180px; vertical-align: top;">Address:</shadow> Boma Ward , Mafinga Town Council, Iringa -Road,  P.O box 133 Mafinga-Tanzania.
    </p>';
   }

    // Email content
    $mail->Body = '
    <p>Dear <b>' . htmlspecialchars($fname, ENT_QUOTES, 'UTF-8') . '</b>,</p>

    <p>
    Thank you for pledging a donation of
    <b>US$' . htmlspecialchars($amount, ENT_QUOTES, 'UTF-8') . '</b>
    through <b>' . htmlspecialchars($payment, ENT_QUOTES, 'UTF-8') . '</b>.
    </p>

    <p>
    Please use the details below to complete your transaction:
    </p>

    ' . $paymentSection . '

    <p>Regards...<br>
    CIHL team</p>
    ';

    // Clean Plain-Text alternative body block 
    $mail->AltBody = "Dear " . $fname . ", your donation pledge has been submitted successfully. " . $paymentLink;

    // Dispatches the email safely
    $mail->send();
            
    // Set success message and redirect
    $_SESSION['status'] = "Pledge submitted and confirmation email sent successfully.";
    echo <<<HTML
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Submission Successful</title>
            <link href='https://unpkg.com' rel='stylesheet'>
            <style>
                .success-wrapper {
                    display: flex;
                    justify-content: center;
                    align-items: center;
                    height: 90vh;
                    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                    background-color: #f4f7f6;
                }
                .success-card {
                    background-color: #e0f2f1;
                    color: #2e7d32;
                    padding: 40px;
                    border-radius: 15px;
                    text-align: center;
                    box-shadow: 0 10px 30px rgba(0,0,0,0.1);
                    border: 1px solid #a5d6a7;
                    max-width: 500px;
                    width: 100%;
                }
                .success-card i {
                    font-size: 4.5rem;
                    display: block;
                    margin-bottom: 15px;
                }
                .success-card h3 { margin: 0; font-size: 1.7rem; }
                .success-card p { color: #444; margin-top: 10px; line-height: 1.6; font-size: 1.05rem;}
                
                /* Download button styling */
                .download-btn {
                    display: inline-flex;
                    align-items: center;
                    gap: 8px;
                    background-color: #2e7d32;
                    color: white;
                    padding: 12px 24px;
                    border-radius: 8px;
                    text-decoration: none;
                    font-weight: bold;
                    margin-top: 20px;
                    box-shadow: 0 4px 10px rgba(46, 125, 50, 0.2);
                    transition: background 0.3s ease;
                    cursor: pointer;
                    border: none;
                }
                .download-btn:hover {
                    background-color: #1b5e20;
                }
                .redirect-msg {
                    font-size: 0.85rem;
                    color: #666;
                    margin-top: 15px;
                    font-weight: bold;
                }
            </style>
        </head>
        <body>

        <div class="success-wrapper">
            <div class="success-card">
                <i class='bx bx-check-circle'></i>
                <h3>Thanks a lot!</h3>
                <p>Your pledge has been uploaded successfully.<br> 
                <strong>Your will receive instructions on your email shortly...</strong></p>
                
                <!-- Manual Download trigger if auto fails -->
                <button class="download-btn" onclick="triggerDownload()">
                    <i class='bx bx-download'></i> Download PDF Receipt
                </button>
                
                <div class="redirect-msg">Redirecting back shortly...</div>
            </div>
        </div>

        <script>
        const base64Data = "{$base64Pdf}";
        const filename = "{$filename}";

        // Execution logic to download base64 string asset
        function triggerDownload() {
            const linkSource = `data:application/pdf;base64,\${base64Data}`;
            const downloadLink = document.createElement("a");
            downloadLink.href = linkSource;
            downloadLink.download = filename;
            document.body.appendChild(downloadLink);
            downloadLink.click();
            document.body.removeChild(downloadLink);
        }

// 1. Run automatic download on window mount
    window.onload = function() {
    triggerDownload();
            
// 2. Redirect back after 6 seconds to give time for operations
         setTimeout(function() {
            window.location.href = "http://localhost/MAX_ELECTRONICS_HUB";
            }, 6000);
        };
        </script>
        
        </body>
        </html>
HTML;
    exit();

        } catch (Exception $e) {
    error_log("Mailer Error: " . $mail->ErrorInfo);
        }

    // 8. DISPLAY SUCCESS ALERT CARD HTML
        echo <<<HTML
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Submission failure</title>
            <link href='https://unpkg.com' rel='stylesheet'>
            <style>
                .error-wrapper {
                    display: flex;
                    justify-content: center;
                    align-items: center;
                    height: 90vh;
                    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                    background-color: #f4f7f6;
                }
                .error-card {
                    position: fixed;
                    top: 50%;
                    left: 50%;
                    transform: translate(-50%, -50%);
                    background-color: #ffebee; /* Light red background */
                    color: #c62828;            /* Dark red text */
                    border-radius: 15px;
                    text-align: center;
                    box-shadow: 0 10px 30px rgba(0,0,0,0.1);
                    border: 1px solid #ffcdd2;
                    width: 300px;
                    padding:40px;
                }
                .error-card i {
                    font-size: 4.5rem;
                    display: block;
                    margin-bottom: 15px;
                }
                .error-card h3 { margin: 0; font-size: 1.7rem; }
                .error-card p { color: #444; margin-top: 8px; line-height: 1.3; font-size: 1.05rem;}
               
                .redirect-msg {
                    font-size: 0.85rem;
                    color: #666;
                    margin-top: 8px;
                    font-weight: bold;
                }
            </style>
        </head>
        <body>

        <div class="error-wrapper">
            <div class="error-card">
                <i class='bx bx-x-circle'></i>
                <h3>Error</h3>
                <p>Submission failed.<br> 
                <div class="redirect-msg">Redirecting you back shortly...</div>
            </div>
        </div>

        <script>
            
// 2. Redirect back after 6 seconds to give time for operations
         setTimeout(function() {
            window.location.href = "http://localhost/MAX_ELECTRONICS_HUB/appl/don.php";
            }, 6000);

        </script>
        
        </body>
        </html>
HTML;
        exit();

    } else {
        // Error Display Screen if DB execution fails
        echo <<<HTML
        <!DOCTYPE html>
        <html>
        <head>
            <link href='https://unpkg.com' rel='stylesheet'>
            <style>
                .error-wrapper { display: flex; justify-content: center; align-items: center; height: 60vh; font-family: sans-serif; }
                .error-card { background-color: #ffebee; color: #c62828; padding: 40px; border-radius: 15px; text-align: center; border: 1px solid #ffcdd2; max-width: 500px; }
                .error-card i { font-size: 4rem; display: block; margin-bottom: 15px; }
            </style>
        </head>
    }
HTML;
exit();
 }
}
?>