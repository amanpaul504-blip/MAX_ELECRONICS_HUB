<?php
session_start();
// Include the database connection file we created earlier
require_once 'db_config.php';

// Check if the form was actually submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
;
    // 1. Collect and sanitize input data
    $firstname    = trim($_POST['firstname']);
    $middlename   = trim($_POST['middlename']);
    $lastname     = trim($_POST['lastname']);
    $email        = trim($_POST['email']);
    $pnumber_a    = trim($_POST['pnumber_a']);
    $organisation = trim($_POST['organisation']);
    $nation       = trim($_POST['nation']);

    // 2. Prepare the SQL Statement
    $sql = "INSERT INTO donors (firstname, middlename, lastname, email, pnumber_a, organisation, nation) 
            VALUES (?, ?, ?, ?, ?, ?, ?)";

    $stmt = $conn->prepare($sql);

    if ($stmt) {
        // 3. Bind variables to the prepared statement
        // "sssssss" means we are sending 7 strings
        $stmt->bind_param("sssssss", $firstname, $middlename, $lastname, $email, $pnumber_a, $organisation, $nation);

        // 4. Execute the query
        if ($stmt->execute()) {
            $_SESSION['message'] = "Application submitted successfully!";
            header("Location: don_form.php?status=success");
            exit();
        } else {
            echo "Error during execution: " . $stmt->error;
        }

        // 5. Close the statement
        $stmt->close();
    } else {
        echo "Error preparing statement: " . $conn->error;
    }
}

// Close the database connection
$conn->close();
?>
