<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Donation Request Form</title>
  <link rel="stylesheet" href="don.css">
  <link href='https://boxicons.com' rel='stylesheet'>
</head>

<body>
  <header>
    <h2 align="center">DONATION REQUEST FORM</h2>
    <p align="center">Fill the form with correct details as per instructions on each field, 
       attach all necessary documents, then verify the details before you submit.</p>
  </header>

  <!-- Added enctype for document uploads -->
  <form class="application-form" action="don_connection.php" method="POST" enctype="multipart/form-data">
    <h3 align="center"><b>Personal Information</b></h3>

    <div class="form-group">
      <label for="firstname">First name</label>
      <input type="text" id="firstname" name="firstname" placeholder="eg. John" required />
    </div>

    <div class="form-group">
      <label for="middlename">Middle name</label>
      <input type="text" id="middlename" name="middlename" placeholder="eg. Andreas" required/>
    </div>

    <div class="form-group">
      <label for="lastname">Last name</label>
      <input type="text" id="lastname" name="lastname" placeholder="eg. Vandapult" required/>
    </div>

    <div class="form-group">
      <label for="email">Email</label>
      <input type="email" id="email" name="email" placeholder="eg. vandapult@gmail.com" required/>
    </div>

    <div class="form-group">
      <label for="pnumber_a">Phone Number</label>
      <input type="tel" id="pnumber_a" name="pnumber_a" placeholder="eg. +49 123 566 001" required/>
    </div>

    <div class="form-group">
      <label for="organisation">Name of the organisation</label>
      <input type="text" id="organisation" name="organisation" placeholder="eg. AYL" required/>
    </div>

    <div class="form-group">
      <label for="nation">Country</label>
      <select id="nation" name="nation" required>
        <option value="">Select country</option>
        <option value="Afghanistan">Afghanistan</option>
        <option value="Aland">Åland Islands</option>
        <option value="Albania">Albania</option>
        <option value="Tanzania">Tanzania</option>
        <option value="USA">USA</option>
      </select>
    </div>

    <!-- Added File Upload Field -->
    <div class="form-group">
      <label for="document">Supporting Document (PDF/JPG)</label>
      <input type="file" id="document" name="document" accept=".pdf,.jpg,.png" required>
    </div>

    <div class="form-group" style="margin-top: 20px;">
      <button type="submit" name="submit_don">Submit Request</button>
    </div>
  </form>
</body>
</html>
