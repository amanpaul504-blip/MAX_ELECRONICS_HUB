<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';

$mail = new PHPMailer(true);

try {
    $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com';
    $mail->SMTPAuth = true;

    // Your Gmail account
    $mail->Username = 'cybermisc4@gmail.com';

    // Your 16-character Gmail App Password
    $mail->Password = 'lhwx ywvh capu dioe';

    $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
    $mail->Port = 465;

    // Sender
    $mail->setFrom('cybermisc4@gmail.com', 'Community Initiatives for Healthy Life');

    // Applicant's email from the form
    $mail->addAddress($email, $firstname . ' ' . $lastname);

    // Attach generated PDF (optional)
    if (file_exists($pdfFile)) {
        $mail->addAttachment($pdfFile);
    }

    // Email content
    $mail->isHTML(true);
    $mail->Subject = 'Donation Receipt Received';

    $mail->Body = "
    Dear <b>$fname</b>,<br><br>

    Thank you for your donation to the Community Initiatives for Healthy Life.<br><br>

    We have successfully received your application and it is now under review.<br><br>

    Regards,<br>
    Community Health Initiative
    ";

    $mail->AltBody = "Dear $fname, Your application has been received successfully.";

    $mail->send();

} catch (Exception $e) {
    error_log("Mailer Error: " . $mail->ErrorInfo);
}
