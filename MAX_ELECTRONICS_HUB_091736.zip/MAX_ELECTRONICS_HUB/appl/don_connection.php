<?php
session_start();

// 1. Database Configuration
$host = "localhost";
$db_user = "root";
$db_pass = "";
$db_name = "appl_db"; // Change this to your actual DB name

// 2. Create Connection
$conn = new mysqli($host, $db_user, $db_pass, $db_name);

// Check Connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// 3. Process Form Submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    // Sanitize inputs
    $fname = trim($_POST['firstname']);
    $mname = trim($_POST['middlename']);
    $lname = trim($_POST['lastname']);
    $email = filter_var(trim($_POST['email']), FILTER_SANITIZE_EMAIL);
    $phone = trim($_POST['pnumber_a']);
    $org   = trim($_POST['organisation']);
    $country = trim($_POST['nation']);
    $category = trim($_POST['categories']);
    $amount = trim($_POST['amount']);
    $payment = trim($_POST['payment']);
    $comment = trim($_POST['comment']);

    // 4. Basic Validation
    if (empty($fname) || empty($email) || empty($country) || empty($category)) {
        $_SESSION['status'] = "Please fill in all required fields.";
        header("Location: don_form.php");
        exit();
    }

    // 5. Use Prepared Statement for Security
    $sql = "INSERT INTO donation_requests (firstname, middlename, lastname, email, phone, organisation, country, category, amount, payment, comment) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    $stmt = $conn->prepare($sql);

    // Corrected: Added quotes around types string "sssssssssss"
    // NOTE: Ensure amount/payment are strings or change 's' to 'i'/'d' for integers/doubles
    $stmt->bind_param("sssssssssss", $fname, $mname, $lname, $email, $phone, $org, $country, $categories, $amount, $payment, $comment);

    if ($stmt->execute()) {http://localhost/MAX_ELECTRONICS_HUB/Application.php"; // Update with your actual URL
    $timeout_milliseconds = 3000;  // 3 seconds

    echo <<<HTML
    <link href='https://cdn.boxicons.com/3.0.6/fonts/brands/boxicons-brands.min.css' rel='stylesheet'>
        <link href='https://cdn.boxicons.com/3.0.6/fonts/basic/boxicons.min.css' rel='stylesheet'>
    <link href='unpkg.com' rel='stylesheet'>
    
    <style>
        .success-wrapper {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 80vh;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .success-card {
            background-color: #e0f2f1;
            color: #2e7d32;
            padding: 40px;
            border-radius: 15px;
            text-align: center;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            border: 1px solid #a5d6a7;
            max-width: 500px;
        }
        .success-card i {
            font-size: 4rem;
            display: block;
            margin-bottom: 15px;
        }
        .success-card h3 { margin: 0; font-size: 1.5rem; }
        .success-card p { color: #555; margin-top: 10px; }
    </style>

    <div class="success-wrapper">
        <div class="success-card">
            <i class='bx bx-check-circle'></i>
            <h3>Thanks a lot!</h3>
            <p>Your application has been uploaded successfully.<br> 
            <strong>You will receive a response message in your email shortly.....</strong></p>
        </div>
    </div>

    <script>
    // Configuration: Set redirect back to form or home
    const redirectUrl = "http://localhost/MAX_ELECTRONICS_HUB"; 
    const timeout = 5000; // Longer delay for errors so they can read the message

    setTimeout(function() {
        window.location.href = redirectUrl;
    }, timeout);
    </script>
    
    HTML;

    } else {
    echo <<<HTML
    <link href='https://cdn.boxicons.com/3.0.6/fonts/brands/boxicons-brands.min.css' rel='stylesheet'>
        <link href='https://cdn.boxicons.com/3.0.6/fonts/basic/boxicons.min.css' rel='stylesheet'>
    <link href='unpkg.com' rel='stylesheet'>
    <style>
        .error-wrapper {
        display: flex;
        justify-content: center;
        align-items: center;
        height: 80vh;
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        .error-card {
        background-color: #ffebee; /* Light red background */
        color: #c62828;            /* Dark red text */
        padding: 40px;
        border-radius: 15px;
        text-align: center;
        box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        border: 1px solid #ffcdd2;
        max-width: 500px;

        }
        /* Icon styling */
        .error-card i {
        font-size: 4rem;
        display: block;
        margin-bottom: 15px;
        }
        .error-card h3 { margin: 0; font-size: 1.5rem; }
        .http://localhost/MAX_ELECTRONICS_HUB/Application.phpn-top: 10px; }
    
        /* Retry Button (Optional but helpful for errors) */
        .retry-btn {
        margin-top: 20px;
        display: inline-block;
        padding: 10px 20px;
        background-color: #c62828;
        color: white;
        text-decoration: none;
        border-radius: 5px;
        font-weight: bold;
        }
    </style>

    <div class="error-wrapper">
    <div class="error-card">
        <!-- Error icon (X circle) -->
        <i class='bx bx-x-circle'></i>
        <h3>Submission Failed</h3>
        <p>We encountered an error while processing your application.<br> 
        <strong>Redirecting you back to try again...</strong></p>
    </div>
    </div>

    <script>
    // Configuration: Set redirect back to form or home
    const redirectUrl = "http://localhost/MAX_ELECTRONICS_HUB/Application.php"; 
    const timeout = 5000; // Longer delay for errors so they can read the message

    setTimeout(function() {
        window.location.href = redirectUrl;
    }, timeout);
    </script>
    HTML;

    }
    $stmt->close();
    $conn->close();
}
?>
