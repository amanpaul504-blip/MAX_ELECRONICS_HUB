CREATE DATABASE IF NOT EXISTS appl_db CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE appl_db;

CREATE TABLE IF NOT EXISTS regis_form (
 id INT AUTO_INCREMENT PRIMARY KEY, fname VARCHAR(100) NOT NULL, lname VARCHAR(100) NOT NULL,
 email VARCHAR(255) NOT NULL UNIQUE, password VARCHAR(255) NOT NULL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS admn (
 id INT AUTO_INCREMENT PRIMARY KEY, firstname VARCHAR(100) NOT NULL, lastname VARCHAR(100) NOT NULL,
 email VARCHAR(255) NOT NULL UNIQUE, password VARCHAR(255) NOT NULL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO admn (firstname, lastname, email, password) VALUES ('MAX', 'Administrator', 'cybermisc4@gmail.com', '$2y$12$qwHBK5TAfV/8l2WDCzX.lO90wcnT95dLRdRDCelAis/X4tL0mqOyC') ON DUPLICATE KEY UPDATE password=VALUES(password), firstname=VALUES(firstname), lastname=VALUES(lastname);

CREATE TABLE IF NOT EXISTS products (
 id INT AUTO_INCREMENT PRIMARY KEY,
 name VARCHAR(180) NOT NULL,
 category VARCHAR(100) NOT NULL,
 description TEXT,
 price DECIMAL(12,2) NOT NULL DEFAULT 0,
 icon VARCHAR(20) DEFAULT '📦',
 active TINYINT(1) NOT NULL DEFAULT 1,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS orders (
 id INT AUTO_INCREMENT PRIMARY KEY,
 customer_name VARCHAR(150) NOT NULL,
 phone VARCHAR(50) NOT NULL,
 email VARCHAR(255),
 address TEXT NOT NULL,
 total DECIMAL(12,2) NOT NULL,
 status VARCHAR(30) NOT NULL DEFAULT 'Pending',
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS order_items (
 id INT AUTO_INCREMENT PRIMARY KEY,
 order_id INT NOT NULL,
 product_id INT NOT NULL,
 quantity INT NOT NULL,
 price DECIMAL(12,2) NOT NULL,
 FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
 FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE RESTRICT
);

INSERT INTO products (name,category,description,price,icon) VALUES
('Fast USB-C Charger','Chargers','Compact fast charger for compatible smartphones and tablets.',25000,'🔌'),
('Dual USB Wall Charger','Chargers','Two-port charger for charging multiple devices.',18000,'⚡'),
('USB-C Fast Charging Cable','Cables','Durable USB-C cable for charging and data transfer.',12000,'🔗'),
('Lightning Charging Cable','Cables','Reliable charging and sync cable for Lightning devices.',15000,'🔗'),
('Wireless Bluetooth Earbuds','Audio','Compact wireless earbuds for music and calls.',45000,'🎧'),
('Wired Stereo Earphones','Audio','Lightweight earphones with microphone and clear sound.',15000,'🎧'),
('10000mAh Power Bank','Power','Portable power bank for phones and small devices.',35000,'🔋'),
('20000mAh Power Bank','Power','High-capacity power bank for extended charging.',65000,'🔋'),
('Phone Holder Stand','Phone Accessories','Adjustable stand for desks, videos and calls.',18000,'📱'),
('Tempered Glass Screen Protector','Phone Accessories','Protective tempered glass for selected smartphones.',10000,'🛡️');
-- MAX ELECTRONICS HUB admin username
-- The admin login username is the email below.
UPDATE admn SET email = 'cybermisc4@gmail.com' WHERE id = 1;
