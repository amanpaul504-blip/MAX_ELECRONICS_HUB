<?php
session_start();
require 'C:/xampp/htdocs/MAX_ELECTRONICS_HUB/res/includes/dB_pwd.php';      

/* Get login values */
$email = trim($_POST['email'] ?? '');
$password = $_POST['password'] ?? '';


/* Find user */
$stmt = $conn->prepare(
    "SELECT id, firstname, lastname, email, password
     FROM admn
     WHERE email = ?
     LIMIT 1"
);

$stmt->bind_param("s", $email);
$stmt->execute();

$result = $stmt->get_result();

if ($result->num_rows === 0) {

    $_SESSION['login_error'] = 'Invalid email or password.';
    $_SESSION['show_login'] = true;

    header('Location: adm.php');
    exit;
}


$user = $result->fetch_assoc();


/* Check password */
if (!password_verify($password, $user['password'])) {
    $_SESSION['login_error'] = 'Invalid email or password.';
    $_SESSION['show_login'] = true;
    header('Location: adm.php');
    exit;
}

/* ==========================
   LOGIN SUCCESSFUL
========================== */
$_SESSION['logged_in'] = true;
$_SESSION['user_id'] = $user['id'];
$_SESSION['user_name'] =
    trim($user['firstname'] . ' ' . $user['lastname']);
$_SESSION['email'] = $user['email'];


/* Open report page */
header('Location: report_management.php');
exit;
