<?php
require "C:/xampp/htdocs/MAX_ELECTRONICS_HUB/appl/header.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://cdn.boxicons.com/3.0.6/fonts/basic/boxicons.min.css' rel='stylesheet'>
    <link href='https://cdn.boxicons.com/3.0.6/fonts/brands/boxicons-brands.min.css' rel='stylesheet'>
</head>

<style>

/* Reset basic spacing styles */
* {
    box-sizing: border-box;
    margin: 0;
    padding: 0;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
}

/* Page wrapper centering the form box */
main {
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 100vh;
    background: linear-gradient(135deg, #4f46e5, #06b6d4);
    padding: 20px;
}

/* Core Form Container Layout */
.form-container {
    position: relative;
    display: flex;
    flex-direction: row;
    background: rgba(255, 255, 255, 0.15);
    max-width: 680px;
    width: 100%;
    border-radius: 12px;
    box-shadow: 0 10px 25px rgba(0, 0, 0, 0.08);
    overflow: hidden;
    padding: 20px;
}

/* Absolute Positioned Close Button (x) */
.close-btn {
   position: absolute;
   top: 0;
   right: 0;
   width: 30px;
   height: 30px;
   background: whitesmoke;
   border-bottom-left-radius: 10px;
   display: flex;
   justify-content: center;
   align-items: center;
   font-size: 1.2rem;
   color: blue;
   cursor: pointer;
   z-index: 10;
   transition: background 0.3s ease, color 0.3s ease;
}

 .close-btn:hover {
   background: skyblue;
   color: #ef4444;
   font-weight: bold;
}
/* Left Side - Plantation Image Panel */
.left-side {
    display: flex;
    align-items: center;
    justify-content: center;
    background-color: #f9f9f9;
}

.left-side img {
    object-fit: cover;
    display: block;
}

/* Right Side - Form Input Content */
.right-side {
    flex: 1;
    display: flex;
    flex-direction: column;
    padding: 10px 25px;
}

.right-side section {
    display: flex;
    flex-direction: column;
    margin-top: 10px;
}

/* Typography Rules */
h2 {
    color: #2c3e50;
    font-size: 22px;
    margin-bottom: 10px;
    font-weight: 600;
    text-align: center;
}

p {
    color: whitesmoke;
    font-size: 13.5px;
    line-height: 1.5;
    margin-bottom: 20px;
    text-align: center;
}

/* Form Fields Styling */
form {
    display: flex;
    flex-direction: column;
    gap: 15px;
}

input[type="email"] {
    width: 100%;
    padding: 12px 14px;
    border: 1.5px solid #dcdde1;
    border-radius: 6px;
    font-size: 14px;
    color: #2f3640;
    outline: none;
    transition: border-color 0.2s;
}

input[type="email"]:focus {
    border-color: #2ecc71; /* Subtle plantation green focus border */
}

input[type="email"]:hover {
    border-color: #2ecc71; /* Subtle plantation green focus border */
    background-color: whitesmoke;
}

/* Action Trigger Button */
button[type="submit"] {
    background-color: #CDE0E9; /*soft cloud blue*/
    color: blue;
    border: none;
    padding: 12px;
    font-size: 15px;
    font-weight: 600;
    border-radius: 6px;
    cursor: pointer;
    transition: background-color 0.2s;
}

button[type="submit"]:hover {
    background-color: #87CEEB; /* sky blue color */
    color: whitesmoke;
}

/* PHP Success Message Box */
.signupsuccess {
    margin-top: 15px;
    padding: 10px;
    background-color: #d4edda;
    color: #155724;
    border: 1px solid #c3e6cb;
    border-radius: 6px;
    font-size: 13px;
    text-align: center;
    font-weight: 500;
}

/* Responsive Rules for Small Devices (Phones) */
@media (max-width: 600px) {
    .form-container {
        flex-direction: column;
    }
    .left-side {
        display: none; /* Auto-hides image pane on mobile screens to save space */
    }
    .right-side {
        padding: 15px 10px;
    }
}

</style>
<body>
    <main>
    <div class="form-container">
         <span class="close-btn" onclick="window.location.href='http://localhost/MAX_ELECTRONICS_HUB/admin/adm.php';" style="cursor: pointer;">X</span>


        <!--Left Side-->
         <div class= "left-side"><img src= "http://localhost/MAX_ELECTRONICS_HUB/Tea_Plantation.jpg" style="width: 280px;height: 300px; border-radius: 10px;"  alt="Plantation">
        </div>

        <!--Right Side-->
        <div class="right-side">
        <img src="http://localhost/MAX_ELECTRONICS_HUB/res/Logoo.jpg" style= "align-self: center; border-radius: 50%; width: 70px; height: 70px; border: .5px solid;color: red; margin-bottom: 2px; margin-top: 15px; position: relative;"class="logo" alt="Logoo">
    <section>
        <h2>Forgot your password?</h2>
        <p>Enter your email address below, then instructions to reset your password will be sent through it.</p>
       <!-- Your form element -->
    <form action="res_request.php" method="POST">
        <input type="email" id="userEmail" name="email" placeholder="eg. jessie@gmail.com" required>
        <button type="submit" name="res_request_submit">Reset Password</button>
    </form>
    </div>
    
        <?php
        if (isset($_GET["reset"])) {
            if ($_GET["reset"] == "success") {
            echo '<p class="signupsuccess">Check your e-mail!</p>';
           }
          }
        ?>
    </section>
</div>
</main>
</body>
</html>

<?php
require "C:/xampp/htdocs/MAX_ELECTRONICS_HUB/appl/footer.php";
?>
