<?php

session_start();

require_once __DIR__ . '/../config.php';

/* Only allow logged-in users */
if (
    !isset($_SESSION['logged_in']) ||
    $_SESSION['logged_in'] !== true
) {
    header('Location: adm.php');
    exit;
}

/* Get logged-in user information */
$userName  = $_SESSION['user_name'] ?? '';
$userEmail = $_SESSION['email'] ?? '';

/* Get first initial of first name */
$firstName = trim(explode(' ', $userName)[0]);

$initial = $firstName !== ''
    ? strtoupper(substr($firstName, 0, 1))
    : 'U';

$successMessage = '';
$errorMessage = '';
$donationCategories = [];
$donationRows = [];

function getDonationRows(mysqli $conn, string $category, string $country = '', ?int $id = null): array
{
    if ($id !== null) {
        $stmt = $conn->prepare('SELECT * FROM donation_requests WHERE id = ?');
        if (!$stmt) {
            return [];
        }
        $stmt->bind_param('i', $id);
    } else {
        $stmt = $conn->prepare(
            "SELECT * FROM donation_requests
             WHERE FIND_IN_SET(?, REPLACE(category, ', ', ',')) > 0
             AND (? = '' OR country = ?)
             ORDER BY id DESC"
        );
        if (!$stmt) {
            return [];
        }
        $stmt->bind_param('sss', $category, $country, $country);
    }

    $rows = [];
    if ($stmt->execute()) {
        $result = $stmt->get_result();
        while ($row = $result->fetch_assoc()) {
            $rows[] = $row;
        }
        $result->free();
    }
    $stmt->close();
    return $rows;
}

function outputDonationPdf(array $rows, string $title, string $filename, string $period = ''): void
{
    require_once __DIR__ . '/../appl/fpdf.php';

    $pdf = new FPDF('L', 'mm', 'A4');
    $pdf->SetTitle($title);
    $pdf->SetMargins(8, 8, 8);
    $pdf->SetAutoPageBreak(true, 10);
    $pdf->AddPage();
    $pdf->SetFont('Arial', 'B', 15);
    $pdf->Cell(0, 10, $title, 0, 1, 'C');
    if ($period !== '') {
        $pdf->SetFont('Arial', '', 10);
        $pdf->Cell(0, 7, 'Report duration: ' . $period, 0, 1, 'C');
    }
    $pdf->Ln(3);

    foreach ($rows as $row) {
        $pdf->SetFont('Arial', 'B', 10);
        $pdf->Cell(0, 7, 'Donation #' . ($row['id'] ?? ''), 0, 1);
        $pdf->SetFont('Arial', '', 9);
        foreach ($row as $column => $value) {
            $label = ucwords(str_replace('_', ' ', $column));
            $pdf->MultiCell(0, 5, $label . ': ' . (string) $value, 0, 'L');
        }
        $pdf->Ln(4);
        $pdf->Line(8, $pdf->GetY(), 289, $pdf->GetY());
        $pdf->Ln(4);
    }

    $pdf->Output('D', $filename);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'GET' && ($_GET['action'] ?? '') === 'donation_pdf') {
    $donationId = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
    $rows = $donationId ? getDonationRows($conn, '', '', $donationId) : [];
    if (!$rows) {
        http_response_code(404);
        exit('Donation record not found.');
    }
    $donorName = trim(($rows[0]['firstname'] ?? '') . '_' . ($rows[0]['lastname'] ?? ''));
    outputDonationPdf($rows, 'Donation Pledge', 'Donation_Pledge_' . ($donorName ?: $donationId) . '.pdf');
}

if ($_SERVER['REQUEST_METHOD'] === 'GET' && ($_GET['action'] ?? '') === 'donation_report_pdf') {
    $category = trim($_GET['category'] ?? '');
    $country = trim($_GET['country'] ?? '');
    $startDate = trim($_GET['start_date'] ?? '');
    $endDate = trim($_GET['end_date'] ?? '');
    $rows = $category !== '' ? getDonationRows($conn, $category, $country) : [];
    if (!$rows) {
        http_response_code(404);
        exit('No donation records found for this report.');
    }
    $period = $startDate !== '' && $endDate !== ''
        ? date('d M Y', strtotime($startDate)) . ' - ' . date('d M Y', strtotime($endDate))
        : '';
    outputDonationPdf($rows, 'Donation Pledge Report', 'Donation_Report.pdf', $period);
}

if ($_SERVER['REQUEST_METHOD'] === 'GET' && ($_GET['action'] ?? '') === 'donation_countries') {
    $selectedCategory = trim($_GET['category'] ?? '');
    $countries = [];

    if ($selectedCategory !== '') {
        $countryStmt = $conn->prepare(
            "SELECT DISTINCT country FROM donation_requests
             WHERE country IS NOT NULL AND TRIM(country) <> ''
             AND FIND_IN_SET(?, REPLACE(category, ', ', ',')) > 0
             ORDER BY country"
        );

        if ($countryStmt) {
            $countryStmt->bind_param('s', $selectedCategory);
            if ($countryStmt->execute()) {
                $countryResult = $countryStmt->get_result();
                while ($countryRecord = $countryResult->fetch_assoc()) {
                    $countries[] = $countryRecord['country'];
                }
                $countryResult->free();
            }
            $countryStmt->close();
        }
    }

    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($countries);
    exit;
}

$categoryResult = $conn->query(
    "SELECT category FROM donation_requests WHERE category IS NOT NULL AND TRIM(category) <> ''"
);

if ($categoryResult) {
    while ($categoryRecord = $categoryResult->fetch_assoc()) {
        foreach (explode(',', $categoryRecord['category']) as $category) {
            $category = trim($category);
            if ($category !== '') {
                $donationCategories[$category] = $category;
            }
        }
    }
    $categoryResult->free();
}
$donationCategories = array_values($donationCategories);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['generate_report'])) {
    $selectedReport = trim($_POST['selected_report'] ?? '');
    $reportFormat = trim($_POST['report_format'] ?? '');
    $startDate = $_POST['start_date'] ?? '';
    $endDate = $_POST['end_date'] ?? '';
    $costSharingName = trim($_POST['cost_sharing_name'] ?? $_POST['field_selected'] ?? $_POST['area_of_interest'] ?? '');
    $costSharingGroup = trim($_POST['cost_sharing_group'] ?? $_POST['country_of_origin'] ?? '');

    if (preg_match('/donation.*pledge|donations.*pledge/i', $selectedReport) && $costSharingName !== '') {
        $donationRows = getDonationRows($conn, $costSharingName, $costSharingGroup);
    }

    if ($selectedReport === '' || $reportFormat === '' || $startDate === '' || $endDate === '') {
        $errorMessage = 'Please select a report and fill in the required date and format fields.';
    } else {
        $reportTableSql = "
            CREATE TABLE IF NOT EXISTS report_requests (
                id INT AUTO_INCREMENT PRIMARY KEY,
                selected_report VARCHAR(255) NOT NULL,
                report_format VARCHAR(50) NOT NULL,
                start_date DATE NOT NULL,
                end_date DATE NOT NULL,
                cost_sharing_name VARCHAR(255) DEFAULT NULL,
                cost_sharing_group VARCHAR(255) DEFAULT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ";

        if (!$conn->query($reportTableSql)) {
            $errorMessage = 'Unable to prepare the report requests table: ' . $conn->error;
        } else {
            $stmt = $conn->prepare(
                'INSERT INTO report_requests (selected_report, report_format, start_date, end_date, cost_sharing_name, cost_sharing_group) VALUES (?, ?, ?, ?, ?, ?)'
            );

            if (!$stmt) {
                $errorMessage = 'Database statement preparation failed.';
            } else {
                $stmt->bind_param(
                    'ssssss',
                    $selectedReport,
                    $reportFormat,
                    $startDate,
                    $endDate,
                    $costSharingName,
                    $costSharingGroup
                );

                if ($stmt->execute()) {
                    $successMessage = 'Report request saved successfully.';
                } else {
                    $errorMessage = 'Unable to save the report request: ' . $stmt->error;
                }

                $stmt->close();
            }
        }
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Report Management</title>
    <link rel="stylesheet"
          href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <link rel="stylesheet" href="report.css">
</head>
<body>

<!-- ================= HEADER ================= -->
<header class="top-header">
    <div class="brand">
        <button class="menu-btn" onclick="toggleSidebar()">
            <i class="fa-solid fa-bars"></i>
        </button>
        <span><img src= "http://localhost/MAX_ELECTRONICS_HUB/CIHL.jpg" style="width: 90px;height: 90px; border-radius: 50%; margin-top: 19px; border: 0.1px solid ghostwhite;"  alt="Logo"></span>
    </div>
    <div class="header-right">
        <div class="search-box">
            <i class="fa-solid fa-magnifying-glass"></i>
            <input type="text" placeholder="Search...">
        </div>

        <div class="icons">
            <i class="fa-solid fa-globe"></i>
            <i class="fa-solid fa-bell"></i>
        </div>

    <div class="user-email">
            <strong>
                    <?php echo htmlspecialchars($userEmail); ?>
            </strong>
    </div>
    
        <div class="user-menu">
   <div class="avatar-wrapper">
    <button type="button"
            class="header-avatar"
            id="avatarButton"
            aria-label="User menu"
            aria-expanded="false">
        <?php echo htmlspecialchars($initial); ?>
    </button>

    <div class="avatar-menu" id="avatarMenu">
        <div class="avatar-menu-user">
            <strong>
                <?php echo htmlspecialchars($userName); ?>
            </strong>

            <small>
                <?php echo htmlspecialchars($userEmail); ?>
            </small>
        </div>

        <div class="avatar-divider"></div>

        <a href="logout.php" class="logout-link">
            <i class="fa-solid fa-right-from-bracket"></i>
            Logout
        </a>
    </div>
</div>

</header><br><br>
<!-- ================= PAGE ================= -->
<div class="page-container">
    <!-- ================= SIDEBAR ================= -->
    <aside class="sidebar" id="sidebar">
        <div class="profile">
            <h3>
                <?php echo htmlspecialchars($userName); ?>
            </h3>
            <div class="profile-status">
                <span class="not-verified">
                    <i class="fa-solid fa-circle-exclamation"></i>
                    Administrator
                </span>
            </div>
        </div>


        <!-- Dashboard -->
        <a href="#" class="menu-item">
            <i class="fa-solid fa-house"></i>
            <span>Dashboard</span>
        </a>
        <!-- Reports -->
        <div class="menu-section active">
            <div class="menu-title" onclick="toggleReports()">
                <span>
                    <i class="fa-solid fa-chart-column"></i>
                    Reports
                </span>
                <i class="fa-solid fa-chevron-down"></i>
            </div>


            <div class="submenu" id="reportsMenu">
                <a href="#" class="submenu-item selected">
                    <i class="fa-solid fa-briefcase"></i>
                    Facility Report
                </a>
                <a href="#" class="submenu-item">
                    <i class="fa-solid fa-briefcase"></i>
                    Mtuha Report
                </a>
            </div>
        </div>
    </aside>



    <!-- ================= MAIN CONTENT ================= -->
    <main class="main-content">
        <!-- Breadcrumb -->
        <div class="breadcrumb">
            <i class="fa-solid fa-house"></i>
            <i class="fa-solid fa-chevron-right"></i>
            <span>Reports Management</span>
            <i class="fa-solid fa-chevron-right"></i>
            <span class="current">
                Report Contents
            </span>
        </div>
        <!-- Page heading -->
        <section class="page-heading">

            <div class="heading-icon">
                <i class="fa-solid fa-print"></i>
            </div>

            <div>
                <h1>Report Management</h1>
                <p>
                    Report Management and Requisitions
                </p>
            </div>
        </section>

        <!-- ================= REPORT AREA ================= -->
        <section class="report-area">

            <?php if ($successMessage !== ''): ?>
                <div class="db-status success"><?php echo htmlspecialchars($successMessage); ?></div>
            <?php endif; ?>

            <?php if ($errorMessage !== ''): ?>
                <div class="db-status error"><?php echo htmlspecialchars($errorMessage); ?></div>
            <?php endif; ?>

            <?php if ($donationRows): ?>
                <div class="donation-results report-print-container" id="donationReport">
                    <div class="donation-results-heading">
                        <div>
                            <h2>Donation Pledge Results</h2>
                            <p class="report-duration">
                                Report duration:
                                <?php echo htmlspecialchars(date('d M Y', strtotime($startDate))); ?>
                                -
                                <?php echo htmlspecialchars(date('d M Y', strtotime($endDate))); ?>
                            </p>
                            <p class="report-filter-summary">
                                Area of interest: <?php echo htmlspecialchars($costSharingName); ?>
                                <?php if ($costSharingGroup !== ''): ?>
                                    | Country: <?php echo htmlspecialchars($costSharingGroup); ?>
                                <?php endif; ?>
                            </p>
                        </div>
                        <div class="report-actions">
                            <button type="button" class="report-action-btn print-report-btn" onclick="printReport()">
                                <i class="fa-solid fa-print"></i> Print Report
                            </button>
                            <a class="report-action-btn" target="_blank"
                           href="report_management.php?action=donation_report_pdf&amp;category=<?php echo urlencode($costSharingName); ?>&amp;country=<?php echo urlencode($costSharingGroup); ?>&amp;start_date=<?php echo urlencode($startDate); ?>&amp;end_date=<?php echo urlencode($endDate); ?>">
                                <i class="fa-solid fa-file-pdf"></i> Download PDF
                            </a>
                        </div>
                    </div>
                    <div class="donation-results-table">
                        <table>
                            <thead>
                                <tr>
                                    <?php foreach (array_keys($donationRows[0]) as $column): ?>
                                        <th><?php echo htmlspecialchars(ucwords(str_replace('_', ' ', $column))); ?></th>
                                    <?php endforeach; ?>
                                    <th>PDF</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($donationRows as $donationRow): ?>
                                    <tr>
                                        <?php foreach ($donationRow as $value): ?>
                                            <td><?php echo htmlspecialchars((string) $value); ?></td>
                                        <?php endforeach; ?>
                                        <td>
                                            <a target="_blank"
                                               href="report_management.php?action=donation_pdf&amp;id=<?php echo (int) $donationRow['id']; ?>"
                                               aria-label="Download PDF for donation <?php echo (int) $donationRow['id']; ?>">
                                                <i class="fa-solid fa-file-pdf"></i> Download
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            <?php elseif ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['generate_report']) && $costSharingName !== ''): ?>
                <div class="db-status">No donation records were found for the selected area of interest.</div>
            <?php endif; ?>

            <!-- LEFT REPORT TREE -->
            <div class="report-list">

                <div class="selected-report">

                    Selected Report:
                    <strong>
                        -
                    </strong>

                </div>


                <!-- Search reports -->
                <div class="report-search">

                    <input
                        type="text"
                        id="reportSearch"
                        placeholder="Filter Reports"
                        onkeyup="filterReports()">

                    <i class="fa-solid fa-magnifying-glass"></i>

                </div>



                <!-- Report tree -->
                <div class="tree" id="reportTree">


                    <div class="tree-folder">

                        <div class="tree-title"
                             onclick="toggleFolder(this)">

                            <i class="fa-solid fa-chevron-down"></i>

                            <i class="fa-regular fa-folder"></i>

                            <span style="font-weight: bold;">
                                REPORTS MANAGEMENT
                            </span>

                        </div>


                        <div class="tree-children">


                            <div class="tree-folder">

                                <div class="tree-title"
                                     onclick="toggleFolder(this)">

                                    <i class="fa-solid fa-chevron-down"></i>

                                    <i class="fa-regular fa-folder"></i>

                                    <span style="font-weight:bold; font-family: sans-serif;">
                                        User Applications
                                    </span>

                                </div>


                                <div class="tree-children">


                                    <div class="report-option"
                                     onclick="selectReport(this, '-')">
                                        <i class="fa-regular fa-folder"></i>
                                        Internship Applications
                                    </div>

                                    <div class="report-option"
                                        onclick="selectReport(this, '-')">
                                        <i class="fa-regular fa-folder"></i>
                                        Medical Service Volunteer Applications
                                    </div>

                                    <div class="report-option"
                                         onclick="selectReport(this, '-')">
                                        <i class="fa-regular fa-folder"></i>
                                        Donation Pledge
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- RIGHT FORM -->
            <div class="report-form">
                <form method="POST" action="report_management.php">
                    <div class="report-container-box">
                        <div class="selected-report-box">
                            <i class="fa-solid fa-folder" style="color:#4b9e94;"></i>
                            <span style="color:#197b70;"><strong id="selectedReport">-</strong></span>
                        </div>

                        <input type="hidden" name="selected_report" id="selected_report_input" value="-">

                        <label>Select Report Format *</label>
                        <select name="report_format" required>
                            <option value="">Select Report Format</option>
                            <option value="PDF">PDF</option>
                            <option value="Excel">Excel</option>
                        </select>

                        <div class="date-row">
                            <div>
                                <label>Start Date *</label>
                                <input type="date" name="start_date" required>
                            </div>
                            <div>
                                <label>End Date *</label>
                                <input type="date" name="end_date" required>
                            </div>
                        </div>

                        <label id="dynamicLabelOne">Cost Sharing Name</label>
                        <select id="dynamicFieldOne" name="cost_sharing_name">
                            <option value="">Select Cost Sharing Name</option>
                            <option value="Finance Office">Finance Office</option>
                            <option value="Operations Unit">Operations Unit</option>
                            <option value="Procurement Team">Procurement Team</option>
                        </select>

                        <label id="dynamicLabelTwo">Cost Sharing Group</label>
                        <select id="dynamicFieldTwo" name="cost_sharing_group">
                            <option value="">Select Cost Sharing Group</option>
                            <option value="Administration">Administration</option>
                            <option value="Healthcare">Healthcare</option>
                            <option value="Community Support">Community Support</option>
                        </select>

                        <button type="submit" name="generate_report" value="1" class="generate-btn">
                            <i class="fa-solid fa-file-export"></i> Generate Report
                        </button>
                    </div>
                </form>
            </div>
        </section>
    </main> <!-- Close main content element block -->
</div> <!-- Close main page-container wrapper -->


<script>
const donationCategories = <?php echo json_encode($donationCategories, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP); ?>;

function toggleReports() {
    const reportsMenu = document.getElementById("reportsMenu");
    const reportsSection = reportsMenu ? reportsMenu.closest(".menu-section") : null;

    if (!reportsMenu || !reportsSection) {
        return;
    }

    const isOpen = reportsSection.classList.toggle("active");
    reportsMenu.style.display = isOpen ? "block" : "none";
}

function toggleFolder(folderTitle) {
    const folder = folderTitle.closest(".tree-folder");
    const children = folder ? folder.querySelector(":scope > .tree-children") : null;

    if (!folder || !children) {
        return;
    }

    const isOpen = folder.classList.toggle("is-open");
    children.style.display = isOpen ? "block" : "none";

    const chevron = folderTitle.querySelector(".fa-chevron-down, .fa-chevron-right");
    if (chevron) {
        chevron.classList.toggle("fa-chevron-down", isOpen);
        chevron.classList.toggle("fa-chevron-right", !isOpen);
    }
}

function updateFieldLabels(reportName) {
    const usesApplicationFields = /internship|medical service volunteer/i.test(reportName || '');
    const usesDonationFields = /donation.*pledge|donations.*pledge/i.test(reportName || '');
    const labelOne = document.getElementById('dynamicLabelOne');
    const fieldOne = document.getElementById('dynamicFieldOne');
    const labelTwo = document.getElementById('dynamicLabelTwo');
    const fieldTwo = document.getElementById('dynamicFieldTwo');

    if (!labelOne || !fieldOne || !labelTwo || !fieldTwo) {
        return;
    }

    if (usesApplicationFields) {
        labelOne.textContent = 'Field selected';
        fieldOne.name = 'field_selected';
        fieldOne.onchange = null;
        fieldOne.innerHTML = `
            <option value="">Select Field Selected</option>
            <option value="Agriculture">Agriculture</option>
            <option value="Healthcare">Healthcare</option>
            <option value="Education">Education</option>
            <option value="Community Development">Community Development</option>
            <option value="Medical Services">Medical Services</option>
        `;

        labelTwo.textContent = 'Country of origin';
        fieldTwo.name = 'country_of_origin';
        fieldTwo.innerHTML = '<option value="">Loading countries...</option>';

        fetch('../appl/profv.php')
            .then(response => response.text())
            .then(html => {
                const parser = new DOMParser();
                const doc = parser.parseFromString(html, 'text/html');
                const countryOptions = Array.from(doc.querySelectorAll('#nation option'))
                    .map(option => ({
                        value: option.value.trim(),
                        text: option.textContent.trim()
                    }))
                    .filter(option => option.value && option.text && option.text !== 'Select country' && option.text !== 'Select Country');

                if (countryOptions.length === 0) {
                    fieldTwo.innerHTML = '<option value="">Select Country of Origin</option>';
                    return;
                }

                fieldTwo.innerHTML = '<option value="">Select Country of Origin</option>' +
                    countryOptions.map(option => 
                        '<option value="' + option.value + '">' + option.text + '</option>'
                    ).join('');
            })
            .catch(() => {
                fieldTwo.innerHTML = '<option value="">Select Country of Origin</option>';
            });
    } else if (usesDonationFields) {
        labelOne.textContent = 'Area of interest';
        fieldOne.name = 'area_of_interest';
        fieldOne.innerHTML = '<option value="">Select Area of Interest</option>' +
            donationCategories.map(category =>
                '<option value="' + category + '">' + category + '</option>'
            ).join('');

        labelTwo.textContent = 'Country of origin';
        fieldTwo.name = 'country_of_origin';
        fieldTwo.innerHTML = '<option value="">Select Area of Interest first</option>';
        fieldOne.onchange = function () {
            loadDonationCountries(this.value, fieldTwo);
        };
    } else {
        labelOne.textContent = 'Cost Sharing Name';
        fieldOne.name = 'cost_sharing_name';
        fieldOne.onchange = null;
        fieldOne.innerHTML = `
            <option value="">Select Cost Sharing Name</option>
            <option value="Finance Office">Finance Office</option>
            <option value="Operations Unit">Operations Unit</option>
            <option value="Procurement Team">Procurement Team</option>
        `;

        labelTwo.textContent = 'Cost Sharing Group';
        fieldTwo.name = 'cost_sharing_group';
        fieldTwo.innerHTML = `
            <option value="">Select Cost Sharing Group</option>
            <option value="Administration">Administration</option>
            <option value="Healthcare">Healthcare</option>
            <option value="Community Support">Community Support</option>
        `;
    }
}

function loadDonationCountries(category, countryField) {
    if (!category) {
        countryField.innerHTML = '<option value="">Select Country of Origin</option>';
        return;
    }

    countryField.innerHTML = '<option value="">Loading countries...</option>';

    fetch('report_management.php?action=donation_countries&category=' + encodeURIComponent(category))
        .then(response => response.json())
        .then(countries => {
            if (countries.length === 0) {
                countryField.innerHTML = '<option value="">No countries found</option>';
                return;
            }

            countryField.innerHTML = '<option value="">Select Country of Origin</option>' +
                countries.map(country =>
                    '<option value="' + country + '">' + country + '</option>'
                ).join('');
        })
        .catch(() => {
            countryField.innerHTML = '<option value="">Unable to load countries</option>';
        });
}

function printReport() {
    window.print();
}

function selectReport(optionElement, fallbackLabel = "Selected Report") {
    const reportName = optionElement && optionElement.textContent
        ? optionElement.textContent.trim()
        : fallbackLabel;

    const leftLabel = document.querySelector(".selected-report strong");
    const rightLabel = document.getElementById("selectedReport");
    const hiddenInput = document.getElementById("selected_report_input");

    if (leftLabel) {
        leftLabel.textContent = reportName;
    }

    if (rightLabel) {
        rightLabel.textContent = reportName;
    }

    if (hiddenInput) {
        hiddenInput.value = reportName;
    }

    updateFieldLabels(reportName);

    document.querySelectorAll(".report-option").forEach((item) => {
        item.classList.remove("selected-report-option");
    });

    if (optionElement) {
        optionElement.classList.add("selected-report-option");
    }
}

function filterReports() {
    const searchInput = document.getElementById("reportSearch");

    if (!searchInput) {
        return;
    }

    const filter = searchInput.value.toLowerCase();

    document.querySelectorAll(".report-option").forEach((item) => {
        const text = item.textContent.toLowerCase();
        item.style.display = text.includes(filter) ? "" : "none";
    });
}

document.addEventListener("DOMContentLoaded", function () {
    const avatarButton = document.getElementById("avatarButton");
    const avatarMenu = document.getElementById("avatarMenu");

    if (!avatarButton || !avatarMenu) {
        console.error("Avatar elements not found.");
        return;
    }

    avatarButton.addEventListener("click", function (event) {
        event.stopPropagation();

        const isOpen = avatarMenu.classList.toggle("show");

        avatarButton.setAttribute(
            "aria-expanded",
            isOpen ? "true" : "false"
        );
    });

    document.addEventListener("click", function (event) {

        if (
            !avatarMenu.contains(event.target) &&
            !avatarButton.contains(event.target)
        ) {
            avatarMenu.classList.remove("show");
            avatarButton.setAttribute("aria-expanded", "false");
        }

    });

    const initialSelection = document.querySelector(".report-option.selected-report-option");
    if (initialSelection) {
        selectReport(initialSelection, "-");
    }

    const reportsMenu = document.getElementById("reportsMenu");
    if (reportsMenu) {
        reportsMenu.style.display = "block";
    }
});
</script>

</body>
</html>
