<?php
date_default_timezone_set('UTC');
session_start();
require 'C:/xampp/htdocs/MAX_ELECTRONICS_HUB/appl/header.php';
require 'C:/xampp/htdocs/MAX_ELECTRONICS_HUB/res/includes/dB_pwd.php';  

$selector = $_GET["selector"] ?? '';
$validator = $_GET["validator"] ?? '';
?>

<!-- Move meta tags and external stylesheets to the real document head or leave them grouped securely -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
<link href='https://cdn.boxicons.com/3.0.6/fonts/brands/boxicons-brands.min.css' rel='stylesheet'>
<link href='https://cdn.boxicons.com/3.0.6/fonts/basic/boxicons.min.css' rel='stylesheet'>

<style>
/* ==========================================
   1. Universal Style Resets & Base Variables
   ========================================== */
* {
    box-sizing: border-box;
    margin: 0;
    padding: 0;
    font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
}

.wrapper-main {
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 100vh;
    background: linear-gradient(135deg, #4f46e5, #06b6d4);
    padding: 20px;
}

/* ==========================================
   2. Case A: Success Card View Configuration
   ========================================== */
.success-wrapper {
    display: flex;
    justify-content: center;
    align-items: center;
    width: 100%;
}

.success-card {
    background: #ffffff;
    padding: 40px 30px;
    border-radius: 12px;
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.05);
    text-align: center;
    max-width: 420px;
    width: 100%;
    animation: fadeIn 0.4s ease-out;
}

/* Success Checkmark Icon Style (Boxicons) */
.success-card i.bx-check-circle {
    font-size: 64px;
    color: #2ecc71;
    margin-bottom: 15px;
}

.success-card h3 {
    color: #2c3e50;
    font-size: 24px;
    margin-bottom: 10px;
}

.success-card p {
    color: #7f8c8d;
    font-size: 14px;
    line-height: 1.6;
}

/* ==========================================
   3. Case B: Form Container Structure
   ========================================== */
.container {
    position: relative;
    display: flex;
    flex-direction: row;
    background: rgba(255, 255, 255, 0.15);
    max-width: 720px;
    width: 100%;
    border-radius: 12px;
    box-shadow: 0 10px 25px rgba(0, 0, 0, 0.06);
    overflow: hidden;
}

/* Absolute Close Header Cross Link */
.close-btn {
   position: absolute;
   top: 0;
   right: 0;
   width: 30px;
   height: 30px;
   background: whitesmoke;
   border-bottom-left-radius: 10px;
   display: flex;
   justify-content: center;
   align-items: center;
   font-size: 1.2rem;
   color: blue;
   cursor: pointer;
   z-index: 10;
   transition: background 0.3s ease, color 0.3s ease;
   text-decoration: none;
   font-weight: bold;
}

.close-btn:hover {
   background: skyblue;
   color: #ef4444;
   font-weight: bold;
}

/* Left Image Panel Row layout */
.left-side {
    width: 45%;
    background-color: #f9f9f9;
}

.left-side img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    display: block;
}

/* Right Content Inputs Form Pane */
.right-side {
    width: 55%;
    padding: 35px 30px;
    display: flex;
    flex-direction: column;
}

.right-side h2 {
    color: #2c3e50;
    font-size: 22px;
    margin-bottom: 8px;
    font-weight: 600;
    text-align: center;
}

.right-side .subtitle {
    color: whitesmoke;
    font-size: 13px;
    line-height: 1.5;
    margin-bottom: 25px;
    text-align: center;
}

/* ==========================================
   4. Form Controls & Toggle Eye Icons
   ========================================== */
form {
    display: flex;
    flex-direction: column;
    gap: 16px;
}

.input-box {
    position: relative;
    width: 100%;

}

.input-box input {
    width: 100%;
    padding: 12px 40px 12px 14px; /* Right padding keeps text clear of the eye icon */
    border: 1.5px solid #dcdde1;
    border-radius: 6px;
    font-size: 14px;
    color: #2f3640;
    outline: none;
    transition: border-color 0.2s;
}

.input-box input:focus {
    border-color: #2ecc71;
}

/* Password Eye Icon Overlay positioning */
.input-box .toggle-password {
    position: absolute;
    right: 14px;
    top: 50%;
    transform: translateY(-50%);
    color: #7f8c8d;
    cursor: pointer;
    font-size: 14px;
    padding: 4px; /* Increases clickable area */
    transition: color 0.2s;
}

.input-box .toggle-password:hover {
    color: #2c3e50;
}

/* Reset Action Button */
button[type="submit"] {
  background-color: #CDE0E9; /*soft cloud blue*/
  color: blue;
  border: none;
  padding: 12px;
  font-size: 15px;
  font-weight: 600;
  border-radius: 6px;
  cursor: pointer;
  transition: background-color 0.2s;
}

button[type="submit"]:hover {
  background-color: #87CEEB; /* sky blue color */
  color: whitesmoke;
}

/* ==========================================
   5. Lower Section Footer Help/Lines Divider
   ========================================== */
.help {
    display: flex;
    align-items: center;
    margin: 25px 0 15px 0;
}

.help hr {
    flex: 1;
    border: none;
    height: 1px;
    background-color: #eaeded;
}

.help span {
    font-size: 11px;
    color: black;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    padding: 0 10px;
}

.footer-text {
    font-size: 12px;
    color: whitesmoke;
    text-align: center;
    line-height: 1.5;
}

/* CSS Keyframe Entry Animations */
@keyframes fadeIn {
    from { opacity: 0; transform: translateY(8px); }
    to { opacity: 1; transform: translateY(0); }
}

/* ==========================================
   6. Media Queries for Mobile Responsiveness
   ========================================== */
@media (max-width: 680px) {
    .container {
        flex-direction: column;
        max-width: 420px;
    }
    
    .left-side {
        display: none; /* Safely strips the tea image banner off small viewports */
    }
    
    .right-side {
        width: 100%;
        padding: 30px 20px;
    }
}


@media (max-width: 600px) {
    .container { flex-direction: column; width: 90%; }
    .left-side { display: none; } /* Hide landscape image on small screens */
    .right-side { width: 100%; }
}
</style>

<main class="wrapper-main">
    <?php
    // Case A: Show Confirmation Alert if URL has no tokens
    if (empty($selector) && empty($validator)) {
        echo <<<HTML
        <div class="success-wrapper">
            <div class="success-card">
                <i class='bx bx-check-circle'></i>
                <h3>Success!</h3>
                <p>Your request has been submitted.<br> 
                <strong>Check your email for a reset link...</strong></p>
            </div>
        </div>
        <script>
            setTimeout(function() {
                window.location.href = 'http://localhost/MAX_ELECTRONICS_HUB/admin/adm.php';
            }, 5000); // Redirects in 5 seconds
        </script>
        HTML;
            } 

         else { 
             // Case B: Evaluate and process incoming tokens from email click (Hexadecimal checking)

        if (!ctype_xdigit($selector) || !ctype_xdigit($validator)) {
            echo "<script>alert('Invalid token format. Redirecting to home...'); window.location.href='http://localhost/MAX_ELECTRONICS_HUB/';</script>";
            exit();
        }

        // 2. Lookup the selector in the database
        // Matches the "Y-m-d H:i:s" string format saved by your request page
        $currentDate = date("Y-m-d H:i:s");
        
        $sql = "SELECT * FROM pwdreset WHERE selector = ? AND pwdResetExpires >= ? LIMIT 1;";
        $stmt = mysqli_stmt_init($conn);

        if (!mysqli_stmt_prepare($stmt, $sql)) {
            echo "There was an error processing your request.";
            exit();
        }

        mysqli_stmt_bind_param($stmt, "ss", $selector, $currentDate);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);

        // 3. Check if a matching selector exists
        if (!$row = mysqli_fetch_assoc($result)) {
            echo "<script>alert('This link has expired or is invalid. Please request a new one.'); window.location.href='http://localhost/MAX_ELECTRONICS_HUB/res/foget.php';</script>";
            exit();
        }

        // 4. Verify the raw hexadecimal validator against the database hash
        $tokenEmail = $row['pwdResetEmail'];
        $tokenCheck = password_verify($validator, $row['validator']);

        if ($tokenCheck === false) {
            echo "<script>alert('Invalid token validation. Please request a new one.'); window.location.href='http://localhost/MAX_ELECTRONICS_HUB/res/foget.php';</script>";
            exit();
        }
        
        // Success: Tokens match! Proceed to display password input fields.
        ?>
        
        <div class="container">
            <a href="http://localhost/MAX_ELECTRONICS_HUB" class="close-btn">&times;</a>
            
            <!-- Left Side Layout Banner -->
            <div class="left-side">
                <img src="http://localhost/MAX_ELECTRONICS_HUB/Tea_Plantation.jpg" alt="Plantation">
            </div>

            <!-- Right Side Interactive Input Form -->
            <div class="right-side">
                <img src="http://localhost/MAX_ELECTRONICS_HUB/res/Logoo.jpg" style="align-self: center; border-radius: 50%; width: 70px; height: 70px; border: 1px solid #ddd; margin-bottom: 10px;" class="logo" alt="Logo">
                
                <h2>Create New Password</h2>
                <p class="subtitle">Enter and confirm your new password to reset your account password.</p>

                <form action="res_password.php" method="POST">
                    <input type="hidden" name="selector" value="<?php echo htmlspecialchars($selector); ?>">
                    <input type="hidden" name="validator" value="<?php echo htmlspecialchars($validator); ?>">
                    
                    <div class="input-box">
                        <input type="password" name="pwd" placeholder="Enter a new password" required>
                        <i class="fa-solid fa-eye toggle-password"></i>
                    </div>
                    
                    <div class="input-box">
                        <input type="password" name="pwd-repeat" placeholder="Repeat new password" required> 
                        <i class="fa-solid fa-eye toggle-password"></i>
                    </div>
                    
                    <button type="submit" name="res-password-submit">
                        <i class="fa-solid fa-unlock-keyhole"></i> Reset Password
                    </button>
                </form>

                <div class="help">
                    <hr><span>Need help?</span><hr>
                </div>
                <p class="footer-text">
                    If you did not request a password reset, 
                    <a href="http://localhost/MAX_ELECTRONICS_HUB/nav/Contacts.php" style="color:#007bff; text-decoration:none;">contact support</a>.
                </p>
            </div>
        </div>
        <?php 
    } // End Else Token Checker block
    ?>
</main>

<script>
// Password Visibility Interaction handler
document.querySelectorAll(".toggle-password").forEach(function(icon) {
    icon.addEventListener("click", function() {
        let input = this.parentElement.querySelector("input");
        if (input.type === "password") {
            input.type = "text";
            this.classList.replace("fa-eye", "fa-eye-slash");
        } else {
            input.type = "password";
            this.classList.replace("fa-eye-slash", "fa-eye");
        }
    });
});
</script>

<?php 
// Include footer if available or delete if completely styled within header
?>


