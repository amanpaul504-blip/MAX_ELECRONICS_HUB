<?php

// 1. Core session handling must execute first
if (session_status() === PHP_SESSION_NONE) { 
    session_start(); 

}
$isLoggedIn=isset($_SESSION['user_id']);
$firstname = $_SESSION['firstame'] ??'';
$lastname = $_SESSION['lastname'] ??'';
$email = $_SESSION['email'] ??'';

//Include header
require "C:/xampp/htdocs/MAX_ELECTRONICS_HUB/appl/header.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Community Initiatives for Healthy Life</title>
  <style>
    /* Reset basic styles */
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: Arial, sans-serif;
    }

    /* Header styling container */
    .site-header {
      background-color: #E1F6FF;
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 15px 5%;
      box-shadow: 0 2px 5px rgba(0,0,0,0.1);
      position: sticky;
      top: 0;
      z-index: 1000;
    }

    /* Logo area */
    .image-overlay{
      position: fixed;
      top: 8%;
      left: 6%;
      transform: translate(-50%,-50%);
      z-index: 9999;
      pointer-events: none;
    }

    /* Navigation list styling */
    .nav-links {
      list-style: none;
      display: flex;
      gap: 30px;
      margin-left: auto;
    }

    .nav-links a {
      text-decoration: none;
      color: #555;
      font-weight: 500;
      transition: color 0.3s;
    }

    .nav-links a:hover {
      color: #007BFF;
    }

    .user-email {
    background: yellow;
    width: 10%;
    height: 5%;
    padding: 15px 12px;
    border-radius: 18px;
    font-size: 18px;
    color: black;
    }


    /* Action button styling */
    .login-btn {
    background-color: skyblue;
    color: #ffffff;
    padding: 10px 20px;
    border: none;
    border-radius: 50px;
    font-size: 16px;
    cursor: pointer;
    margin-right: 0px;
    transition: background-color 0.2s ease;
    }
    .menu-item i,
    .menu-title i {
    color: blue;
    }
    .login-btn:hover {
    background-color: #0056b3;

    .welcome-note {
    display: inline-block;
    background-color: #f3f4f6; /* Soft neutral gray */
    color: #1f2937;            /* Dark text contrast */
    padding: 0.75rem 1.25rem;
    border-radius: 0.375rem;   /* Smooth rounded corners */
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
    font-size: 0.95rem;
    font-weight: 500;
    border: 1px solid #e5e7eb;  /* Subtle divider frame */
    margin: 1rem 0;
    box-shadow: 0 1px 2px 0 rgba(0, 0, 0, 0.05);
}

   </style>

   <header class="site-header">
     <div class="logo">
      <a href="#">LOGO</a>
    </div>

    <div class="image-overlay">
      <img src= "http://localhost/MAX_ELECTRONICS_HUB/CIHL.jpg" style="width: 90px;height: 90px; border-radius: 50%; margin-top: 0px; border: 0.1px solid ghostwhite;"  alt="Logo">
    </div>
    
    <nav>
      <ul class="nav-links">
        <li><a href="http://localhost/MAX_ELECTRONICS_HUB">Home</a></li>
        <li><a href="#home">Donations</a></li>
        <li><a href="#about">Safari internship</a></li>
        <li><a href="#services">Proffesional Visits</a></li>
        <li><a href="#contact">Others</a></li>
      </ul>
    </nav>

    <div class="user-email">
            <?php echo htmlspecialchars($email); ?>
        </div>

        <i class="fa-solid fa-globe"></i>
        <i class="fa-solid fa-bell"></i>

        <div class="header-avatar">
            E
        </div>


   <!-- 1. The Trigger Button (Place this in your header/navbar) -->
  <button type= "button" class="login-btn" onclick="handleAuth()"><?php echo isset($_SESSION['user_id']) ?'Logout':'Login'; ?></button>

  </header>
  <!-- Welcome note: -->
  <?php 
      // Pull from the URL bar while defending against XSS injection vulnerabilities
      $getFirstName = isset($_GET['firstname']) ? htmlspecialchars(trim($_GET['firstname']), ENT_QUOTES, 'UTF-8') : '';
      $getLastName  = isset($_GET['lastname'])  ? htmlspecialchars(trim($_GET['lastname']), ENT_QUOTES, 'UTF-8') : '';
      
      // Check condition to see if name values actually exist in the browser path
      $hasWelcomeData = (!empty($getFirstName) || !empty($getLastName));
  ?>

  <!-- Your HTML template layout block element -->
  <?php if ($hasWelcomeData): ?>
      <div class="welcome-note">
          Welcome, <?php echo $getFirstName . ' ' . $getLastName; ?>! 
      </div> 
  <?php endif; ?>


  <style>
    * {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
  font-family: 'Poppins', sans-serif;
}

/* Center the login/register card */
body {
    margin: 0;
    width: 100%;
    min-height: 100vh;
    justify-content: center;
    align-items: center;
    background: linear-gradient(135deg, #4f46e5, #06b6d4);
    padding: 0;
    overflow-x: hidden;
}
.site-header {
  position: sticky;
  top:0;
  width: 100%;
  z-index: 1000;
}
 /* Logo area */
.logo a {
  font-size: 24px;
  font-weight: bold;
  color: transparent;
  text-decoration: none;
}

/*Login/register is hidden initially*/
.wrapper {
  display: none;
}
/*shows login/register when activated*/
.wrapper.show{
  display:block;
  position: fixed;
  top:50%;
  left:50%;
  transform: translate(-50%, -50%) scale(1.0);
  z-index: 2000;
}

/* Main form card */
.wrapper {
    position: relative;
    width: 400px;
    max-width: 100%;
    background: rgba(255, 255, 255, 0.15);
    backdrop-filter: blur(15px);
    -webkit-backdrop-filter: blur(15px);
    border: 2px solid rgba(255, 255, 255, 0.2);
    border-radius: 20px;
    box-shadow: 0 15px 35px rgba(0, 0, 0, 0.2);
    padding: 40px;
    color: #fff;
    overflow: hidden;
    transition: transform 0.4s cubic-bezier(0.25, 1, 0.5, 1), max-height 0.4s ease;
    max-height: 400px; /* Base ceiling for the Login form */
}

 /* Position the close button in the top right corner */
 .close-btn {
   position: absolute;
   top: 0;
   right: 0;
   width: 45px;
   height: 45px;
   background: rgba(255, 255, 255, 0.1);
   border-bottom-left-radius: 20px;
   display: flex;
   justify-content: center;
   align-items: center;
   font-size: 1.2rem;
   color: rgba(255, 255, 255, 0.8);
   cursor: pointer;
   z-index: 10;
   transition: background 0.3s ease, color 0.3s ease;
}

 .close-btn:hover {
   background: #E1F6FF;
   color: #ef4444;
   font-weight: bold;
}

/* Sliding container */
.form-container-row {
   display: flex;
   width: 200%;
   align-items: flex-start;
   transition: transform 0.4s cubic-bezier(0.25, 1, 0.5, 1);
}
 .wrapper.active {
    max-height: 620px; /* Tall enough to fit the longer registration form */
}

/* Shift the entire inner row left when active */
.wrapper.active .form-container-row {
  transform: translateX(-50%);
}

/* Each form occupies exactly one card width */
.form-box {
    flex: 0 0 50%;
    width: 30%;
    padding: 10px 40px;
}

h2 {
  font-size: 2em;
  text-align: center;
}

/* Animated Input Fields */
.input-box {
  position: relative;
  width: 100%;
  height: 30px;
  border-bottom: 1px solid #fff;
  margin: 20px 0;
}

.input-box label {
  position: absolute;
  top: 50%;
  left: 5px;
  transform: translateY(-50%);
  font-size: 0.8em;
  pointer-events: none;
  transition: .3s;
}

/* Pull label up when input is focused or contains text */
.input-box input:focus ~ label,
.input-box input:valid ~ label {
  top: -5px;
  font-size: 0.85em;
}

.input-box input {
  width: 100%;
  height: 100%;
  background: transparent;
  border: none;
  outline: none;
  font-size: 1em;
  padding: 0 35px 0 5px;
  color: #fff;
}

.input-box .icon {
  position: absolute;
  right: 8px;
  font-size: 1.1em;
  line-height: 55px;
}

/* Layout for terms / links */
.forgot {
  font-size: .7em;
  display: flex;
  justify-content: space-between;
  margin: -10px 0 20px;
  font-weight: bold;
  text-decoration: none;
  margin-bottom: 10px;
}

.forgot label input {
  accent-color: #4f46e5;
  margin-right: 5px;
}

.forgot a {
  color: #fff;
  text-decoration: none;
  text-align: center;
}

.forgot a:hover {
  color: blue;
}

/* Glassmorphism Buttons */
.btn {
  width: 100%;
  height: 45px;
  background: #E1F6FF;
  border: none;
  outline: none;
  border-radius: 10px;
  cursor: pointer;
  font-size: 1em;
  color: #000;
  font-weight: 600;
  transition: background 0.3s, transform 0.1s;
}

.btn:hover {
  background: whitesmoke;
  color: black;
  font-weight: bold;
  font-size: 18px;
}

.btn:active {
  transform: scale(0.98);
}

.login-register {
  font-size: .9em;
  text-align: center;
  margin: 20px 0 0;
}

.login-register p a {
  color: #fff;
  text-decoration: none;
  font-weight: 600;
}

.login-register p a:hover {
  text-decoration: underline;
}

.login-alert {
  width: 100%;
  color: red;
  text-align: center;
  font-size: 14px;

}

@media (max-width: 480px) {
  body { padding: 10px; }
  .wrapper {
    width: 100%;
    padding: 35px 25px;
  }
  h2 {
    font-size: 1.7em;
  }
}
</style>

  <!-- MAIN OVERLAY WRAPPER -->
<div class="wrapper <?php echo $showLogin ? 'show' : ''; ?>" id="loginModal">
  
  <!-- Content Card Box -->
  <div class="modal-card">
    
    <!-- Close Button -->
    <span class="close-btn" id="closeLogin">X</span>

    <!-- Sliding Form Wrapper Track -->
    <div class="form-container-row">
      
      <!-- LOGIN FORM PANEL -->
      <div class="form-box login">
        <h2>Login</h2>
            
        <!-- PHP Session Flash Messages safely contained inside the form layout -->
        
        <div id="login-container" class="login-container">
        <form action="adm_auth_process.php" method="POST">
          <div class="input-box">
            <span class="icon"><i class="fa-solid fa-envelope"></i></span>
            <input type="email" name="email" required>
            <label>Email</label>
          </div>
          
          <div class="input-box">
            <span class="icon"><i class="fa-solid fa-lock"></i></span>
            <input type="password" name="password" required>
            <label>Password</label>
          </div>
          <input type="hidden" name="redirect" value="<?php echo htmlspecialchars($_SERVER['REQUEST_URI']); ?>">
          <div class="forgot">
            <a href="forgot.php">Forgot Password?</a>
          </div>
          
          <button type="submit" name="login_btn" class="btn">Login</button>
          
          <div class="login-register">
            <!-- FIXED: Replaced "." with descriptive actionable link text -->
            <p>Don't have an account? <a href="#" class="register-link">Register</a></p>
          </div>
        </form>
       </div>
      </div>

      <!-- REGISTRATION FORM PANEL -->
      <div class="form-box register">
        <h2>Registration</h2>
        <form action="adm_auth_process.php" method="POST">
          
          <div class="input-box">
            <span class="icon"><i class="fa-solid fa-user"></i></span>
            <input type="text" name="firstname" id="firstname" required>
            <label>First Name</label>
          </div>
          
          <div class="input-box">
            <span class="icon"><i class="fa-solid fa-user"></i></span>
            <input type="text" name="lastname" id="lastname" required>
            <label>Last Name</label>
          </div>
          
          <div class="input-box">
            <span class="icon"><i class="fa-solid fa-envelope"></i></span>
            <input type="email" name="email" required>
            <label>Email</label>
          </div>
          
          <div class="input-box">
            <span class="icon"><i class="fa-solid fa-lock"></i></span>
            <input type="password" name="password" required>
            <label>Password</label>
          </div>
          
          <button type="submit" name="register_btn" class="btn">Register</button>
          
          <div class="login-register">
            <p>Already have an account? <a href="#" class="login-link">Login</a></p>
          </div>
        </form>
       </div>
      </div> <!-- End .form-container-row -->
    </div> <!-- End .modal-card -->
  </div> <!-- End #loginModal -->

  <!-- JavaScript to toggle forms -->
  <script>
      // Select main modal container and interactive components
    const loginModal = document.getElementById('loginModal');
    const registerLink = document.querySelector('.register-link');
    const loginLink = document.querySelector('.login-link');
    const closeBtn = document.getElementById('closeLogin');

    /**
     * 1. Open the Modal & Show Login Form
     * Triggered by your navbar button: onclick="showLogin()"
     */
    function showLogin() {
        loginModal.classList.add('show');
        loginModal.classList.remove('active'); // Ensures it defaults to login view
    }

    /**
     * 2. Switch to Registration View
     * Slide effect triggered by clicking the register link inside the card
     */
    if (registerLink) {
        registerLink.addEventListener('click', function (e) {
            e.preventDefault();
            loginModal.classList.add('active'); // Toggles CSS sliding track mechanism
        });
    }

    /**
     * 3. Switch back to Login View
     * Slide effect triggered by clicking the login link inside the card
     */
    if (loginLink) {
        loginLink.addEventListener('click', function (e) {
            e.preventDefault();
            loginModal.classList.remove('active'); // Slides track back to login
        });
    }

    /**
     * 4. Helper function to completely close and clear the modal
     */
    function closeModal() {
        loginModal.classList.remove('show');
        loginModal.classList.remove('active');
        
        // Optional: Reset form fields so input values clear when closed
        const forms = loginModal.querySelectorAll('form');
        forms.forEach(form => form.reset());
    }

    // 5. Close modal when clicking the explicit 'X' button
    if (closeBtn) {
        closeBtn.addEventListener('click', closeModal);
    }

    // 6. Close modal when user clicks anywhere outside the form card container
    window.addEventListener('click', function (e) {
        if (e.target === loginModal) {
            closeModal();
        }
    });


    document.addEventListener("DOMContentLoaded", function () {

    const loginContainer = document.getElementById("loginContainer");

    <?php if (!empty($_SESSION['error'])): ?>

        // Keep login container open
        if (loginContainer) {
            loginContainer.style.display = "flex";
            loginContainer.classList.add("active");
        }

        // Show JavaScript alert
        alert("<?php echo addslashes($_SESSION['error']); ?>");

        // Clear the error so it doesn't appear again after refresh
        <?php unset($_SESSION['error']); ?>

    <?php endif; ?>

});
    function handleAuth() {
      const isLoggedIn = <?php echo isset($_SESSION['user_id']) ? 'true':
      'false'; ?>;

      if (isLoggedIn) {
        window.location.href="logout.php"
      }else{
        showLogin();
      }
    }
</script>
</body>
</html>
