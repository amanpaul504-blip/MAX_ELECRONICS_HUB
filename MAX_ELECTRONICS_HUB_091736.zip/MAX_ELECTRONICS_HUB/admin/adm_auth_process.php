<?php
// 1. Establish session handling and load database profile
if (session_status() === PHP_SESSION_NONE) {
    session_start();

    $loginError = $_SESSION['login_error'] ?? '';
    unset($_SESSION['login_error']);
}

// Fallback connection parameters — update to match your local architecture configuration
$host = "localhost";
$dbname = "appl_db";
$username = "root";
$password = "";

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Database access connection initialization failed.");
}

// 2. REGISTRATION FORM HANDLING
if (isset($_POST['register_btn'])) {
    // Map data from the HTML form names matching: $_POST['firstname'] and $_POST['lastname']
    $firstname       = trim($_POST['firstname'] ?? '');
    $lastname        = trim($_POST['lastname'] ?? '');
    $email           = 'cybermisc4@gmail.com';
    $password        = $_POST['password'] ?? ''; 

    // 1. Initial Input Presence Validation
    if (empty($firstname) || empty($lastname) || !$email || empty($password)) {
        $_SESSION['error'] = "All standard form items must be completed properly.";
        header("Location: adm.php");
        exit;
    }

    // 2. Password Confirmation Match Validation (Fixed self-comparison bug)
    // Note: If you add a password confirmation field later, change the second variable to $_POST['confirm_password']
    if (isset($_POST['confirm_password']) && $password !== $_POST['confirm_password']) { 
        $_SESSION['error'] = "The passwords you entered do not match.";
        header("Location: adm.php");
        exit;
    }

    // 3. Authority Validation Rules & Complexity Checks
    if (strlen($password) < 6) {
        exit('Password must contain at least 6 characters.');
    }

        // ... inside your register_btn form validation check blocks ...

    // 4. Secure Password Cryptographic Hashing
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

    // 5. Database Verification and Row Insertion
    try {
        // Enforce email uniqueness check before inserting
        $checkStmt = $pdo->prepare("SELECT id FROM admn WHERE email = ?");
        $checkStmt->execute([$email]);
        if ($checkStmt->fetch()) {
            $_SESSION['error'] = "This email is already registered.";
            header("Location: http://localhost/MAX_ELECTRONICS_HUB/admin/adm.php");
            exit;
        }

        // Insert the verified user data
        $insertStmt = $pdo->prepare("INSERT INTO admn (firstname, lastname, email, password) VALUES (?, ?, ?, ?)");
        $insertStmt->execute([$firstname, $lastname, $email, $hashedPassword]);

        // SUCCESS: Flush out previous validation session errors
        unset($_SESSION['error']); 

        // YOUR UPDATED ABSOLUTE GET REDIRECTION LOGIC:
        $redirectUrl = "http://localhost/MAX_ELECTRONICS_HUB/admin/adm.php?firstname=" . urlencode($firstname) . "&lastname=" . urlencode($lastname);

        // Execute the redirect jump
        header("Location: " . $redirectUrl);
        exit;

    } catch (PDOException $e) {
        $_SESSION['error'] = "A critical backend system execution error occurred: " . $e->getMessage();
        header("Location: http://localhost/MAX_ELECTRONICS_HUB/admin/adm.php");
        exit;
    }
} 

// 3. LOGIN FORM HANDLING
if (isset($_POST['login_btn'])) {
    $email    = filter_var(trim($_POST['email'] ?? ''), FILTER_VALIDATE_EMAIL);
    $password = $_POST['password'] ?? ''; 

    if (!$email || empty($password)) {
        $_SESSION['error'] = "Please provide both valid access credentials.";
        header("Location: adm.php");
        exit;
    }

    try {
        // Normalised column names to select from: firstname and lastname fields
        $stmt = $pdo->prepare("SELECT id, firstname, lastname, password FROM admn WHERE email = ?");
        $stmt->execute([$email]);
        $user = $stmt->fetch();

        // Perform password cryptographic validation matching checks
        if ($user && password_verify($password, $user['password'])) {
        session_regenerate_id(true);
        $_SESSION['user_id'] = $user['id'];
        header("Location: admn.php");
        exit;

    } else {
        // FAILURE: Map error states into the global state array
        $_SESSION['login_error'] = "Invalid email or password.";
        $_SESSION['show_login']  = true; // This flag lets JavaScript open the popup card automatically
        header("Location: http://localhost/MAX_ELECTRONICS_HUB/admin/adm.php");
        exit;
    } 
        
    } catch (PDOException $e) { 
        $_SESSION['error'] = "A system verification query error occurred.";
        header("Location: adm.php");
        exit;
    }
}

// If accessed directly without form interaction, redirect back home
header("Location: index.php");
exit;
