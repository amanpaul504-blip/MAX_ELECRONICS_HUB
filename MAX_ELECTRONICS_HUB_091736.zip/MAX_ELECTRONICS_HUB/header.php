<?php
if (session_status() === PHP_SESSION_NONE) session_start();
$cartCount = array_sum($_SESSION['cart'] ?? []);
?>
<header class="site-header">
  <a class="brand" href="index.php"><span class="brand-mark">M</span><span>MAX ELECTRONICS HUB</span></a>
  <nav>
    <a href="index.php">Home</a>
    <a href="products.php">Products</a>
    <a href="about.php">About</a>
    <a href="contacts.php">Contact</a>
  </nav>
  <div class="header-actions">
    <a class="cart-link" href="cart.php">🛒 Cart <b><?= $cartCount ?></b></a>
    <?php if (!empty($_SESSION['fname'])): ?>
      <a class="login-link" href="logout.php">Logout</a>
    <?php else: ?>
      <a class="login-link" href="user_login.php">Login</a>
    <?php endif; ?>
  </div>
</header>